# Low Tool Mode

Use this mode when the target agent or AI can read local files but has weak or missing tool ability.

## Typical constraints

1. cannot write files directly
2. cannot run local scripts
3. cannot open extra windows
4. cannot keep durable owned-scope artifacts by itself

## Required behavior

1. stay inside read-and-reason mode unless a human operator explicitly runs a local command
2. prefer `START_HERE_PROMPTS.md` and direct `SKILL.md` paths over generated prompt bundles that require tooling first
3. expose every next action as a copy-paste-ready instruction for the operator
4. when a bundled script is required, name the exact script path, expected input, and expected output artifact
5. when multi-window work is recommended, ask the operator to open and route the windows manually
6. do not pretend that a file was updated if the environment cannot actually write it
7. when the next step cannot be executed locally, emit `OPERATOR_HANDOFF_CONTRACT.md` fields explicitly instead of leaving the handoff implicit

## Fallback sequence

1. enter through `research-skill-hub/SKILL.md`
2. let the agent inspect and recommend the correct local skill
3. if the chosen skill depends on scripts, convert that step into an operator instruction
4. keep user checkpoints explicit in the main conversation
5. if durable workspace artifacts are required, either:
   - ask the operator to run the local script, or
   - stop at analysis and handoff rather than claiming the workspace was updated

## Profile mapping

Use the `chat-manual-operator` platform profile when a human can assist with commands and windows.

Use the `read-only-review-agent` profile when the agent can read local files but should not assume writes, scripts, or window spawning at all.

Use `OPERATOR_HANDOFF_CONTRACT.md` when the environment limit must be handed off explicitly to a human or stronger agent.
