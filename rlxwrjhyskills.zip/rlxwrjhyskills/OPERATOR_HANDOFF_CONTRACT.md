# Operator Handoff Contract

Use this contract when the active agent can analyze the project but cannot safely perform the next filesystem write, local script execution, or multi-window launch.

## Required fields

1. `objective`
   - one sentence describing what the next step is trying to achieve
2. `environment_limit`
   - the exact blocker such as `no_local_writes`, `no_subprocess_execution`, or `no_multi_window_launch`
3. `required_operator_action`
   - the exact action a human or stronger agent must perform next
4. `input_paths`
   - the local files or folders the operator must read or pass into the next step
5. `output_paths`
   - the files that should exist after the operator action completes
6. `verification_rule`
   - how to confirm the action succeeded
7. `resume_prompt`
   - the exact prompt that should be sent back into the next agent after the operator action completes

## Minimal template

```text
objective: <ONE_SENTENCE_OBJECTIVE>
environment_limit: <LIMIT_NAME>
required_operator_action: <EXACT_ACTION>
input_paths:
- <PATH_A>
- <PATH_B>
output_paths:
- <PATH_C>
- <PATH_D>
verification_rule: <HOW_TO_CONFIRM_SUCCESS>
resume_prompt: <COPY_PASTE_READY_PROMPT>
```

## Rule

Do not say the workspace was updated when the environment limit prevented the write.

Instead, emit this contract and stop at the correct checkpoint.
