#!/usr/bin/env python3
"""Validate research platform adapter profiles."""

from __future__ import annotations

import json
import sys
from pathlib import Path


ALLOWED_PROMPT_STYLES = {"universal", "codex"}
ALLOWED_EXECUTION_POSTURES = {"tool_runner", "manual_operator", "worker_lane"}
ALLOWED_MULTI_WINDOW_MODELS = {"user_assisted", "manual", "external_orchestrator"}


def main() -> None:
    if len(sys.argv) != 2:
        print("Usage: python validate_research_platform_profiles.py <profiles_json>")
        sys.exit(1)

    path = Path(sys.argv[1]).resolve()
    payload = json.loads(path.read_text(encoding="utf-8"))
    profiles = payload.get("profiles", [])
    checks = {
        "schema_version_ok": payload.get("schema_version") == 1,
        "profiles_nonempty": bool(profiles),
        "profile_ids_unique": profile_ids_unique(profiles),
        "profile_shapes_ok": all(profile_shape_ok(profile) for profile in profiles),
        "profile_enums_ok": all(profile_enums_ok(profile) for profile in profiles),
        "manual_operator_rules_ok": all(manual_operator_rules_ok(profile) for profile in profiles),
        "worker_lane_rules_ok": all(worker_lane_rules_ok(profile) for profile in profiles),
    }
    result = {
        "profiles_file": str(path),
        "profile_count": len(profiles),
        "checks": checks,
        "status": "ready" if all(checks.values()) else "needs_attention",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result["status"] == "ready" else 1)


def profile_ids_unique(profiles: list[dict]) -> bool:
    ids = [item.get("id") for item in profiles]
    return len(ids) == len(set(ids)) and all(ids)


def profile_shape_ok(profile: dict) -> bool:
    required_keys = {
        "id",
        "display_name",
        "prompt_style",
        "execution_posture",
        "supports_local_file_paths",
        "supports_bundled_scripts",
        "multi_window_launch_model",
        "assumptions",
        "overlay",
    }
    return (
        required_keys.issubset(profile)
        and isinstance(profile.get("assumptions"), list)
        and isinstance(profile.get("overlay"), list)
        and all(isinstance(item, str) and item.strip() for item in profile.get("assumptions", []))
        and all(isinstance(item, str) and item.strip() for item in profile.get("overlay", []))
    )


def profile_enums_ok(profile: dict) -> bool:
    return (
        profile.get("prompt_style") in ALLOWED_PROMPT_STYLES
        and profile.get("execution_posture") in ALLOWED_EXECUTION_POSTURES
        and profile.get("multi_window_launch_model") in ALLOWED_MULTI_WINDOW_MODELS
    )


def manual_operator_rules_ok(profile: dict) -> bool:
    if profile.get("execution_posture") != "manual_operator":
        return True
    return profile.get("supports_bundled_scripts") is False and profile.get("multi_window_launch_model") == "manual"


def worker_lane_rules_ok(profile: dict) -> bool:
    if profile.get("execution_posture") != "worker_lane":
        return True
    overlay_text = " ".join(profile.get("overlay", [])).lower()
    return "scope" in overlay_text and "phase" in overlay_text or "coordinator" in overlay_text


if __name__ == "__main__":
    main()
