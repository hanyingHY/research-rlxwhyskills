#!/usr/bin/env python3
"""Generate a no-local-file-access transfer packet for one research skill."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True

from research_runtime import python_command, run_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a transfer packet for no-local-file-access environments")
    parser.add_argument("--skill-path")
    parser.add_argument("--skill-name")
    parser.add_argument("--skills-root", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--project-root", default="<PROJECT_ROOT>")
    parser.add_argument("--style", choices=["generic", "universal", "codex"], default="universal")
    parser.add_argument("--autonomous-mode", action="store_true")
    parser.add_argument("--output")
    parser.add_argument("--format", choices=["json", "markdown"], default="json")
    args = parser.parse_args()

    if not args.skill_path and not args.skill_name:
        raise ValueError("Provide --skill-path or --skill-name")

    skills_root = Path(args.skills_root).resolve()
    skill_path = Path(args.skill_path).resolve() if args.skill_path else skills_root / args.skill_name / "SKILL.md"
    skill_name = args.skill_name or infer_skill_name(skill_path)
    skill_text = skill_path.read_text(encoding="utf-8")
    direct_reference_paths = discover_direct_references(skill_text)
    bundled_script_paths = discover_bundled_scripts(skill_text)
    included_references = [build_reference_record(skill_path.parent, ref_path) for ref_path in direct_reference_paths]

    prompt_payload = run_json([
        *python_command(
            skills_root / "build_research_skill_prompt.py",
            "--skill-path",
            skill_path,
            "--project-root",
            args.project_root,
            "--style",
            args.style,
            *( ["--autonomous-mode"] if args.autonomous_mode else [] ),
        )
    ])

    result = {
        "schema_version": 1,
        "skill_name": skill_name,
        "skill_path": str(skill_path),
        "project_root": str(args.project_root),
        "style": args.style,
        "autonomous_mode": args.autonomous_mode,
        "activation_prompt": prompt_payload.get("prompt", ""),
        "invocation_contract": prompt_payload.get("invocation_contract", ""),
        "skill_body": skill_text,
        "included_references": included_references,
        "bundled_script_paths": bundled_script_paths,
        "transfer_steps": [
            "Choose the target skill on a machine that can access the local skill family.",
            "Paste the activation prompt into the no-local-file-access environment.",
            "Paste the SKILL.md body and only the included reference files from this packet.",
            "If a local script or write step is required, convert it into an explicit operator handoff instead of pretending it was executed.",
        ],
        "status": "ready",
    }

    if args.output:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        if args.format == "markdown":
            output.write_text(render_markdown(result), encoding="utf-8")
        else:
            output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(result, ensure_ascii=False, indent=2))


def infer_skill_name(skill_path: Path) -> str:
    text = skill_path.read_text(encoding="utf-8")
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("name:"):
            return stripped.split(":", 1)[1].strip()
    return skill_path.parent.name


def discover_direct_references(skill_text: str) -> list[str]:
    refs = sorted(set(re.findall(r"`(references/[^`]+)`", skill_text)))
    return refs


def discover_bundled_scripts(skill_text: str) -> list[str]:
    return sorted(set(re.findall(r"`(scripts/[^`]+)`", skill_text)))


def build_reference_record(skill_root: Path, relative_path: str) -> dict:
    full_path = skill_root / relative_path
    return {
        "relative_path": relative_path,
        "full_path": str(full_path),
        "content": full_path.read_text(encoding="utf-8"),
    }


def render_markdown(result: dict) -> str:
    transfer_steps = "\n".join(f"1. {step}" for step in result.get("transfer_steps", [])) or "1. none"
    script_lines = "\n".join(f"- `{path}`" for path in result.get("bundled_script_paths", [])) or "- none"
    reference_sections = []
    for ref in result.get("included_references", []):
        reference_sections.extend([
            f"## Reference: {ref['relative_path']}",
            "",
            f"- full_path: `{ref['full_path']}`",
            "",
            "````text",
            ref["content"],
            "````",
            "",
        ])
    reference_block = "\n".join(reference_sections) if reference_sections else "## References\n\n- none\n"
    return f"""# Research Skill Transfer Packet

## Summary

- skill_name: `{result['skill_name']}`
- skill_path: `{result['skill_path']}`
- project_root: `{result['project_root']}`
- style: `{result['style']}`
- autonomous_mode: `{result.get('autonomous_mode', False)}`
- invocation_contract: {result['invocation_contract']}

## Activation Prompt

```text
{result['activation_prompt']}
```

## Transfer Steps

{transfer_steps}

## Bundled Script Paths

{script_lines}

## SKILL.md

````text
{result['skill_body']}
````

{reference_block}"""


if __name__ == "__main__":
    main()
