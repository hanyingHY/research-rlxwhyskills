# Research Skills Family Guide / 研究技能体系说明

## Overview / 概览

This family turns papers, project materials, and implementation work into an auditable research workflow. Version `1.1.0` uses two independent governance tracks: research credibility and code implementation maturity.

本技能家族把文献、项目材料和实现工作组织成可审计的研究流程。当前版本为 `1.1.0`，采用研究可信度与代码实现成熟度两条独立治理轨道。

The development source of truth is `skills/`. `rlxwrjhyskills/` and `rlxwrjhyskills.zip` are generated release artifacts and should not be edited directly.

开发源唯一权威目录是 `skills/`。`rlxwrjhyskills/` 和 `rlxwrjhyskills.zip` 是生成的发布产物，不应直接修改。

## Components / 组件

| Entry / 入口 | Use it when / 适用情况 | Main output / 主要产物 |
| --- | --- | --- |
| Research Skill Hub | You need to discover and choose an entry / 需要发现并选择入口 | Skill comparison and handoff prompt / 技能比较与交接提示 |
| Research Pipeline Lite | The corpus is small or medium and triage should be fast / 材料规模小到中等，需要快速分诊 | Evidence summary, action map, implementation snapshot / 证据摘要、行动映射、实现快照 |
| Research Pipeline Full | You need experiments, benchmark freeze, release decisions, or multi-window auditability / 需要实验、基准冻结、发布决策或多窗口审计 | Full workspace, maturity assessment, route gates, engineering backlog / 完整工作区、成熟度评估、路线门控、工程 backlog |

Use Hub first when the track is unknown. Choose Full whenever the task asks whether code is executable, results can be promoted, a benchmark can be frozen, or a release is ready.

当无法确定轨道时先使用 Hub。凡是涉及代码能否执行、结果能否晋级、基准能否冻结或是否可以发布，都应选择 Full。

## Dual-track governance / 双轨治理

Research credibility is scored from evidence quality. Implementation maturity is scored independently across six equal-weight dimensions: traceability, implementation completeness, runnability, automated verification, reproducibility/benchmark linkage, and operational readiness.

研究可信度根据证据质量评分。代码成熟度独立评估六个等权维度：可追溯性、实现完整性、可运行性、自动化验证、复现与基准关联、运维或交付准备度。

| Target stage / 目标阶段 | Minimum implementation level / 最低实现等级 | Required joint status / 要求的联合状态 |
| --- | --- | --- |
| Research retention or validation placeholder / 研究保留或验证占位 | M0 | `research_only` |
| Experiment execution / 实验执行 | M2 | `ready_for_execution` |
| Result promotion / 结果晋级 | M3 | `ready_for_promotion` |
| Benchmark freeze / 基准冻结 | M4 | `ready_for_benchmark_freeze` |
| Release or production delivery / 发布或生产交付 | M5 | `ready_for_release` |

A high research score never offsets an implementation failure. A missing executable environment is recorded as `not_run`; this can preserve research整理 but blocks M2+ advancement.

高研究分不能抵消实现失败。不可用的执行环境记录为 `not_run`；它不会阻止研究整理，但会阻止 M2 及以上晋级。

## Route identity / 路线身份

`route_id` is the durable join key across credibility records, code inventory, implementation evidence, and readiness matrices. `route_board` only labels a route as stable or aggressive; it is not a route identifier.

`route_id` 是可信度记录、代码盘点、实现证据和 readiness 矩阵之间的稳定连接键。`route_board` 只表示 stable 或 aggressive 分类，不能充当路线标识。

If credibility records exist without explicit `route_id`, retain the research conclusion but mark execution and later promotion as `mapping_required` until the route is mapped.

如果可信度记录存在但缺少显式 `route_id`，仍保留研究结论；但在补齐路线映射前，实验执行及后续晋级标记为 `mapping_required` 并阻断。

## Workspace contract / 工作区契约

Full creates the following under `05_validation/`:

Full 在 `05_validation/` 下生成：

- `code_inventory.csv`: components, paths, entries, dependencies, tests, benchmarks / 组件、路径、入口、依赖、测试、基准
- `implementation_evidence.csv`: static and executable evidence / 静态与可执行证据
- `implementation_assessment.csv`: six scores, level, blockers, next action / 六维评分、等级、阻塞项、下一动作
- `implementation_backlog.csv`: engineering tasks and acceptance criteria / 工程任务与验收条件
- `route_readiness_matrix.csv`: separate research and implementation gates / 独立研究与实现门控
- `IMPLEMENTATION_READINESS.md`: human-readable summary / 面向用户的摘要

Lite creates only `03_output/implementation_snapshot.csv` and writes gaps into the existing action map. Complex implementation gaps or any real execution/promotion work should move to Full.

Lite 只生成 `03_output/implementation_snapshot.csv`，并把缺口写入现有 action map。复杂实现缺口或任何真实执行、晋级工作都应升级到 Full。

## Authority and safety / 权限与安全

Static audit is always allowed. Build, test, smoke, benchmark, and reproduction commands must be project-declared or user-confirmed and non-destructive. By default, the system audits and creates backlog tasks; it does not modify business code. Explicit engineering authorization is required before implementation changes.

静态审计始终允许。构建、测试、烟测、基准和复现命令必须由项目声明或经用户确认，且不可破坏。默认只审计并生成 backlog，不修改业务代码；实施工程修改前需要明确授权。

For quantitative research, select the `quant-research` profile to add point-in-time safety, leakage, backtest-integrity, output-contract, environment, and benchmark-freeze checks.

量化研究请选择 `quant-research` profile，以增加时点安全、泄漏、回测完整性、输出契约、环境复现和基准冻结检查。

## Related documents / 相关文档

- `RESEARCH_SKILLS_LAUNCH_BILINGUAL.md`: commands and copy-paste prompts / 命令与可复制提示词
- `START_HERE_PROMPTS.md`: portable skill prompts / 可移植技能提示词
- `research_skill_quickstart.md`: generated quickstart pack / 生成的快速启动包
- `research_platform_adapter_pack.md`: platform adapter / 平台适配提示
