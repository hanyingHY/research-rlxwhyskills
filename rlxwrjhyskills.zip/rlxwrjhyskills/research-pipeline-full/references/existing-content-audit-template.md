# Existing Content Audit Template

## Objective

Provide a reusable structure for auditing claims that already exist inside a research project before trusting them.

## Required sections

1. claim inventory
2. source or provenance check
3. authority assessment
4. external confirmation or contradiction result
5. disposition decision
6. rewrite or quarantine notes when needed

## Suggested output artifacts

1. `existing_content_audit.md`
2. `claim_verification_log.csv`
3. `source_authority_log.csv`
4. `search_trace_log.csv` when the audit itself required outward search or citation chasing
5. `credibility_summary.csv` when important retained claims or source bundles were explicitly scored
