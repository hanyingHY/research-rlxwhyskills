# Literature-Only Mode

## Objective

Support users who want maximum high-trust source accumulation without jumping into engineering or experimental implementation.

## Rules

1. do not implement code, models, or experiments unless the user explicitly asks for that phase
2. still extract validation-ready conclusions and placeholders
3. keep every retained claim mapped to a later action category
4. keep provenance, conflict logs, and disposition states as if execution were coming later
5. stop at user decision gates instead of silently moving from accumulation into scaffolding or execution
6. after each bounded literature-search wave, ask the user whether the search depth is sufficient before declaring the literature pass complete
7. if the user wants more, increase either search breadth, search depth, or both in an explicit escalation step

## Minimum requirement

Even in literature-only mode, the worker must still leave behind:

1. retained evidence
2. conflict adjudication
3. validation placeholders
4. clear immediate next research actions
