# Autonomous Execution Pilot

## Status

Supported opt-in high-intensity mode.

Do not treat this mode as the default research-program behavior.

## Objective

Allow a user to opt into a more hands-off mode when they explicitly prefer reduced checkpoint frequency and want the agent to keep pushing the task toward the strongest reachable result inside an approved scope.

## Default rule

The default skill behavior remains user-checkpoint-first.

This autonomy mode may be used only when the user explicitly authorizes more autonomous execution.

## Required warnings

Before enabling this mode, clearly warn the user that:

1. the agent may advance across multiple stages without waiting at every gate
2. execution cost, scope drift, and cleanup risk increase
3. token consumption may increase materially because the agent will keep iterating until the approved stop conditions are met
4. this mode is not the default or safest mode

## Minimum consent requirements

Do not enable autonomous execution unless all are true:

1. the user explicitly says they want hands-off or autonomous progression
2. the workspace records that consent in a visible file
3. the current phase and stop conditions are recorded before autonomy starts
4. the approved scope boundary is recorded before autonomy starts
5. the next mandatory manual review point is recorded before autonomy starts

## Full-auto completion standard

When autonomy is enabled, do not aim for a merely acceptable pass.

Push the task toward the strongest reachable in-scope result by repeating bounded improvement waves until one of these is true:

1. the approved success condition is satisfied
2. additional bounded waves are no longer improving retained evidence, conflict resolution, validation quality, or decision quality in a meaningful way
3. a recorded hard stop condition is reached

## Research-first rule

Autonomous mode should optimize the research task itself before polishing surrounding structure.

Once the workspace has enough structure to safely continue, prefer:

1. stronger retained evidence
2. better contradiction handling
3. clearer direction ranking
4. stronger validation mapping
5. better final decision quality

Do not keep spending major effort on scaffold beautification unless a structure defect is blocking those outcomes.

## Single-window fallback rule

Autonomous mode must not depend on the user being able to open multiple windows.

If the environment or operator cannot support multi-window execution, fall back to one-window phased execution and keep the original research responsibilities separated in time instead of separated by concurrent windows.

Recommended single-window phase order:

1. coordinator and control-surface pass
2. intake and master-table stabilization pass
3. direction pass 01
4. direction pass 02
5. direction pass 03
6. direction pass 04
7. direction pass 05
8. conflict-review pass
9. synthesis and validation-mapping pass

In that fallback, the agent should preserve the same evidence, conflict, and validation contracts that the multi-window program would have used.

## Structure sufficiency ceiling

Treat structure work as sufficient once the current run already has:

1. a usable intake-to-evidence path
2. visible decision surfaces
3. the minimum audit traces needed for the active mode
4. enough operator or worker contracts to prevent drift

After that point, further structure refinement needs a concrete blocker, not just a preference for tidier control files.

## Guardrails

Even in autonomous mode:

1. do not skip evidence grading
2. do not skip conflict adjudication
3. do not skip benchmark or validation logic
4. do not take destructive cleanup action without explicit user approval
5. stop and ask again if a new major scope jump appears
6. stop and ask again before stable-versus-aggressive execution selection if the user has not already chosen one explicitly
7. keep bounded-wave summaries so later reviewers can see what each autonomous pass improved

## Generated-workspace contract

If autonomous mode is enabled, the workspace should expose:

1. `00_protocol/EXPERIMENTAL_AUTONOMY_CONSENT.md`
2. `00_protocol/AUTONOMY_STATUS.md`

The consent artifact should visibly record:

1. warning acknowledgement
2. explicit user consent
3. approved scope boundaries
4. required manual stops
5. hard stop conditions
6. token-cost acknowledgement
7. autonomy completion standard

The status artifact should visibly record:

1. autonomy mode
2. whether warnings were acknowledged
3. whether explicit consent was granted
4. approved scope boundaries
5. required manual stops
6. stop conditions
7. current operating authority
8. last manual gate
9. next mandatory review
10. autonomy cost warning
11. autonomy completion target
12. structure sufficiency state

## Suggested autonomy states

1. `disabled`
2. `enabled_with_user_consent`
3. `paused_for_user_review`
4. `stopped`
