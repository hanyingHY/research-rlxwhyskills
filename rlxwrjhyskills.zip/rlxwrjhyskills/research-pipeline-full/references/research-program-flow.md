# Research Program Flow

## Objective

Run a research project from raw corpus contact to multi-window launch in a way that is auditable, iterative, and saturation-aware.

## End-to-end flow

1. traverse the existing research project and inventory all files
2. if the workspace is still an unstructured pile, bootstrap a reusable research layout before trusting any summary or direction map
3. identify what the project is already researching
4. audit existing research content for authority and accuracy before trusting it
5. stop and ask the user whether to consolidate, strengthen, proceed into discovery, or stop
6. if the current audit is already usable, ask whether the user wants one more bounded optimization wave before freezing it
7. search outward until the real direction set stabilizes and no meaningful direction-level increment remains
8. verify source authority before retaining direction-level evidence
9. stop and ask the user whether to consolidate, strengthen, proceed into deep search, or stop
10. if the current direction map is already usable, ask whether the user wants one more bounded optimization wave before freezing it
11. if the user proceeds, ask which directions move forward, what deep-dive intensity each chosen direction should use, and what budget intent each chosen direction should carry
12. deepen each retained direction until information gain flattens
13. relate the directions to each other and write a synthesis report
14. split the retained ideas into stable and aggressive option boards
15. stop and ask the user whether to consolidate, strengthen, scaffold, choose stable mode, choose aggressive mode, or stop
16. if the synthesis or route boards are already usable, ask whether the user wants one more bounded optimization wave before freezing them
17. iterate on the discovered directions and their descriptions until the direction map is stable enough to support worker launch
18. write the current phase state and recommended user decision explicitly
19. scaffold project structure for multi-window work
20. create one dedicated prompt, folder contract, and task interface for each direction window
21. recommend how many windows to open, including optional refinement windows when hardware permits
22. stop and ask the user whether to proceed into worker launch or execution planning
23. if the user explicitly enables autonomous mode, record consent, scope boundaries, token-cost acknowledgement, and manual stop conditions before any hands-off progression begins
24. in autonomous mode, keep iterating toward the strongest reachable in-scope result until the approved stop conditions or saturation conditions are met
25. launch windows only after direction mapping, evidence grading, interface contracts, and user approval are stable
