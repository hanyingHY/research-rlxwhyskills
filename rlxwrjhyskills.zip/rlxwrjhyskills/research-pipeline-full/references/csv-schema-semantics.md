# CSV Schema Semantics

## Objective

Define not only the required CSV headers, but also what each field means so parallel windows produce consistently interpretable structured data.

## round_log.csv

- `round_id`: stable round identifier
- `search_question`: the exact question pursued in the round
- `query_set`: the search query family or compressed query description
- `candidate_count`: number of candidate items reviewed
- `retained_count`: number of retained items after filtering
- `next_action`: what the next round should try

## source_index.csv

- `source_id`: local stable identifier
- `title`: exact source title
- `authors`: author or institution string
- `year`: publication, release, or document year
- `source`: journal, conference, series, or repository label
- `evidence_class`: reusable evidence taxonomy label such as quantitative, qualitative, policy, archival, implementation, or structured-note class
- `stable_link`: DOI or stable URL
- `direction`: one primary direction only
- `disposition`: approved disposition state

## evidence_matrix.csv

- `source_id`: foreign key into source index
- `evidence_class`: reusable evidence taxonomy label carried forward from the source layer
- `claim`: claim precise enough to adjudicate
- `study_context`: domain, environment, population, or universe actually studied
- `evaluation_scope`: prediction horizon, intervention scope, operating regime, or analogous evaluation frame
- `evidence_strength`: confidence or grade label
- `transferability`: how well the evidence transfers to the target task
- `implementation_value`: practical usefulness if retained

## experiment_hypotheses.csv

- `hypothesis_id`: stable local hypothesis identifier
- `mapped_category`: signal or feature, rule or filter, target or label, model or method, routing or control logic, output or selection layer, validation design, or explicit rejection
- `claim`: retained claim being mapped forward
- `validation_placeholder`: future validation or experiment stub
- `priority`: immediate, dependent, or deferred

## ingestion_log.csv

- `timestamp`: time the item was classified or dispositioned
- `item_name`: original file or item name
- `source_path`: original intake location
- `primary_direction`: single primary routing bucket
- `secondary_tags`: optional supporting tags
- `disposition`: retain, reject, quarantine, or review state
- `reason`: why the disposition was applied

## search_trace_log.csv

- `worker`: worker folder that ran the search round
- `direction_hint`: coarse direction or lane label inferred from the worker role
- `round_id`: stable local round identifier from the worker round log
- `search_question`: exact question pursued in that round
- `query_set`: query family or compressed query description
- `candidate_count`: number of candidate items reviewed in the round
- `retained_count`: number of retained items that survived filtering
- `next_action`: what the worker planned next after the round
- `source_file`: relative path of the originating worker round log

## source_authority_log.csv

- `source_id`: stable source identifier when available
- `title`: exact source title
- `authors`: author or institution string
- `year`: publication or release year
- `source`: journal, conference, repository, or organization label
- `evidence_class`: reusable evidence taxonomy label for the source material class
- `stable_link`: DOI or stable URL
- `directions_seen`: comma-separated directions or lanes that used the source
- `workers_seen`: comma-separated worker folders that referenced the source
- `authority_assessment`: explicit authority judgment using the authority ladder
- `verification_status`: pending_review, verified, contradicted, downgraded, or similar operator state
- `external_verdict`: short result from external confirmation or contradiction work
- `disposition`: retained or rejected disposition after authority review
- `notes`: operator notes that explain caveats, overrides, or unresolved trust issues

## credibility_summary.csv

- `label`: human-readable label for the scored item
- `route_id`: stable route identifier used to join research credibility to implementation maturity; do not substitute `route_board`
- `direction`: direction linked to the scored item
- `route_board`: stable or aggressive board association when available
- `claim_scope`: signal, routing, validation, or other mapped scope
- `source_id`: linked source identifier when available
- `claim_id`: linked claim identifier when available
- `credibility_score_35`: total score across the seven credibility dimensions
- `credibility_band`: weak, caveated, actionable, or high_confidence
- `source_authority`: dimension score copied from the underlying credibility report
- `task_directness`: dimension score copied from the underlying credibility report
- `empirical_strength`: dimension score copied from the underlying credibility report
- `transfer_risk`: dimension score copied from the underlying credibility report
- `reproducibility_readiness`: dimension score copied from the underlying credibility report
- `contradiction_burden`: dimension score copied from the underlying credibility report
- `validation_readiness`: dimension score copied from the underlying credibility report
- `report_path`: relative path to the underlying JSON credibility artifact
