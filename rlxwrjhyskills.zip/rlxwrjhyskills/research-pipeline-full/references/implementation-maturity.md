# Implementation Maturity

## Purpose

Keep research credibility and code readiness separate. A strong paper or claim can justify a validation placeholder, but it cannot make immature code execution-ready.

## Assessment dimensions

Score each dimension from `0` to `4` using recorded artifacts rather than confidence language:

1. traceability from retained claims to active components
2. implementation completeness
3. runnability in a declared environment
4. automated verification
5. reproducibility and benchmark linkage
6. operational or delivery readiness

Normalize the six equally weighted dimensions to `implementation_score_100`. Apply the level prerequisites in `implementation-maturity-model.json`; never assign a level from the average alone when a prerequisite fails.

## Evidence rules

1. Treat a discovered path as static evidence, not proof that it runs.
2. Record build, test, smoke, benchmark, and reproduction commands only after they actually run.
3. Run only project-declared or user-confirmed non-destructive verification commands; never invent or execute an arbitrary shell command merely to raise the score.
4. Use `not_run` when the environment cannot execute a check.
5. Treat failed integrity, leakage, point-in-time, backtest-integrity, or output-contract checks as critical blockers when the active profile requires them.
6. Do not let a high research score offset a failed implementation gate.

## Stage gates

1. research retention or validation placeholder: `M0`
2. experiment execution: `M2`
3. result promotion: `M3`
4. benchmark freeze: `M4`
5. release: `M5`

## Route identity rule

Use `route_id` as the durable join key between credibility records, code inventory, implementation evidence, and the joint readiness matrix. `route_board` only labels a route as stable or aggressive; it is never a substitute for `route_id`.

For research retention and validation placeholders, an unmapped credibility record may remain visible as research-only. Before experiment execution, result promotion, benchmark freeze, or release, at least one explicit `route_id` mapping is required. If credibility records exist but all omit `route_id`, record `mapping_required`, create a backlog task, and block advancement without discarding the research conclusion.

## Engineering authority

By default, audit the implementation and write executable backlog tasks. Do not modify project business code unless the user explicitly authorizes engineering work.

Each backlog task should name the route, owned scope, gap, proposed change, verification command, expected artifact, acceptance criteria, priority, and status.

## Profiles

Use `generic` unless the project is clearly quantitative research. Use `quant-research` when the implementation includes strategies, factors, backtests, temporal datasets, or benchmark route selection. Keep the selected profile visible in the readiness report.
