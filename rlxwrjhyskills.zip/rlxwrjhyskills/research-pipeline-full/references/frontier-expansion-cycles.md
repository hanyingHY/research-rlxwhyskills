# Frontier Expansion Cycles

## Objective

Turn a vague request for "search more sources" into a bounded, auditable frontier-expansion program.

## Default cycle structure

## User-controlled escalation rule

Do not treat one completed search wave as proof that the search is saturated.

After each bounded discovery pass, each deep-search cycle block, and each global follow-up block:

1. summarize what changed
2. ask the user whether the search depth is sufficient
3. if the user is dissatisfied or explicitly asks for more, increase search effort instead of stopping
4. record which escalation level is active before the next wave starts

Default escalation ladder:

1. `level_0_initial`: current bounded wave only
2. `level_1_broaden_queries`: expand query variation, synonyms, adjacent terminology, and source families
3. `level_2_broaden_directions`: keep the same core objective but add adjacent directions or weaker-but-plausible branches
4. `level_3_deepen_rounds`: increase round budget per direction and allow more deep cycles
5. `level_4_frontier_saturation`: allow very broad frontier search until marginal retained evidence is near zero and the user agrees to stop

Escalation intent should be explicit, not inferred silently.

### Stage 1: direction discovery

For each active direction:

1. run `10` discovery rounds
2. record the search question, query set, candidate set, retained sources, and next action each round
3. score the direction before any long deep-dive starts
4. stop and ask whether the user wants another discovery wave before promotion or pruning decisions are finalized

### Stage 2: deep search cycles

For each promoted direction:

1. run deep retrieval in cycles of `50` search or retrieval rounds
2. allow up to `10` deep cycles per direction
3. stop early if two consecutive cycles add no retained evidence or do not change the direction judgment
4. after each deep-cycle block, ask whether the user wants more depth, broader breadth, or no further search on that direction

### Stage 3: global follow-up minimum

Across the best directions:

1. run at least `20` additional follow-up cycles of `50` rounds each
2. stop only when the coordinator confirms that marginal evidence no longer changes ranking, adjudication, or validation priorities
3. if the user still believes the search is thin, widen the breadth before declaring saturation

## Promotion thresholds

After discovery, promote only when the average score on these dimensions is `>= 4.0`:

1. objective relevance
2. directness to the target domain or decision environment
3. evidence strength
4. implementation feasibility
5. expected upside

## Saturation stop rule

Declare a direction saturated only when all are true:

1. new rounds produce mainly duplicates or weaker restatements
2. conflict adjudication is stable
3. retained claims no longer change the validation slate
4. new evidence does not improve task directness or authority level
5. the user does not request another escalation wave

## What not to do

1. do not launch all directions directly into 50-round deep search
2. do not keep searching a weak direction just to satisfy a quota
3. do not count retrieval volume as progress unless retained evidence changed
