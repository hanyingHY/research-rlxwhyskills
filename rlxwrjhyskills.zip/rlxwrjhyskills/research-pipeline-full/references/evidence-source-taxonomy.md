# Evidence Source Taxonomy

## Objective

Provide a reusable evidence-class vocabulary for research programs that mix quantitative, qualitative, normative, archival, implementation, and synthetic materials.

## Core evidence classes

1. `quantitative_experimental`
   - controlled experiments, benchmark evaluations, randomized studies, ablation tables
2. `quantitative_observational`
   - logs, telemetry, panels, observational datasets, descriptive analytics
3. `qualitative_interview_or_transcript`
   - interviews, oral histories, transcripts, structured testimony
4. `survey_or_questionnaire`
   - survey exports, questionnaires, polling instruments, coded response summaries
5. `policy_or_compliance_document`
   - policies, regulations, standards, governance frameworks, requirements documents
6. `archival_or_record_source`
   - archival records, meeting minutes, registries, correspondence, historical records
7. `implementation_or_analysis_code`
   - code, notebooks, executable analysis pipelines, operational logic
8. `config_schema_or_structured_text`
   - schemas, configs, structured metadata, machine-readable definitions
9. `markdown_research_note`
   - summaries, working notes, drafts, human-authored synthesis artifacts
10. `general_text_like_research_material`
    - mixed text material that still needs finer classification

## Handling guidance

1. `quantitative_experimental`
   - prioritize task fit, metric definition, benchmark comparability, and reproducibility
2. `quantitative_observational`
   - prioritize provenance, sampling bias, missingness, and temporal leakage risk
3. `qualitative_interview_or_transcript`
   - extract claim bundles, speaker scope, contradiction burden, and transfer limits
4. `survey_or_questionnaire`
   - inspect instrument design, respondent population, coding assumptions, and aggregation loss
5. `policy_or_compliance_document`
   - extract operative constraints, jurisdiction or scope, update cadence, and conflict hierarchy
6. `archival_or_record_source`
   - inspect provenance chain, date meaning, record completeness, and retrospective bias
7. `implementation_or_analysis_code`
   - map logic to claims, inputs, outputs, hidden assumptions, and active versus stale usage
8. `config_schema_or_structured_text`
   - inspect schema semantics, default values, version drift, and downstream dependency risk
9. `markdown_research_note`
   - treat as synthesis or hypothesis until cross-checked against stronger evidence
10. `general_text_like_research_material`
    - classify further before promotion into core retained evidence

## Conflict rule

Do not adjudicate conflicts only by source class.

Use evidence class as one comparison dimension alongside:

1. directness to the target task
2. empirical strength
3. reproducibility readiness
4. authority and provenance
5. transfer risk

## Promotion rule

Mixed-evidence projects are normal.

Do not force every direction to rely on one evidence class only. Instead, record:

1. which evidence classes support the direction
2. which class carries the strongest decision weight
3. where the main uncertainty still sits
