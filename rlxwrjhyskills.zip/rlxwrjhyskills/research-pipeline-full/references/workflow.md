# Full Workflow

## Objective

Run research as a controlled system that produces auditable decisions, explicit evidence governance, and executable or validation-ready plans.

## Stages

### 1. Stabilize

1. inventory existing files
2. identify stale and active outputs
3. define the current decision objective
4. identify what is intake, what is judgment, and what is already synthesis
5. if the workspace already exists and is only partly complete, ask whether to continue, repair, rebuild generated scaffold artifacts while keeping the raw corpus, or stop
6. if the project is just a loose pile of text or literature, bootstrap a reusable intake and evidence structure before deeper audit begins

### 2. Intake and triage

1. register every source once
2. assign one primary topic or direction
3. mark duplicates, support material, and weak sources
4. decide whether material is retain, reject, quarantine, or needs manual review

### 3. Discovery rounds

When the user wants broad frontier expansion, begin with bounded discovery rather than unconstrained deep search.

Default rule:

1. each active direction or worker runs a `10`-round discovery pass
2. score the direction before allowing long deep-dive cycles
3. only strong directions continue
4. stop for a user decision gate before moving from discovery into deep search
5. after the discovery summary, ask whether the user wants another search wave; if the user says the search is too thin, increase breadth and/or rounds before finalizing direction judgments

### 4. Evidence judgment

1. extract claims precisely
2. record sample, method, and scope
3. grade strength and transferability
4. record why weak evidence was downgraded

### 5. Conflict handling

1. detect contradiction at the claim level
2. compare domain, evaluation scope, dataset, and method
3. write an explicit adjudication result
4. state what remains unresolved

### 6. Deep retrieval cycles

For directions that qualify after discovery:

1. run deep retrieval in bounded cycles, not infinite searching
2. stop when new rounds no longer change retained evidence or direction ranking
3. escalate only when the marginal evidence is still useful
4. stop for a user decision gate before moving from deep search into structure setup or execution planning
5. after each deep-cycle block, ask whether the user wants further search; if the user is unsatisfied, widen the source family, query family, or cycle budget instead of silently stopping

### 6A. Focused strengthening

When the user chooses strengthen mode:

1. ask what should be strengthened first
2. allow the target to be a direction, dataset, paper, claim bundle, or source family such as interviews, surveys, policy sets, archival records, or stakeholder materials
3. record the strengthening target explicitly before broadening the search surface
4. keep the strengthening pass aligned to those explicit targets
5. when a strengthening wave ends, ask whether the user wants another strengthening wave at a higher search depth or wider source scope

### 6B. Bounded optimization recheck

In non-autonomous mode:

1. when a phase reaches a usable level, ask whether the user wants one more bounded optimization wave before freezing the phase
2. treat `optimize_more` as a targeted quality-improvement pass inside the current phase, not as permission to silently jump into the next phase
3. after that bounded optimization wave, ask again whether the current result is now strong enough or whether another explicit choice is needed

### 7. Synthesis

1. rank directions
2. decide what advances now
3. name what remains unproven
4. separate immediate, dependent, and deferred routes
5. split the retained route board into stable and aggressive option sets after the full search surface is understood

### 8. Validation planning

1. convert retained claims into validation schemes or explicit validation placeholders
2. separate immediate, dependent, and deferred jobs
3. define metrics, benchmarks, and promotion rules
4. stop for a user decision gate before moving from validation planning into engineering or experiment launch

### 8A. Autonomous execution mode

Only if the user explicitly opts in:

1. record visible user consent and scope boundaries
2. record mandatory manual stop conditions before autonomy starts
3. keep evidence grading, conflict adjudication, and validation logic fully intact
4. stop again when a new scope jump, destructive action, or board-choice decision appears
5. warn explicitly that token consumption may increase because the agent will keep iterating until the approved stop conditions are met
6. keep pushing toward the strongest reachable in-scope result instead of settling for a merely acceptable pass
7. prefer research-quality improvements over further structure beautification once the structure is sufficient to continue safely

### 9. Benchmark freeze

Freeze the current best low-cost baseline before heavy execution starts.

### 10. Post-run comparison

Compare execution outputs against:

1. frozen benchmark
2. original retained claims
3. stability requirements

## Search recheck rule

Every bounded search wave must end with:

1. what changed
2. what still feels thin
3. a direct user choice:
   - stop search here
   - search deeper on the same direction
   - search wider across more sources or related directions
   - search both deeper and wider

If the user says the search is not deep enough, do not end the program just because the default round block is complete.
