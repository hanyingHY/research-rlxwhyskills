#!/usr/bin/env python3
"""Synchronize user-facing decision surfaces for a full research workspace."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True

from local_runtime import python_command, run_json


STRENGTHENING_COLUMNS = ["focus_type", "focus_name", "strengthen_goal", "evidence_gap", "preferred_action", "priority", "notes"]
DIRECTION_DEPTH_COLUMNS = ["direction", "selected_state", "depth_profile", "allowed_round_budget", "allowed_cycle_budget", "notes"]
SEARCH_ESCALATION_COLUMNS = ["escalation_level", "stage", "direction_scope", "scope_change", "round_change", "source_family_change", "trigger_reason", "user_state", "notes"]
SEARCH_MODE_COLUMNS = ["phase_scope", "recommended_search_mode", "approved_search_mode", "local_project_corpus", "model_prior_knowledge", "external_literature_search", "user_choice_state", "notes"]
WINDOW_MODE_COLUMNS = ["stage", "recommended_mode", "recommended_window_count", "single_window_path", "multi_window_path", "user_assistance_required", "notes"]
SEARCH_TRACE_COLUMNS = ["worker", "direction_hint", "round_id", "search_question", "query_set", "candidate_count", "retained_count", "next_action", "source_file"]
SOURCE_AUTHORITY_COLUMNS = ["source_id", "title", "authors", "year", "source", "evidence_class", "stable_link", "directions_seen", "workers_seen", "authority_assessment", "verification_status", "external_verdict", "disposition", "notes"]
CREDIBILITY_SUMMARY_COLUMNS = ["label", "route_id", "direction", "route_board", "claim_scope", "source_id", "claim_id", "credibility_score_35", "credibility_band", "source_authority", "task_directness", "empirical_strength", "transfer_risk", "reproducibility_readiness", "contradiction_burden", "validation_readiness", "report_path"]


def main() -> None:
    parser = argparse.ArgumentParser(description="Sync decision surfaces for a full research workspace")
    parser.add_argument("--workspace-root", required=True)
    parser.add_argument("--source-project-root")
    parser.add_argument("--profile", default="generic")
    parser.add_argument("--overwrite-generated", action="store_true")
    args = parser.parse_args()

    workspace_root = Path(args.workspace_root).resolve()
    source_project_root = Path(args.source_project_root).resolve() if args.source_project_root else None

    audit = run_json([
        *python_command(
            Path(__file__).resolve().parent / "assess_workspace_progress.py",
            "--workspace-root",
            workspace_root,
        )
    ])
    source_markers = detect_partial_markers(source_project_root) if source_project_root else None
    inventory = collect_top_level_inventory(source_project_root)
    strengthening_rows = recommend_strengthening_rows(inventory)
    direction_rows = recommend_direction_rows(inventory)
    search_mode_rows = recommend_search_mode_rows(audit, inventory)
    search_escalation_rows = recommend_search_escalation_rows(audit, direction_rows)
    window_mode_rows = recommend_window_mode_rows(audit, direction_rows, inventory)
    search_trace_rows = collect_search_trace_rows(workspace_root)
    source_authority_rows = collect_source_authority_rows(workspace_root)
    credibility_summary_rows = collect_credibility_summary_rows(workspace_root)

    write_text(workspace_root / "06_reports" / "REENTRY_DECISION.md", build_reentry_decision(audit, source_project_root, source_markers), args.overwrite_generated)
    write_text(workspace_root / "06_reports" / "NEXT_USER_DECISION.md", build_next_user_decision(audit, strengthening_rows, direction_rows), args.overwrite_generated)
    write_text(workspace_root / "00_protocol" / "PHASE_STATE.md", build_phase_state(audit), args.overwrite_generated)
    write_text(workspace_root / "00_protocol" / "CHECKPOINT_RESPONSE_LOG.md", build_checkpoint_response_log(audit), args.overwrite_generated)
    write_text(workspace_root / "01_window_runs" / "W01_coordinator" / "coordinator_log.md", build_coordinator_log(audit, strengthening_rows, direction_rows), args.overwrite_generated)

    write_text(workspace_root / "06_reports" / "FOCUSED_STRENGTHENING_SELECTION.md", build_focused_strengthening_selection(strengthening_rows), args.overwrite_generated)
    write_csv_rows(workspace_root / "06_reports" / "FOCUSED_STRENGTHENING_PLAN.csv", STRENGTHENING_COLUMNS, strengthening_rows, args.overwrite_generated)

    write_text(workspace_root / "06_reports" / "DIRECTION_SELECTION.md", build_direction_selection(direction_rows), args.overwrite_generated)
    write_text(workspace_root / "06_reports" / "DEEP_DIVE_SELECTION.md", build_deep_dive_selection(direction_rows), args.overwrite_generated)
    write_csv_rows(workspace_root / "06_reports" / "DIRECTION_DEPTH_PLAN.csv", DIRECTION_DEPTH_COLUMNS, build_direction_depth_rows(direction_rows), args.overwrite_generated)
    write_text(workspace_root / "06_reports" / "SEARCH_MODE_SELECTION.md", build_search_mode_selection(search_mode_rows), args.overwrite_generated)
    write_csv_rows(workspace_root / "06_reports" / "SEARCH_MODE_PLAN.csv", SEARCH_MODE_COLUMNS, search_mode_rows, args.overwrite_generated)
    write_text(workspace_root / "06_reports" / "SEARCH_ESCALATION_SELECTION.md", build_search_escalation_selection(search_escalation_rows), args.overwrite_generated)
    write_csv_rows(workspace_root / "06_reports" / "SEARCH_ESCALATION_PLAN.csv", SEARCH_ESCALATION_COLUMNS, search_escalation_rows, args.overwrite_generated)
    write_text(workspace_root / "06_reports" / "STAGE_WINDOW_GUIDANCE.md", build_stage_window_guidance(window_mode_rows), args.overwrite_generated)
    write_text(workspace_root / "06_reports" / "WINDOW_MODE_SELECTION.md", build_window_mode_selection(window_mode_rows), args.overwrite_generated)
    write_csv_rows(workspace_root / "06_reports" / "WINDOW_MODE_PLAN.csv", WINDOW_MODE_COLUMNS, window_mode_rows, args.overwrite_generated)

    write_csv_rows(workspace_root / "12_ingestion_logs" / "search_trace_log.csv", SEARCH_TRACE_COLUMNS, search_trace_rows, True)
    write_csv_rows(workspace_root / "12_ingestion_logs" / "source_authority_log.csv", SOURCE_AUTHORITY_COLUMNS, source_authority_rows, True)
    write_csv_rows(workspace_root / "06_reports" / "credibility" / "credibility_summary.csv", CREDIBILITY_SUMMARY_COLUMNS, credibility_summary_rows, True)

    result = {
        "workspace_root": str(workspace_root),
        "source_project_root": str(source_project_root) if source_project_root else None,
        "audit_status": audit["status"],
        "reentry_recommended_default": reentry_default(source_markers),
        "next_user_default": next_user_default(audit["status"]),
        "strengthening_target_count": len(strengthening_rows),
        "direction_candidate_count": len(direction_rows),
        "search_mode_count": len(search_mode_rows),
        "search_escalation_count": len(search_escalation_rows),
        "window_mode_count": len(window_mode_rows),
        "search_trace_row_count": len(search_trace_rows),
        "source_authority_row_count": len(source_authority_rows),
        "credibility_summary_row_count": len(credibility_summary_rows),
        "status": "ready",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))

def detect_partial_markers(project_root: Path | None) -> dict | None:
    if not project_root:
        return None
    full_markers = ["00_protocol", "01_window_runs", "05_master_tables", "06_reports"]
    lite_markers = ["00_raw", "01_index", "02_retained", "03_output"]
    full_present = [item for item in full_markers if (project_root / item).exists()]
    lite_present = [item for item in lite_markers if (project_root / item).exists()]
    return {
        "partial_full_workspace_detected": len(full_present) >= 2 and len(full_present) < len(full_markers),
        "partial_lite_workspace_detected": len(lite_present) >= 2 and len(lite_present) < len(lite_markers),
        "partial_full_markers_present": full_present,
        "partial_lite_markers_present": lite_present,
    }


def collect_top_level_inventory(project_root: Path | None) -> dict:
    if not project_root or not project_root.exists():
        return {"dirs": [], "files": [], "all_names": []}
    dirs = sorted(path.name for path in project_root.iterdir() if path.is_dir())
    files = sorted(path.name for path in project_root.iterdir() if path.is_file())
    return {"dirs": dirs, "files": files, "all_names": [*dirs, *files]}


def names_match(names: list[str], keywords: list[str]) -> list[str]:
    matches: list[str] = []
    for name in names:
        lowered = name.lower()
        if any(keyword in lowered for keyword in keywords):
            matches.append(name)
    return matches


def reentry_default(source_markers: dict | None) -> str:
    if not source_markers:
        return "continue_current_workspace"
    if source_markers.get("partial_full_workspace_detected") or source_markers.get("partial_lite_workspace_detected"):
        return "rebuild_generated_scaffold_keep_raw_corpus"
    return "continue_current_workspace"


def next_user_default(audit_status: str) -> str:
    if audit_status in {"structural_only", "evidence_building"}:
        return "strengthen"
    if audit_status == "decision_ready":
        return "consolidate"
    if audit_status == "launch_candidate":
        return "choose_stable_mode"
    return "consolidate"


def phase_state_for_status(audit_status: str) -> tuple[str, str, str, str]:
    if audit_status == "structural_only":
        return ("audit_ready", "pending_user_decision", "workspace scaffold is initialized", "evidence intake, retained evidence, and route ranking are not ready")
    if audit_status == "evidence_building":
        return ("audit_ready", "ready_to_strengthen", "initial evidence intake has started", "route ranking and validation mapping are not ready")
    if audit_status == "decision_ready":
        return ("direction_map_ready", "ready_to_consolidate", "the workspace can support a user-facing decision", "launch-level execution is not ready")
    if audit_status == "launch_candidate":
        return ("validation_plan_ready", "ready_to_proceed", "validation planning and decision surfaces are ready", "explicit execution approval is still required")
    return ("audit_ready", "pending_user_decision", "pending", "pending")


def build_reentry_decision(audit: dict, source_project_root: Path | None, source_markers: dict | None) -> str:
    current_state_lines = [
        f"- workspace_status: `{audit['status']}`",
        f"- quality_score_100: `{audit['quality_score_100']}`",
        f"- critical_blocker_count: `{audit['critical_blocker_count']}`",
    ]
    if source_project_root:
        current_state_lines.append(f"- source_project_root: `{source_project_root}`")
    if source_markers and source_markers.get("partial_full_workspace_detected"):
        current_state_lines.append(f"- partial_full_markers_present: `{', '.join(source_markers['partial_full_markers_present'])}`")
    if source_markers and source_markers.get("partial_lite_workspace_detected"):
        current_state_lines.append(f"- partial_lite_markers_present: `{', '.join(source_markers['partial_lite_markers_present'])}`")

    notes = []
    if source_markers and (source_markers.get("partial_full_workspace_detected") or source_markers.get("partial_lite_workspace_detected")):
        notes.append("A partial workspace was detected in the source project. Rebuild is the recommended default when you want the generated scaffold refreshed without deleting the raw corpus.")
    else:
        notes.append("No partial source workspace markers were detected. Continue is the recommended default unless the generated scaffold itself is stale or inconsistent.")

    return "\n".join([
        "# Reentry Decision",
        "",
        "## Purpose",
        "",
        "Make the user choose how to handle an existing scaffolded or partially completed workspace.",
        "",
        "## Current Workspace State",
        "",
        *current_state_lines,
        "",
        "## Recommended Default",
        "",
        reentry_default(source_markers),
        "",
        "## Options",
        "",
        "1. continue_current_workspace",
        "2. repair_current_workspace",
        "3. rebuild_generated_scaffold_keep_raw_corpus",
        "4. stop",
        "",
        "## User Decision",
        "",
        "",
        "## Notes",
        "",
        *[f"- {note}" for note in notes],
        "",
        "```text",
        "This workspace already exists. Please choose whether to continue it, repair it in place, rebuild generated scaffold artifacts while keeping the raw corpus, or stop.",
        "```",
        "",
    ])


def build_next_user_decision(audit: dict, strengthening_rows: list[dict[str, str]], direction_rows: list[dict[str, str]]) -> str:
    blockers = audit.get("blockers", [])[:5]
    strengths = audit.get("strengths", [])[:5]
    ready_lines = [f"- {item}" for item in strengths] if strengths else ["- workspace scaffold and control surfaces are initialized"]
    not_ready_lines = [f"- {item}" for item in blockers] if blockers else ["- no major blockers recorded"]
    strengthening_lines = [f"- `{row['focus_name']}`" for row in strengthening_rows[:3]] or ["- no recommended strengthening targets inferred automatically"]
    direction_lines = [f"- `{row['direction']}`" for row in direction_rows[:3]] or ["- no recommended directions inferred automatically"]
    implementation_blocked = audit.get("implementation_summary", {}).get("blocked_route_count", 0) > 0
    recommended_default = "repair_implementation_before_promotion" if implementation_blocked else next_user_default(audit["status"])
    return "\n".join([
        "# Next User Decision",
        "",
        "## Current Gate",
        "",
        "A",
        "",
        "## What Is Ready",
        "",
        *ready_lines,
        "",
        "## What Is Not Ready",
        "",
        *not_ready_lines,
        "",
        "## Recommended Default",
        "",
        recommended_default,
        "",
        "## Recommended Options",
        "",
        "1. consolidate",
        "2. optimize_more",
        "3. strengthen",
        "4. search_more",
        "5. repair_implementation_before_promotion",
        "6. choose_stable_mode",
        "7. choose_aggressive_mode",
        "8. proceed",
        "9. stop",
        "",
        "## User Decision",
        "",
        "",
        "## Notes For User",
        "",
        f"- current_workspace_status: `{audit['status']}`",
        f"- quality_band: `{audit['quality_band']}`",
        "- if you choose optimize_more, run one more bounded quality-improvement wave inside the current phase before freezing it",
        "- if you choose strengthen, specify which directions, datasets, papers, claim bundles, or source families should be reinforced first",
        "- if you choose search_more, specify whether the next wave should go broader, deeper, or both",
        "- choose repair_implementation_before_promotion when a route fails its target-stage implementation gate; generate backlog tasks before changing business code",
        "- if deep work is proposed later, record explicit direction, depth, and budget choices before long deep cycles begin",
        "- before the next major stage starts, review the window-mode recommendation and confirm whether single-window or multi-window work should be used",
        "- recommended strengthening targets:",
        *strengthening_lines,
        "- recommended directions:",
        *direction_lines,
        "",
    ])


def build_phase_state(audit: dict) -> str:
    current_phase, state_status, ready_now, not_ready = phase_state_for_status(audit["status"])
    implementation_blocked = audit.get("implementation_summary", {}).get("blocked_route_count", 0) > 0
    recommended_default = "repair_implementation_before_promotion" if implementation_blocked else next_user_default(audit["status"])
    return "\n".join([
        "# Phase State",
        "",
        f"current_phase: {current_phase}",
        "current_gate: A",
        f"state_status: {state_status}",
        f"ready_now: {ready_now}",
        f"not_ready: {not_ready}",
        f"recommended_default: {recommended_default}",
        "allowed_next_actions: consolidate, optimize_more, strengthen, search_more, repair_implementation_before_promotion, choose_stable_mode, choose_aggressive_mode, proceed, stop",
        f"blocking_conditions: {audit['critical_blocker_count']} blocker(s) currently recorded",
        "",
    ])


def build_checkpoint_response_log(audit: dict) -> str:
    notes = "; ".join(audit.get("blockers", [])[:3]) or "no major notes yet"
    return "\n".join([
        "# Checkpoint Response Log",
        "",
        "| Gate | Current State | Recommended Next Step | User Decision | Notes |",
        "|---|---|---|---|---|",
        f"| A | {audit['status']} | {next_user_default(audit['status'])} | pending | {notes} |",
        "| B | pending | pending | pending | |",
        "| C | pending | pending | pending | |",
        "| D | pending | pending | pending | |",
        "",
        "## Usage",
        "",
        "Update this file whenever the coordinator stops at a major phase boundary and asks the user whether to consolidate, optimize_more, strengthen, choose a route board when applicable, proceed, or stop.",
        "",
    ])


def build_coordinator_log(audit: dict, strengthening_rows: list[dict[str, str]], direction_rows: list[dict[str, str]]) -> str:
    ready_lines = [f"- {item}" for item in audit.get("strengths", [])[:5]] or ["- workspace scaffold is initialized"]
    not_ready_lines = [f"- {item}" for item in audit.get("blockers", [])[:5]] or ["- no major blockers recorded"]
    strengthening_lines = [f"- `{row['focus_name']}`" for row in strengthening_rows[:3]] or ["- no recommended strengthening targets inferred automatically"]
    direction_lines = [f"- `{row['direction']}`" for row in direction_rows[:3]] or ["- no recommended directions inferred automatically"]
    return "\n".join([
        "# Coordinator Log",
        "",
        "## Current Phase",
        "",
        phase_state_for_status(audit["status"])[0],
        "",
        "## Ready Now",
        "",
        *ready_lines,
        "",
        "## Not Ready",
        "",
        *not_ready_lines,
        "",
        "## Recommended Next User Decision",
        "",
        next_user_default(audit["status"]),
        "",
        "## Notes",
        "",
        f"- quality_score_100: `{audit['quality_score_100']}`",
        f"- quality_band: `{audit['quality_band']}`",
        f"- critical_blocker_count: `{audit['critical_blocker_count']}`",
        "- recommended strengthening targets:",
        *strengthening_lines,
        "- recommended directions:",
        *direction_lines,
        "",
    ])


def recommend_strengthening_rows(inventory: dict) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []

    decision_matches = names_match(inventory["all_names"], ["decision", "strategy", "summary", "route", "benchmark", "playbook"])
    if decision_matches:
        rows.append({
            "focus_type": "claim_bundle",
            "focus_name": "strategy-and-decision-summaries",
            "strengthen_goal": "verify project-level strategy and decision summaries against retained evidence and active code paths",
            "evidence_gap": "high-level summaries may not align with the latest retained evidence or implementation state",
            "preferred_action": "audit_claim_bundle",
            "priority": "high",
            "notes": f"Matched top-level items: {', '.join(decision_matches[:5])}",
        })

    dataset_matches = names_match(inventory["all_names"], ["dataset", "data", "csv", "parquet", "panel", "scholar"])
    if dataset_matches:
        rows.append({
            "focus_type": "dataset",
            "focus_name": "dataset-and-source-governance",
            "strengthen_goal": "clarify dataset coverage, provenance, and active usage paths",
            "evidence_gap": "dataset semantics and active usage are not yet synchronized into the new workspace",
            "preferred_action": "inventory_and_map",
            "priority": "high",
            "notes": f"Matched top-level items: {', '.join(dataset_matches[:5])}",
        })

    research_matches = names_match(inventory["all_names"], ["research", "study", "note", "literature", "audit", "program", "process"])
    if research_matches:
        rows.append({
            "focus_type": "direction",
            "focus_name": "historical-research-reconciliation",
            "strengthen_goal": "classify and reconcile historical research notes into active versus stale tracks",
            "evidence_gap": "historical notes likely contain mixed-vintage conclusions and inconsistent confidence levels",
            "preferred_action": "classify_and_reconcile",
            "priority": "high",
            "notes": f"Matched top-level items: {', '.join(research_matches[:5])}",
        })

    rules_matches = names_match(inventory["all_names"], ["guide", "handbook", "manual", "submission", "checklist", "faq", "rule"])
    if rules_matches:
        rows.append({
            "focus_type": "paper",
            "focus_name": "rules-and-deliverable-constraints",
            "strengthen_goal": "verify operator assumptions against the latest authoritative rules and deliverable constraints",
            "evidence_gap": "execution assumptions may drift from official constraint documents",
            "preferred_action": "reconfirm_authoritative_rules",
            "priority": "medium",
            "notes": f"Matched top-level items: {', '.join(rules_matches[:5])}",
        })

    policy_matches = names_match(inventory["all_names"], ["policy", "regulation", "standard", "compliance", "governance", "requirement", "framework", "guideline"])
    if policy_matches:
        rows.append({
            "focus_type": "source_family",
            "focus_name": "policy-and-compliance-interpretation",
            "strengthen_goal": "reconcile policy, regulatory, standard, and compliance materials into explicit usable constraints",
            "evidence_gap": "normative documents may exist but their operative constraints are not yet normalized into the active decision program",
            "preferred_action": "extract_constraints_and_map",
            "priority": "high",
            "notes": f"Matched top-level items: {', '.join(policy_matches[:5])}",
        })

    qualitative_matches = names_match(inventory["all_names"], ["interview", "transcript", "survey", "questionnaire", "stakeholder", "persona", "user-research", "user_research", "ux", "ethnography", "fieldnote", "field-note", "observation"])
    if qualitative_matches:
        rows.append({
            "focus_type": "source_family",
            "focus_name": "qualitative-evidence-and-user-insight",
            "strengthen_goal": "structure qualitative findings, stakeholder testimony, and user insight into explicit claim bundles and evidence limits",
            "evidence_gap": "qualitative materials may be present but not yet normalized into explicit retained claims, contradictions, and transfer limits",
            "preferred_action": "extract_claim_bundles",
            "priority": "high",
            "notes": f"Matched top-level items: {', '.join(qualitative_matches[:5])}",
        })

    archival_matches = names_match(inventory["all_names"], ["archive", "archival", "historical", "record", "registry", "minutes", "memoir", "correspondence", "catalog", "catalogue", "logbook"])
    if archival_matches:
        rows.append({
            "focus_type": "source_family",
            "focus_name": "archival-and-record-based-evidence",
            "strengthen_goal": "map archival or record-based material into traceable evidence, provenance, and temporal constraints",
            "evidence_gap": "record-based sources may be rich but their provenance, date semantics, and evidentiary limits are not yet normalized",
            "preferred_action": "provenance_and_timeline_audit",
            "priority": "medium",
            "notes": f"Matched top-level items: {', '.join(archival_matches[:5])}",
        })

    implementation_matches = names_match(inventory["all_names"], ["baseline", "model", "engine", "pipeline", "app", "src", "implementation", "service"])
    if implementation_matches:
        rows.append({
            "focus_type": "direction",
            "focus_name": "active-implementation-audit",
            "strengthen_goal": "reconcile the active implementation surface with the documented research claims and current decision program",
            "evidence_gap": "code paths, summaries, and retained evidence may not yet be fully aligned",
            "preferred_action": "map_code_to_claims",
            "priority": "medium",
            "notes": f"Matched top-level items: {', '.join(implementation_matches[:5])}",
        })

    return rows


def recommend_direction_rows(inventory: dict) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []

    def add_row(direction: str, rationale: str, suggested_depth: str, priority: str, evidence_hint: str) -> None:
        rows.append({
            "direction": direction,
            "rationale": rationale,
            "suggested_depth": suggested_depth,
            "priority": priority,
            "evidence_hint": evidence_hint,
        })

    if names_match(inventory["all_names"], ["decision", "strategy", "summary", "route", "benchmark"]):
        add_row("strategy-claim-reconciliation", "Reconcile strategy summaries and route logic with the retained evidence base.", "standard_deep", "high", "Strategy and decision artifacts are present at the project root.")
    if names_match(inventory["all_names"], ["dataset", "data", "csv", "parquet", "panel", "scholar"]):
        add_row("dataset-governance-and-usage", "Map dataset coverage, provenance, and usage assumptions before deeper modeling work.", "standard_deep", "high", "Dataset-like assets are visible in the top-level inventory.")
    if names_match(inventory["all_names"], ["guide", "handbook", "manual", "submission", "checklist", "faq", "rule"]):
        add_row("rules-and-deliverable-constraints", "Reconfirm official rules, submission constraints, and reproducibility requirements.", "light_validate", "high", "Guide and submission-oriented documents are present.")
    if names_match(inventory["all_names"], ["policy", "regulation", "standard", "compliance", "governance", "requirement", "framework", "guideline"]):
        add_row("policy-and-compliance-interpretation", "Extract operative constraints from policy, standards, regulatory, or compliance materials.", "standard_deep", "high", "Policy or compliance-oriented materials are visible in the top-level inventory.")
    if names_match(inventory["all_names"], ["interview", "transcript", "survey", "questionnaire", "stakeholder", "persona", "user-research", "user_research", "ux", "ethnography", "fieldnote", "field-note", "observation"]):
        add_row("qualitative-evidence-and-user-insight", "Normalize interviews, surveys, stakeholder input, and qualitative findings into explicit claim bundles.", "standard_deep", "high", "Qualitative or user-research style assets are visible in the top-level inventory.")
    if names_match(inventory["all_names"], ["archive", "archival", "historical", "record", "registry", "minutes", "memoir", "correspondence", "catalog", "catalogue", "logbook"]):
        add_row("archival-and-record-based-evidence", "Audit archival or record-based material for provenance, temporal meaning, and evidentiary limits.", "light_validate", "medium", "Archive-like or record-oriented assets are visible in the top-level inventory.")
    if names_match(inventory["all_names"], ["research", "study", "note", "literature", "audit", "program", "process"]):
        add_row("historical-research-reconciliation", "Reconcile mixed-vintage research notes into active, deferred, and stale tracks.", "standard_deep", "medium", "Research-history style directories or files are present.")
    if names_match(inventory["all_names"], ["baseline", "model", "engine", "pipeline", "app", "src", "implementation", "service"]):
        add_row("active-implementation-audit", "Audit active code paths against the documented research and decision surfaces.", "light_validate", "medium", "Implementation-oriented directories or files are present.")

    return rows


def build_focused_strengthening_selection(rows: list[dict[str, str]]) -> str:
    candidate_lines = [f"- `{row['focus_type']}`: `{row['focus_name']}`" for row in rows] or ["- no recommended strengthening targets were inferred automatically"]
    recommended_lines = [f"- `{row['focus_name']}`: {row['strengthen_goal']}" for row in rows] or ["- no recommended strengthening targets were inferred automatically"]
    return "\n".join([
        "# Focused Strengthening Selection",
        "",
        "## Purpose",
        "",
        "Choose exactly which directions, datasets, papers, claim bundles, or source families should be strengthened before the program broadens.",
        "",
        "## Candidate Strengthening Targets",
        "",
        *candidate_lines,
        "",
        "## Recommended Targets",
        "",
        *recommended_lines,
        "",
        "## User Choice",
        "",
        "",
        "## Notes",
        "",
        "```text",
        "Please choose which directions, datasets, papers, claim bundles, or source families should be strengthened first, and record the reasons in the strengthening plan.",
        "```",
        "",
    ])


def build_direction_selection(rows: list[dict[str, str]]) -> str:
    candidate_lines = [f"- `{row['direction']}`: {row['rationale']}" for row in rows] or ["- no candidate directions were inferred automatically"]
    core_lines = [f"- `{row['direction']}`" for row in rows if row["priority"] == "high"] or ["- no core directions inferred automatically"]
    deferred_lines = [f"- `{row['direction']}`" for row in rows if row["priority"] != "high"] or ["- no deferred directions inferred automatically"]
    return "\n".join([
        "# Direction Selection",
        "",
        "## Purpose",
        "",
        "Choose which discovered directions move forward now instead of deepening every direction uniformly.",
        "",
        "## Candidate Directions",
        "",
        *candidate_lines,
        "",
        "## Recommended Core Directions",
        "",
        *core_lines,
        "",
        "## Recommended Deferred Directions",
        "",
        *deferred_lines,
        "",
        "## User-Added Directions",
        "",
        "",
        "## User Choice",
        "",
        "",
        "## Notes",
        "",
        "```text",
        "We finished direction discovery.",
        "",
        "Please choose:",
        "1. which directions move forward now",
        "2. which directions stay deferred",
        "3. which directions need strengthening before promotion",
        "4. any user-added directions that should enter the map",
        "```",
        "",
    ])


def recommend_search_escalation_rows(audit: dict, direction_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    if audit["status"] in {"structural_only", "evidence_building"}:
        rows.append({
            "escalation_level": "level_1_broaden_queries",
            "stage": "discovery",
            "direction_scope": "all_active_directions",
            "scope_change": "expand query wording, synonym families, and adjacent terminology",
            "round_change": "run another bounded search wave",
            "source_family_change": "keep current source families first",
            "trigger_reason": "current search depth may still be too thin",
            "user_state": "pending_user_choice",
            "notes": "Default first escalation when the user says the current search is insufficient.",
        })
    if direction_rows:
        rows.append({
            "escalation_level": "level_2_broaden_directions",
            "stage": "discovery",
            "direction_scope": "direction_map",
            "scope_change": "add adjacent or user-defined directions before locking the map",
            "round_change": "run another bounded discovery wave",
            "source_family_change": "include adjacent direction-specific source families",
            "trigger_reason": "direction set may still be incomplete",
            "user_state": "pending_user_choice",
            "notes": f"Current recommended directions: {', '.join(row['direction'] for row in direction_rows[:4])}",
        })
    return rows


def recommend_search_mode_rows(audit: dict, inventory: dict) -> list[dict[str, str]]:
    project_corpus_available = "yes" if inventory["all_names"] else "no"
    default_mode = "project_corpus_only" if project_corpus_available == "yes" else "knowledge_only"
    return [
        {
            "phase_scope": "initial_audit",
            "recommended_search_mode": default_mode,
            "approved_search_mode": "pending_user_choice",
            "local_project_corpus": project_corpus_available,
            "model_prior_knowledge": "yes",
            "external_literature_search": "optional",
            "user_choice_state": "pending",
            "notes": "Choose whether the audit should stay inside the current project corpus or allow outward literature search.",
        },
        {
            "phase_scope": "direction_discovery",
            "recommended_search_mode": "external_search_enabled" if audit["status"] in {"structural_only", "evidence_building"} else default_mode,
            "approved_search_mode": "pending_user_choice",
            "local_project_corpus": project_corpus_available,
            "model_prior_knowledge": "yes",
            "external_literature_search": "yes",
            "user_choice_state": "pending",
            "notes": "Discovery can use prior knowledge alone, the existing project corpus, or outward literature search depending on the user's tolerance for new external sources.",
        },
        {
            "phase_scope": "deep_search",
            "recommended_search_mode": "external_search_enabled",
            "approved_search_mode": "pending_user_choice",
            "local_project_corpus": project_corpus_available,
            "model_prior_knowledge": "yes",
            "external_literature_search": "yes",
            "user_choice_state": "pending",
            "notes": "Deep-search usually benefits from external literature, but the user may still constrain the program to existing knowledge or project corpus only.",
        },
    ]


def recommend_window_mode_rows(audit: dict, direction_rows: list[dict[str, str]], inventory: dict) -> list[dict[str, str]]:
    active_direction_count = len(direction_rows)
    large_inventory = len(inventory["all_names"]) >= 8
    return [
        {
            "stage": "audit_and_existing_content_review",
            "recommended_mode": "single_window" if not large_inventory else "multi_window_optional",
            "recommended_window_count": "1" if not large_inventory else "2-3",
            "single_window_path": "One agent can audit the corpus, classify existing research, and verify the first authority checks when the project is still modest. If autonomous mode is active and no window help is available, run this as the first serial phase in the same window.",
            "multi_window_path": "If the corpus is already scattered or large, ask the user to help open 2-3 windows for audit, indexing, and authority verification.",
            "user_assistance_required": "yes_if_multi_window",
            "notes": "Prefer multi-window only when the existing corpus is fragmented enough that one agent becomes the bottleneck. In autonomous mode without user window help, fall back to the serial single-window phase plan.",
        },
        {
            "stage": "direction_discovery",
            "recommended_mode": "single_window" if active_direction_count <= 1 else "multi_window_optional",
            "recommended_window_count": "1" if active_direction_count <= 1 else "3-6",
            "single_window_path": "One agent can run discovery when the direction surface is still small and the query families remain manageable. If autonomous mode is active and no window help is available, execute direction lanes sequentially in one window.",
            "multi_window_path": "If several directions need parallel discovery, ask the user to help open the coordinator and per-direction windows before broad search expands.",
            "user_assistance_required": "yes_if_multi_window",
            "notes": "Use multiple windows when separate directions can accumulate evidence independently without constant interference. In autonomous mode without user window help, keep lane ownership logically separate but execute the lanes in sequence.",
        },
        {
            "stage": "deep_search",
            "recommended_mode": "single_window" if active_direction_count <= 1 and audit["status"] != "launch_candidate" else "multi_window_recommended",
            "recommended_window_count": "1" if active_direction_count <= 1 and audit["status"] != "launch_candidate" else "4-8",
            "single_window_path": "One agent can continue when only one strong direction survives or when the deep-search budget remains conservative. If autonomous mode is active and multi-window help is unavailable, rotate through promoted directions sequentially in one window using the same depth and budget contracts.",
            "multi_window_path": "If multiple strong directions survive, ask the user to help open a coordinator lane, shared-table lane, and per-direction windows before long deep cycles begin.",
            "user_assistance_required": "yes_if_multi_window",
            "notes": "Deep-search expansion should not start in multiple windows until the user has chosen direction depth and budget intent explicitly. Autonomous mode may still perform this stage in one window by serializing the direction passes.",
        },
        {
            "stage": "synthesis_and_validation_planning",
            "recommended_mode": "single_window" if audit["status"] in {"structural_only", "evidence_building"} else "multi_window_optional",
            "recommended_window_count": "1" if audit["status"] in {"structural_only", "evidence_building"} else "2-4",
            "single_window_path": "One agent can synthesize and map validation placeholders when the retained slate is still compact. In autonomous mode without multi-window help, treat this as the closing serial phase after intake, direction, and conflict passes.",
            "multi_window_path": "If several retained directions and route boards need concurrent reconciliation, ask the user to help open synthesis, conflict-review, and master-table windows.",
            "user_assistance_required": "yes_if_multi_window",
            "notes": "Keep single-window viable, but explicitly recommend help from the user when several parallel reconciliation tasks are visible. Autonomous mode must still be able to complete this stage in one window if help is unavailable.",
        },
    ]


def build_search_escalation_selection(rows: list[dict[str, str]]) -> str:
    level_lines = [f"- `{row['escalation_level']}`: {row['scope_change']}" for row in rows] or ["- no escalation recommendations inferred automatically"]
    return "\n".join([
        "# Search Escalation Selection",
        "",
        "## Purpose",
        "",
        "Decide whether the current search depth is sufficient or whether another search wave should run at a higher breadth, depth, or both.",
        "",
        "## Current Search Sufficiency Judgment",
        "",
        "",
        "## Escalation Levels",
        "",
        *level_lines,
        "",
        "## User Choice",
        "",
        "",
        "## Notes",
        "",
        "```text",
        "If the current search still feels too thin, choose the next escalation wave and record any user-added directions before the next search stage begins.",
        "```",
        "",
    ])


def build_search_mode_selection(rows: list[dict[str, str]]) -> str:
    mode_lines = [f"- `{row['phase_scope']}`: recommend `{row['recommended_search_mode']}`" for row in rows] or ["- no search-mode recommendation inferred automatically"]
    return "\n".join([
        "# Search Mode Selection",
        "",
        "## Purpose",
        "",
        "Choose whether the next research stage should rely only on model prior knowledge, only on the existing project corpus, or on external literature search.",
        "",
        "## Recommended Modes",
        "",
        *mode_lines,
        "",
        "## Available Search Modes",
        "",
        "1. knowledge_only",
        "2. project_corpus_only",
        "3. external_search_enabled",
        "",
        "## User Choice",
        "",
        "",
        "## Notes",
        "",
        "```text",
        "Please choose whether the next stage should use only existing knowledge, only the existing project corpus, or allow external literature search.",
        "```",
        "",
    ])


def build_stage_window_guidance(rows: list[dict[str, str]]) -> str:
    sections: list[str] = ["# Stage Window Guidance", "", "Use this file to decide whether the next stage should stay in one window or use multiple windows.", ""]
    title_map = {
        "audit_and_existing_content_review": "Audit And Existing-Content Review",
        "direction_discovery": "Direction Discovery",
        "deep_search": "Deep Search",
        "synthesis_and_validation_planning": "Synthesis And Validation Planning",
    }
    for row in rows:
        title = title_map.get(row["stage"], row["stage"].replace("_", " ").title())
        sections.extend([
            f"## {title}",
            "",
            f"- recommended_mode: `{row['recommended_mode']}`",
            f"- recommended_window_count: `{row['recommended_window_count']}`",
            f"- user_assistance_required: `{row['user_assistance_required']}`",
            "",
            "Single-window path:",
            row["single_window_path"],
            "",
            "Multi-window path:",
            row["multi_window_path"],
            "",
            "Notes:",
            row["notes"],
            "",
        ])
    return "\n".join(sections)


def build_window_mode_selection(rows: list[dict[str, str]]) -> str:
    stage_lines = [f"- `{row['stage']}`: recommend `{row['recommended_mode']}` with `{row['recommended_window_count']}` window(s)" for row in rows] or ["- no stage-level recommendation was inferred automatically"]
    return "\n".join([
        "# Window Mode Selection",
        "",
        "## Purpose",
        "",
        "Choose whether the next stage should stay in one window or use multiple windows.",
        "",
        "## Current Stage",
        "",
        "",
        "## Recommended Default",
        "",
        *stage_lines,
        "",
        "## Available Modes",
        "",
        "1. single_window",
        "2. multi_window",
        "",
        "## Suggested Window Count",
        "",
        "",
        "## User Choice",
        "",
        "",
        "## User Assistance Request",
        "",
        "If multi-window is chosen, ask the user to help open the requested number of windows because many agents cannot open extra windows by themselves.",
        "If the user cannot help open windows and autonomous mode is active, fall back to the single-window phased plan instead of blocking the program.",
        "",
        "## Notes",
        "",
    ])


def build_deep_dive_selection(rows: list[dict[str, str]]) -> str:
    selected_lines = [f"- `{row['direction']}` (recommended if selected later)" for row in rows] or ["- no direction candidates were inferred automatically"]
    depth_lines = [f"- `{row['direction']}`: `{row['suggested_depth']}` because {row['evidence_hint']}" for row in rows] or ["- no direction candidates were inferred automatically"]
    return "\n".join([
        "# Deep Dive Selection",
        "",
        "## Purpose",
        "",
        "Choose how deeply each selected direction should be pursued before large search or validation budgets are spent.",
        "",
        "## Selected Directions",
        "",
        *selected_lines,
        "",
        "## Suggested Depth Profiles",
        "",
        "1. light_validate",
        "2. standard_deep",
        "3. aggressive_frontier",
        "",
        *depth_lines,
        "",
        "## User Choice",
        "",
        "",
        "## Notes",
        "",
        "```text",
        "For the directions that move forward, please choose one depth profile for each:",
        "1. light_validate",
        "2. standard_deep",
        "3. aggressive_frontier",
        "```",
        "",
    ])


def build_direction_depth_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    for row in rows:
        selected_state = "advance_now" if row["priority"] == "high" else "defer"
        depth_profile = row["suggested_depth"] if selected_state == "advance_now" else "not_applicable"
        allowed_round_budget = "pending_user_choice"
        allowed_cycle_budget = "pending_user_choice"
        notes = f"Recommended from top-level inventory: {row['evidence_hint']}"
        result.append({
            "direction": row["direction"],
            "selected_state": selected_state,
            "depth_profile": depth_profile,
            "allowed_round_budget": allowed_round_budget,
            "allowed_cycle_budget": allowed_cycle_budget,
            "notes": notes,
        })
    return result


def collect_search_trace_rows(workspace_root: Path) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    worker_root = workspace_root / "01_window_runs"
    if not worker_root.exists():
        return rows
    for folder in sorted(worker_root.glob("W*_*")):
        round_log = folder / "round_log.csv"
        for row in read_csv_rows(round_log):
            rows.append({
                "worker": folder.name,
                "direction_hint": infer_direction_hint(folder.name),
                "round_id": row.get("round_id", ""),
                "search_question": row.get("search_question", ""),
                "query_set": row.get("query_set", ""),
                "candidate_count": row.get("candidate_count", ""),
                "retained_count": row.get("retained_count", ""),
                "next_action": row.get("next_action", ""),
                "source_file": str(round_log.relative_to(workspace_root)),
            })
    return rows


def collect_source_authority_rows(workspace_root: Path) -> list[dict[str, str]]:
    existing_rows = read_csv_rows(workspace_root / "12_ingestion_logs" / "source_authority_log.csv")
    existing_by_key: dict[str, dict[str, str]] = {}
    for row in existing_rows:
        key = authority_row_key(row.get("source_id", ""), row.get("stable_link", ""), row.get("title", ""))
        if key:
            existing_by_key[key] = row

    aggregated: dict[str, dict[str, str]] = {}
    worker_root = workspace_root / "01_window_runs"
    if worker_root.exists():
        for folder in sorted(worker_root.glob("W*_*")):
            for row in read_csv_rows(folder / "source_index.csv"):
                source_id = row.get("source_id", "")
                stable_link = row.get("stable_link", "")
                title = row.get("title", "")
                key = authority_row_key(source_id, stable_link, title)
                if not key:
                    continue
                current = aggregated.setdefault(
                    key,
                    {
                        "source_id": source_id,
                        "title": title,
                        "authors": row.get("authors", ""),
                        "year": row.get("year", ""),
                        "source": row.get("source", ""),
                        "evidence_class": row.get("evidence_class", ""),
                        "stable_link": stable_link,
                        "directions_seen": "",
                        "workers_seen": "",
                        "authority_assessment": "",
                        "verification_status": "pending_review",
                        "external_verdict": "",
                        "disposition": row.get("disposition", ""),
                        "notes": "",
                    },
                )
                current["directions_seen"] = merge_csv_set(current.get("directions_seen", ""), row.get("direction", ""))
                current["workers_seen"] = merge_csv_set(current.get("workers_seen", ""), folder.name)
                current["disposition"] = current.get("disposition") or row.get("disposition", "")

    result: list[dict[str, str]] = []
    consumed_keys: set[str] = set()
    for key, row in aggregated.items():
        merged = dict(row)
        if key in existing_by_key:
            merged = {**row, **{k: v for k, v in existing_by_key[key].items() if v}}
            merged["directions_seen"] = merge_csv_set(row.get("directions_seen", ""), existing_by_key[key].get("directions_seen", ""))
            merged["workers_seen"] = merge_csv_set(row.get("workers_seen", ""), existing_by_key[key].get("workers_seen", ""))
            consumed_keys.add(key)
        result.append({column: merged.get(column, "") for column in SOURCE_AUTHORITY_COLUMNS})

    for key, row in existing_by_key.items():
        if key not in consumed_keys and key not in aggregated:
            result.append({column: row.get(column, "") for column in SOURCE_AUTHORITY_COLUMNS})

    return result


def collect_credibility_summary_rows(workspace_root: Path) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    credibility_root = workspace_root / "06_reports" / "credibility"
    if not credibility_root.exists():
        return rows
    for path in sorted(credibility_root.rglob("*.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if "credibility_score_35" not in payload:
            continue
        scores = payload.get("scores", {})
        row = {
            "label": payload.get("label", ""),
            "route_id": payload.get("route_id", ""),
            "direction": payload.get("direction", ""),
            "route_board": payload.get("route_board", ""),
            "claim_scope": payload.get("claim_scope", ""),
            "source_id": payload.get("source_id", ""),
            "claim_id": payload.get("claim_id", ""),
            "credibility_score_35": str(payload.get("credibility_score_35", "")),
            "credibility_band": payload.get("credibility_band", ""),
            "source_authority": str(scores.get("source_authority", "")),
            "task_directness": str(scores.get("task_directness", "")),
            "empirical_strength": str(scores.get("empirical_strength", "")),
            "transfer_risk": str(scores.get("transfer_risk", "")),
            "reproducibility_readiness": str(scores.get("reproducibility_readiness", "")),
            "contradiction_burden": str(scores.get("contradiction_burden", "")),
            "validation_readiness": str(scores.get("validation_readiness", "")),
            "report_path": str(path.relative_to(workspace_root)),
        }
        rows.append(row)
    return rows


def infer_direction_hint(worker_name: str) -> str:
    lowered = worker_name.lower()
    if "direction" in lowered:
        return worker_name.split("_", 1)[1] if "_" in worker_name else worker_name
    if "intake" in lowered:
        return "intake_metadata"
    if "conflict" in lowered:
        return "conflict_review"
    if "synthesis" in lowered:
        return "synthesis"
    if "master" in lowered:
        return "master_tables"
    if "coordinator" in lowered:
        return "coordinator"
    return worker_name


def authority_row_key(source_id: str, stable_link: str, title: str) -> str:
    if source_id:
        return f"source_id::{source_id}"
    if stable_link:
        return f"stable_link::{stable_link}"
    if title:
        return f"title::{title.strip().lower()}"
    return ""


def merge_csv_set(left: str, right: str) -> str:
    values = []
    seen = set()
    for raw in [left, right]:
        parts = [item.strip() for item in raw.split(",")] if raw else []
        for item in parts:
            if item and item not in seen:
                seen.add(item)
                values.append(item)
    return ", ".join(values)


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return list(reader)


def write_text(path: Path, text: str, overwrite: bool) -> None:
    if path.exists() and not overwrite:
        return
    path.write_text(text, encoding="utf-8")


def write_csv_rows(path: Path, columns: list[str], rows: list[dict[str, str]], overwrite: bool) -> None:
    if path.exists() and not overwrite:
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in columns})


if __name__ == "__main__":
    main()
