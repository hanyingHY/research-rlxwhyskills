#!/usr/bin/env python3
"""Assess implementation maturity without conflating it with research credibility."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path


sys.dont_write_bytecode = True


INVENTORY_HEADERS = [
    "component_id", "route_id", "research_claim_ids", "path", "component_type",
    "active_status", "entrypoint", "dependency_surface", "test_surface", "benchmark_surface",
]
EVIDENCE_HEADERS = [
    "evidence_id", "route_id", "component_id", "evidence_type", "command_or_artifact",
    "status", "observed_at", "output_reference", "notes",
]
ASSESSMENT_HEADERS = [
    "route_id", "traceability", "implementation_completeness", "runnability",
    "automated_verification", "reproducibility", "operational_readiness",
    "implementation_score_100", "maturity_level", "critical_blockers", "next_engineering_action",
]
BACKLOG_HEADERS = [
    "task_id", "route_id", "component_id", "gap", "required_stage", "proposed_change",
    "owned_scope", "verification_command", "expected_artifact", "acceptance_criteria", "priority", "status",
]
READINESS_HEADERS = [
    "route_id", "target_stage", "research_score_100", "implementation_score_100",
    "implementation_level", "research_gate", "implementation_gate", "gated_status", "blocking_reasons",
]

LEVEL_RANK = {f"M{value}": value for value in range(6)}


def main() -> None:
    parser = argparse.ArgumentParser(description="Assess code implementation maturity for a full research workspace")
    parser.add_argument("--workspace-root", required=True)
    parser.add_argument("--project-root")
    parser.add_argument("--profile", choices=["generic", "quant-research"], default="generic")
    parser.add_argument(
        "--target-stage",
        choices=["research_retention", "validation_placeholder", "experiment_execution", "result_promotion", "benchmark_freeze", "release"],
        default="experiment_execution",
    )
    parser.add_argument("--format", choices=["json", "markdown"], default="json")
    parser.add_argument("--output")
    parser.add_argument("--write-workspace", action="store_true")
    args = parser.parse_args()

    workspace = Path(args.workspace_root).resolve()
    project = Path(args.project_root).resolve() if args.project_root else workspace
    model = load_model(Path(__file__).resolve().parents[1] / "references" / "implementation-maturity-model.json")
    result = assess(workspace, project, args.profile, args.target_stage, model)

    if args.write_workspace:
        write_workspace_outputs(workspace, result)
    rendered = render_markdown(result) if args.format == "markdown" else json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        output = Path(args.output).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(rendered, encoding="utf-8")
    print(rendered)


def load_model(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def assess(workspace: Path, project: Path, profile: str, target_stage: str, model: dict) -> dict:
    validation_dir = workspace / "05_validation"
    inventory_path = validation_dir / "code_inventory.csv"
    evidence_path = validation_dir / "implementation_evidence.csv"
    inventory = read_csv(inventory_path)
    if not inventory:
        inventory = discover_inventory(project)
    evidence = read_csv(evidence_path)
    credibility = read_csv(workspace / "06_reports" / "credibility" / "credibility_summary.csv")
    explicit_credibility_routes = {row.get("route_id", "").strip() for row in credibility if row.get("route_id", "").strip()}
    credibility_lacks_route_mapping = bool(credibility) and not explicit_credibility_routes
    credibility_routes = explicit_credibility_routes or {row.get("direction", "").strip() for row in credibility if row.get("direction", "").strip()}
    routes = sorted(
        {row.get("route_id", "").strip() or "project-default" for row in inventory}
        | {row.get("route_id", "").strip() or "project-default" for row in evidence}
        | credibility_routes
    )
    if not routes:
        routes = ["project-default"]

    assessments = []
    backlog = []
    readiness = []
    for route_id in routes:
        route_inventory = [row for row in inventory if (row.get("route_id", "").strip() or "project-default") == route_id]
        route_evidence = [row for row in evidence if (row.get("route_id", "").strip() or "project-default") == route_id]
        dimension_scores, critical_blockers = score_dimensions(route_inventory, route_evidence, profile, target_stage, model, project)
        score_100 = round(sum(dimension_scores.values()) / (4 * len(dimension_scores)) * 100)
        level = determine_level(score_100, dimension_scores, route_evidence, critical_blockers, model)
        gaps = derive_gaps(dimension_scores, route_evidence, critical_blockers, target_stage, level, model)
        assessment = {
            "route_id": route_id,
            **dimension_scores,
            "implementation_score_100": score_100,
            "maturity_level": level,
            "critical_blockers": "; ".join(critical_blockers),
            "next_engineering_action": gaps[0] if gaps else "none",
        }
        assessments.append(assessment)
        backlog.extend(build_backlog(route_id, route_inventory, gaps, target_stage))

        research_score = research_score_for_route(route_id, credibility)
        research_gate = "pass" if research_score is not None else "unscored"
        route_mapping_blocker = None
        if requires_explicit_route_mapping(target_stage) and credibility_lacks_route_mapping:
            research_gate = "mapping_required"
            route_mapping_blocker = "credibility reports lack explicit route_id mapping"
        required_level = model["stage_gates"][target_stage]
        implementation_gate = "pass" if LEVEL_RANK[level] >= LEVEL_RANK[required_level] and not critical_blockers else "fail"
        blockers = list(critical_blockers) + ([route_mapping_blocker] if route_mapping_blocker else []) + gaps
        gated_status = joint_status(target_stage, research_gate, implementation_gate)
        readiness.append({
            "route_id": route_id,
            "target_stage": target_stage,
            "research_score_100": research_score if research_score is not None else "unscored",
            "implementation_score_100": score_100,
            "implementation_level": level,
            "research_gate": research_gate,
            "implementation_gate": implementation_gate,
            "gated_status": gated_status,
            "blocking_reasons": "; ".join(dict.fromkeys(blockers)),
        })

    return {
        "schema_version": 1,
        "workspace_root": str(workspace),
        "project_root": str(project),
        "profile": profile,
        "recommended_profile": recommend_profile(project),
        "target_stage": target_stage,
        "inventory_source": "workspace" if read_csv(inventory_path) else "static_discovery",
        "inventory": inventory,
        "evidence_count": len(evidence),
        "assessments": assessments,
        "implementation_backlog": backlog,
        "route_readiness": readiness,
        "status": "ready" if all(row["gated_status"].startswith("ready_for_") or row["gated_status"] == "research_only" for row in readiness) else "needs_attention",
    }


def score_dimensions(inventory: list[dict], evidence: list[dict], profile: str, target_stage: str, model: dict, project: Path) -> tuple[dict[str, int], list[str]]:
    passing = defaultdict(int)
    failing = []
    for row in evidence:
        evidence_type = row.get("evidence_type", "").strip()
        status = row.get("status", "").strip()
        if status == "pass":
            passing[evidence_type] += 1
        elif status == "fail":
            failing.append(evidence_type)

    existing_paths = 0
    active_components = 0
    traced_components = 0
    complete_surfaces = 0
    for row in inventory:
        raw_path = row.get("path", "").strip()
        path = Path(raw_path)
        exists = path.exists() if path.is_absolute() else (project / path).exists()
        existing_paths += int(exists)
        active_components += int(row.get("active_status", "").strip() in {"active", "candidate"})
        traced_components += int(bool(row.get("route_id", "").strip()) and bool(row.get("research_claim_ids", "").strip()))
        complete_surfaces += int(bool(row.get("entrypoint", "").strip()) and bool(row.get("dependency_surface", "").strip()))

    count = len(inventory)
    traceability = 0 if count == 0 else 1
    if count and all(row.get("route_id", "").strip() for row in inventory):
        traceability = 2
    if traced_components:
        traceability = 3
    if traced_components == count and count and (passing["traceability"] or passing["claim_to_code"]):
        traceability = 4

    completeness = 0 if count == 0 else 1
    if existing_paths and active_components:
        completeness = 2
    if complete_surfaces:
        completeness = 3
    if count and complete_surfaces == count and all(row.get("test_surface", "").strip() for row in inventory):
        completeness = 4

    run_passes = passing["build"] + passing["smoke"] + passing["runtime"]
    runnability = 0 if run_passes == 0 else 2
    if run_passes >= 2:
        runnability = 3
    if run_passes >= 3 and passing["environment"]:
        runnability = 4

    verification_passes = passing["test"] + passing["integrity"] + passing["static_analysis"]
    verification = 0 if verification_passes == 0 else 2
    if verification_passes >= 2:
        verification = 3
    if verification_passes >= 3 and not failing:
        verification = 4

    reproducibility_passes = passing["reproduction"] + passing["benchmark"] + passing["benchmark_freeze"]
    reproducibility = 0 if reproducibility_passes == 0 else 2
    if (passing["benchmark"] or passing["benchmark_freeze"]) and reproducibility_passes >= 2:
        reproducibility = 3
    if passing["benchmark_freeze"] and passing["reproduction"]:
        reproducibility = 4

    operational_passes = passing["output_contract"] + passing["release"] + passing["monitoring"] + passing["rollback"]
    operational = min(4, operational_passes)

    critical_types = set(model["profiles"][profile]["critical_evidence_types"])
    critical_blockers = [f"critical evidence failed: {item}" for item in sorted(set(failing) & critical_types)]
    if profile == "quant-research" and target_stage not in {"research_retention", "validation_placeholder"}:
        observed_types = {row.get("evidence_type", "").strip() for row in evidence}
        critical_blockers.extend(f"required quant evidence missing: {item}" for item in sorted(critical_types - observed_types))
    return {
        "traceability": traceability,
        "implementation_completeness": completeness,
        "runnability": runnability,
        "automated_verification": verification,
        "reproducibility": reproducibility,
        "operational_readiness": operational,
    }, critical_blockers


def determine_level(score_100: int, dimensions: dict[str, int], evidence: list[dict], blockers: list[str], model: dict) -> str:
    passing_types = {row.get("evidence_type", "").strip() for row in evidence if row.get("status", "").strip() == "pass"}
    selected = "M0"
    for definition in model["levels"]:
        level = definition["id"]
        if score_100 < definition["minimum_score_100"]:
            break
        if any(dimensions.get(key, 0) < value for key, value in definition.get("minimum_dimensions", {}).items()):
            break
        if definition.get("forbid_critical_failures") and blockers:
            break
        if not set(definition.get("required_passing_evidence", [])).issubset(passing_types):
            break
        required_any = set(definition.get("required_any_passing_evidence", []))
        if required_any and not required_any.intersection(passing_types):
            break
        selected = level
    return selected


def derive_gaps(dimensions: dict[str, int], evidence: list[dict], blockers: list[str], target_stage: str, level: str, model: dict) -> list[str]:
    gaps = list(blockers)
    required_level = model["stage_gates"][target_stage]
    if LEVEL_RANK[level] < LEVEL_RANK[required_level]:
        gaps.append(f"{target_stage} requires {required_level}; current level is {level}")
    evidence_statuses = {row.get("status", "").strip() for row in evidence}
    if target_stage not in {"research_retention", "validation_placeholder"} and not evidence:
        gaps.append("no executable evidence has been recorded")
    elif target_stage not in {"research_retention", "validation_placeholder"} and evidence_statuses <= {"not_run", "missing"}:
        gaps.append("all executable evidence is missing or not_run")
    for name, score in dimensions.items():
        if score == 0:
            gaps.append(f"{name} has no supporting evidence")
    return list(dict.fromkeys(gaps))


def build_backlog(route_id: str, inventory: list[dict], gaps: list[str], target_stage: str) -> list[dict[str, str]]:
    component_id = inventory[0].get("component_id", "") if inventory else "project-default"
    owned_scope = inventory[0].get("path", "") if inventory else "project root"
    return [
        {
            "task_id": f"IMPL-{index:03d}",
            "route_id": route_id,
            "component_id": component_id,
            "gap": gap,
            "required_stage": target_stage,
            "proposed_change": f"Close implementation maturity gap: {gap}",
            "owned_scope": owned_scope,
            "verification_command": "pending_operator_definition",
            "expected_artifact": "passing implementation evidence row",
            "acceptance_criteria": "record a passing, reproducible artifact and rerun the maturity assessment",
            "priority": "high" if index <= 2 else "medium",
            "status": "open",
        }
        for index, gap in enumerate(gaps, start=1)
    ]


def research_score_for_route(route_id: str, rows: list[dict]) -> int | None:
    route_scores = [parse_int(row.get("credibility_score_35")) for row in rows if row.get("route_id", "").strip() == route_id]
    route_scores = [score for score in route_scores if score is not None]
    if not route_scores:
        route_scores = [parse_int(row.get("credibility_score_35")) for row in rows if row.get("direction", "").strip() == route_id]
        route_scores = [score for score in route_scores if score is not None]
    if not route_scores:
        route_scores = [parse_int(row.get("credibility_score_35")) for row in rows if row.get("label", "").strip() == route_id]
        route_scores = [score for score in route_scores if score is not None]
    if not route_scores:
        return None
    return round(sum(route_scores) / len(route_scores) / 35 * 100)


def requires_explicit_route_mapping(target_stage: str) -> bool:
    """Require the durable route key once a route is meant to execute or advance."""
    return target_stage in {"experiment_execution", "result_promotion", "benchmark_freeze", "release"}


def joint_status(target_stage: str, research_gate: str, implementation_gate: str) -> str:
    if research_gate != "pass":
        return "blocked"
    if implementation_gate != "pass":
        return "research_only" if target_stage in {"research_retention", "validation_placeholder"} else "implementation_required"
    return {
        "research_retention": "research_only",
        "validation_placeholder": "research_only",
        "experiment_execution": "ready_for_execution",
        "result_promotion": "ready_for_promotion",
        "benchmark_freeze": "ready_for_benchmark_freeze",
        "release": "ready_for_release",
    }[target_stage]


def discover_inventory(project: Path) -> list[dict[str, str]]:
    patterns = {
        "main.py": "runtime_entrypoint", "app.py": "runtime_entrypoint", "cli.py": "runtime_entrypoint",
        "pyproject.toml": "dependency_manifest", "requirements.txt": "dependency_manifest",
        "package.json": "dependency_manifest", "Cargo.toml": "dependency_manifest", "go.mod": "dependency_manifest",
        "Dockerfile": "delivery_surface",
    }
    rows = []
    seen = set()
    for name, component_type in patterns.items():
        for path in list(project.glob(name)) + list(project.glob(f"*/{name}")) + list(project.glob(f"*/*/{name}")):
            relative = str(path.relative_to(project))
            if relative in seen:
                continue
            seen.add(relative)
            rows.append({
                "component_id": f"component-{len(rows) + 1:03d}",
                "route_id": "project-default",
                "research_claim_ids": "",
                "path": relative,
                "component_type": component_type,
                "active_status": "candidate",
                "entrypoint": relative if component_type == "runtime_entrypoint" else "",
                "dependency_surface": relative if component_type == "dependency_manifest" else "",
                "test_surface": "tests" if (project / "tests").exists() else "",
                "benchmark_surface": "benchmarks" if (project / "benchmarks").exists() else "",
            })
    return rows


def recommend_profile(project: Path) -> str:
    quant_markers = {"backtest", "factor", "strategy", "benchmark", "portfolio", "signal", "returns", "experiment"}
    paths = list(project.glob("*")) + list(project.glob("*/*")) + list(project.glob("*/*/*"))
    names = {path.name.lower() for path in paths}
    return "quant-research" if any(any(marker in name for marker in quant_markers) for name in names) else "generic"


def write_workspace_outputs(workspace: Path, result: dict) -> None:
    directory = workspace / "05_validation"
    directory.mkdir(parents=True, exist_ok=True)
    write_csv(directory / "code_inventory.csv", INVENTORY_HEADERS, result["inventory"])
    write_csv(directory / "implementation_assessment.csv", ASSESSMENT_HEADERS, result["assessments"])
    write_csv(directory / "implementation_backlog.csv", BACKLOG_HEADERS, result["implementation_backlog"])
    write_csv(directory / "route_readiness_matrix.csv", READINESS_HEADERS, result["route_readiness"])
    (directory / "IMPLEMENTATION_READINESS.md").write_text(render_markdown(result), encoding="utf-8")


def write_csv(path: Path, headers: list[str], rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            writer.writerow({header: row.get(header, "") for header in headers})


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def parse_int(raw: object) -> int | None:
    try:
        return int(float(str(raw)))
    except (TypeError, ValueError):
        return None


def render_markdown(result: dict) -> str:
    lines = [
        "# Implementation Readiness",
        "",
        "## Profile",
        "",
        f"- selected: `{result['profile']}`",
        f"- recommended: `{result['recommended_profile']}`",
        "",
        "## Target Stage",
        "",
        f"`{result['target_stage']}`",
        "",
        f"- status: `{result['status']}`",
        "",
        "## Route Gates",
        "",
    ]
    for row in result["route_readiness"]:
        lines.extend([
            f"### {row['route_id']}",
            "",
            f"- research_score_100: `{row['research_score_100']}`",
            f"- implementation_score_100: `{row['implementation_score_100']}`",
            f"- implementation_level: `{row['implementation_level']}`",
            f"- gated_status: `{row['gated_status']}`",
            f"- blocking_reasons: {row['blocking_reasons'] or 'none'}",
            "",
        ])
    lines.extend(["## Critical Gaps", ""])
    gaps = [row["blocking_reasons"] for row in result["route_readiness"] if row["blocking_reasons"]]
    lines.extend([f"- {gap}" for gap in gaps] or ["- none"])
    lines.extend(["", "## Engineering Authority", "", "Audit and create backlog tasks by default. Modify business code only after explicit user authorization.", ""])
    return "\n".join(lines)


if __name__ == "__main__":
    main()
