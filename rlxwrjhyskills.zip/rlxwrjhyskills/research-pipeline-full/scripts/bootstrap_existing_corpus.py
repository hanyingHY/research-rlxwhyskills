#!/usr/bin/env python3
"""Bootstrap a full research workspace from an existing project corpus."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True


TEXT_EXTENSIONS = {".md", ".txt", ".json", ".yaml", ".yml", ".csv", ".tsv", ".py", ".ipynb"}
DEFAULT_EXCLUDED_DIRS = {
    ".git",
    ".codex",
    ".agents",
    "__pycache__",
    "node_modules",
    ".venv",
    ".venv_exp",
    ".venv_run",
    ".mypy_cache",
    ".pytest_cache",
    ".idea",
    ".vscode",
    "dist",
    "build",
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Bootstrap a full research workspace from an existing project corpus")
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--workspace-root", required=True)
    parser.add_argument("--overwrite-derived", action="store_true")
    parser.add_argument("--max-files", type=int, default=300)
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    workspace_root = Path(args.workspace_root).resolve()

    discovered_files = discover_corpus_files(project_root, workspace_root, max_files=args.max_files)
    master_source_rows = build_master_source_rows(project_root, discovered_files)
    direction_rows = build_direction_scoreboard_rows(master_source_rows)
    experiment_rows = build_research_to_experiment_rows(direction_rows)
    search_trace_rows = build_search_trace_rows(project_root, discovered_files)
    source_authority_rows = build_source_authority_rows(master_source_rows)
    claim_verification_rows = build_claim_verification_rows(master_source_rows)

    write_csv_rows(
        workspace_root / "05_master_tables" / "master_source_index.csv",
        ["source_id", "title", "authors", "year", "evidence_class", "stable_link", "primary_direction", "disposition"],
        master_source_rows,
        args.overwrite_derived,
    )
    write_csv_rows(
        workspace_root / "05_master_tables" / "direction_scoreboard.csv",
        ["direction", "relevance", "directness", "evidence_strength", "feasibility", "expected_upside", "status"],
        direction_rows,
        args.overwrite_derived,
    )
    write_csv_rows(
        workspace_root / "05_master_tables" / "research_to_experiment_matrix.csv",
        ["direction", "claim", "mapped_category", "validation_placeholder", "priority"],
        experiment_rows,
        args.overwrite_derived,
    )
    write_csv_rows(
        workspace_root / "12_ingestion_logs" / "search_trace_log.csv",
        ["worker", "direction_hint", "round_id", "search_question", "query_set", "candidate_count", "retained_count", "next_action", "source_file"],
        search_trace_rows,
        args.overwrite_derived,
    )
    write_csv_rows(
        workspace_root / "12_ingestion_logs" / "source_authority_log.csv",
        ["source_id", "title", "authors", "year", "source", "evidence_class", "stable_link", "directions_seen", "workers_seen", "authority_assessment", "verification_status", "external_verdict", "disposition", "notes"],
        source_authority_rows,
        args.overwrite_derived,
    )
    write_csv_rows(
        workspace_root / "12_ingestion_logs" / "claim_verification_log.csv",
        ["claim_id", "claim_text", "original_source", "authority_assessment", "external_verdict", "disposition", "notes"],
        claim_verification_rows,
        args.overwrite_derived,
    )

    write_text(
        workspace_root / "01_window_runs" / "W08_intake_metadata" / "direction_report.md",
        build_intake_direction_report(project_root, master_source_rows, direction_rows),
        args.overwrite_derived,
    )
    write_text(
        workspace_root / "01_window_runs" / "W08_intake_metadata" / "quality_audit.md",
        build_intake_quality_audit(discovered_files, source_authority_rows, claim_verification_rows),
        args.overwrite_derived,
    )
    write_text(
        workspace_root / "06_reports" / "final_technical_report.md",
        build_final_report(master_source_rows, direction_rows),
        args.overwrite_derived,
    )

    result = {
        "project_root": str(project_root),
        "workspace_root": str(workspace_root),
        "discovered_file_count": len(discovered_files),
        "master_source_index_rows": len(master_source_rows),
        "direction_scoreboard_rows": len(direction_rows),
        "research_to_experiment_rows": len(experiment_rows),
        "search_trace_rows": len(search_trace_rows),
        "source_authority_rows": len(source_authority_rows),
        "claim_verification_rows": len(claim_verification_rows),
        "status": "ready",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


def discover_corpus_files(project_root: Path, workspace_root: Path, max_files: int) -> list[Path]:
    files: list[Path] = []
    excluded_roots = {
        workspace_root.resolve(),
        (project_root / "rlxwrjhyskills").resolve() if (project_root / "rlxwrjhyskills").exists() else None,
    }
    excluded_roots = {item for item in excluded_roots if item is not None}
    for path in project_root.rglob("*"):
        if len(files) >= max_files:
            break
        if not path.is_file():
            continue
        if path.suffix.lower() not in TEXT_EXTENSIONS:
            continue
        if any(excluded_root in path.parents for excluded_root in excluded_roots):
            continue
        if any(part in DEFAULT_EXCLUDED_DIRS for part in path.parts):
            continue
        files.append(path)
    return sorted(files)


def build_master_source_rows(project_root: Path, files: list[Path]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for index, path in enumerate(files, start=1):
        relative_path = str(path.relative_to(project_root))
        evidence_class = infer_source_type(relative_path)
        rows.append(
            {
                "source_id": f"src_{index:04d}",
                "title": relative_path,
                "authors": infer_source_family(relative_path),
                "year": infer_year(path),
                "evidence_class": evidence_class,
                "stable_link": str(path),
                "primary_direction": infer_direction(relative_path),
                "disposition": infer_disposition(relative_path),
            }
        )
    return rows


def build_direction_scoreboard_rows(master_source_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    counts: dict[str, int] = {}
    for row in master_source_rows:
        counts[row["primary_direction"]] = counts.get(row["primary_direction"], 0) + 1
    rows: list[dict[str, str]] = []
    for direction, count in sorted(counts.items()):
        rows.append(
            {
                "direction": direction,
                "relevance": str(min(5, max(1, count // 5 + 1))),
                "directness": str(min(5, max(1, count // 7 + 1))),
                "evidence_strength": str(min(5, max(1, count // 9 + 1))),
                "feasibility": "3",
                "expected_upside": str(min(5, max(1, count // 6 + 1))),
                "status": "discovered_from_existing_corpus",
            }
        )
    return rows


def build_research_to_experiment_rows(direction_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    return [
        {
            "direction": row["direction"],
            "claim": f"Bootstrap existing project materials for {row['direction']} into a validation-ready slate.",
            "mapped_category": "validation design",
            "validation_placeholder": "classify retained local materials, validate them externally, and promote the strongest claims into deeper search",
            "priority": "immediate",
        }
        for row in direction_rows
    ]


def build_search_trace_rows(project_root: Path, files: list[Path]) -> list[dict[str, str]]:
    return [
        {
            "worker": "W08_intake_metadata",
            "direction_hint": "existing_corpus_bootstrap",
            "round_id": "bootstrap_r001",
            "search_question": "Which existing project materials should seed the new research workspace?",
            "query_set": "filesystem traversal of existing text-like project materials",
            "candidate_count": str(len(files)),
            "retained_count": str(len(files)),
            "next_action": "map imported materials into direction lanes and start authority review",
            "source_file": str(project_root),
        }
    ]


def build_source_authority_rows(master_source_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    return [
        {
            "source_id": row["source_id"],
            "title": row["title"],
            "authors": row["authors"],
            "year": row["year"],
            "source": row["evidence_class"],
            "evidence_class": row["evidence_class"],
            "stable_link": row["stable_link"],
            "directions_seen": row["primary_direction"],
            "workers_seen": "W08_intake_metadata",
            "authority_assessment": "existing local project material requires external confirmation before final retention",
            "verification_status": "pending_review",
            "external_verdict": "not yet checked",
            "disposition": row["disposition"],
            "notes": f"Imported automatically from the existing project corpus to seed the workspace. Evidence class: {infer_source_type(row['title'])}.",
        }
        for row in master_source_rows
    ]


def build_claim_verification_rows(master_source_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for index, row in enumerate(master_source_rows[:25], start=1):
        rows.append(
            {
                "claim_id": f"claim_{index:03d}",
                "claim_text": f"Validate imported project material `{row['title']}` before using it as final retained evidence.",
                "original_source": row["stable_link"],
                "authority_assessment": "internal or mixed local source",
                "external_verdict": "pending_external_confirmation",
                "disposition": "needs_manual_review",
                "notes": "Generated from the existing corpus bootstrap pass.",
            }
        )
    return rows


def build_intake_direction_report(project_root: Path, master_source_rows: list[dict[str, str]], direction_rows: list[dict[str, str]]) -> str:
    top_directions = "\n".join(f"1. `{row['direction']}`" for row in direction_rows[:5]) or "1. none"
    evidence_mix = render_evidence_class_mix(master_source_rows)
    return f"""# W08_intake_metadata

## Objective

Bootstrap the full research workspace from the existing project corpus so the program starts from real materials instead of an empty scaffold.

## Strongest Retained Evidence

1. Imported `{len(master_source_rows)}` text-like project materials into `master_source_index.csv`.
2. Generated a direction scoreboard from the imported corpus.
3. Seeded an explicit claim-verification backlog rather than trusting local materials blindly.

## Conflicts and Adjudication

1. The imported corpus mixes active implementation notes, historical traces, and supporting audit documentation.
2. The bootstrap keeps those materials visible while marking authority review as pending.

## Validation Schemes

1. Confirm imported local materials against stronger external authority before promotion.
2. Promote the strongest imported directions into deeper search once user direction choices are explicit.

## Immediate Next Actions

1. Review `master_source_index.csv`, `direction_scoreboard.csv`, and `source_authority_log.csv`.
2. Choose which imported directions advance now.

## Deferred Items

1. Claim-level extraction from imported materials.
2. External evidence reconciliation.

## Top Imported Directions

{top_directions}

## Evidence Class Mix

{evidence_mix}

## Project Root

`{project_root}`
"""


def build_intake_quality_audit(files: list[Path], source_authority_rows: list[dict[str, str]], claim_verification_rows: list[dict[str, str]]) -> str:
    evidence_mix = render_evidence_class_mix(source_authority_rows)
    return f"""# Quality Audit

## Status

The workspace is no longer an empty shell. It now has real imported corpus structure from the project root.

## Gaps

1. Imported materials still require external authority checks.
2. Imported rows are inventory-grade, not yet claim-grade evidence rows.

## Repairs

1. Imported `{len(files)}` text-like project files.
2. Seeded `{len(source_authority_rows)}` source-authority rows.
3. Seeded `{len(claim_verification_rows)}` claim-verification backlog rows.
4. Created a bootstrap search-trace row so the intake step is visible in machine-readable form.

## Evidence Class Mix

{evidence_mix}
"""


def build_final_report(master_source_rows: list[dict[str, str]], direction_rows: list[dict[str, str]]) -> str:
    top_directions = "\n".join(f"- `{row['direction']}`" for row in direction_rows[:5]) or "- none"
    evidence_mix = render_evidence_class_mix(master_source_rows)
    return f"""# Final Technical Report

## Objective

Prove that the research skill family can bootstrap a full workspace from a real project corpus instead of only generating empty structures.

## Strongest Retained Evidence

1. Imported `{len(master_source_rows)}` text-like project materials into the master source index.
2. Derived a direction scoreboard from the real corpus.
3. Preserved explicit authority-review and verification backlogs.

## Evidence Class Mix

{evidence_mix}

## Conflicts and Adjudication

1. Local project materials remain mixed-authority inputs and therefore stay pending for external validation.
2. The bootstrap does not silently overstate their trust level.

## Validation Schemes

1. Validate imported corpus items against stronger external sources.
2. Promote the strongest directions into deeper search after user gating.

## Immediate Next Actions

1. Review imported directions and choose which ones advance.
2. Begin authority validation on the highest-impact imported materials.

## Deferred Items

1. Claim-grade extraction.
2. Direction-specific deep search.

## Top Imported Directions

{top_directions}
"""


def render_evidence_class_mix(rows: list[dict[str, str]]) -> str:
    counts: dict[str, int] = {}
    for row in rows:
        evidence_class = row.get("evidence_class") or row.get("source") or "unknown"
        counts[evidence_class] = counts.get(evidence_class, 0) + 1
    if not counts:
        return "- none"
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return "\n".join(f"- `{name}`: `{count}`" for name, count in ordered)


def infer_source_family(relative_path: str) -> str:
    top = relative_path.split("\\", 1)[0].split("/", 1)[0]
    return top or "project_root"


def infer_source_type(relative_path: str) -> str:
    lowered = relative_path.lower()
    if any(token in lowered for token in ["interview", "transcript", "oral-history", "stakeholder"]):
        return "qualitative_interview_or_transcript"
    if any(token in lowered for token in ["survey", "questionnaire", "poll", "instrument"]):
        return "survey_or_questionnaire"
    if any(token in lowered for token in ["policy", "regulation", "standard", "compliance", "governance", "requirement", "framework", "guideline"]):
        return "policy_or_compliance_document"
    if any(token in lowered for token in ["archive", "archival", "record", "registry", "minutes", "memoir", "correspondence", "catalog", "catalogue", "logbook"]):
        return "archival_or_record_source"
    if lowered.endswith(".csv"):
        return "tabular_data_or_log"
    if lowered.endswith(".tsv"):
        return "tabular_data_or_log"
    if lowered.endswith(".md"):
        return "markdown_research_note"
    if lowered.endswith(".py"):
        return "implementation_or_analysis_code"
    if lowered.endswith(".ipynb"):
        return "notebook_or_analysis_code"
    if lowered.endswith((".yaml", ".yml", ".json")):
        return "config_schema_or_structured_text"
    return "general_text_like_research_material"


def infer_direction(relative_path: str) -> str:
    lowered = relative_path.lower()
    if any(token in lowered for token in ["dataset", "data", "csv", "parquet", "tsv"]):
        return "dataset-governance-and-usage"
    if any(token in lowered for token in ["submission", "competition", "guide", "checklist", "manual", "policy", "regulation", "standard", "compliance", "governance", "requirement"]):
        return "rules-and-deliverable-constraints"
    if any(token in lowered for token in ["strategy", "decision", "route", "benchmark", "playbook"]):
        return "strategy-claim-reconciliation"
    if any(token in lowered for token in ["interview", "transcript", "survey", "questionnaire", "stakeholder", "persona", "user-study", "user_research", "ethnography", "fieldnote", "field-note", "observation"]):
        return "qualitative-evidence-and-user-insight"
    if any(token in lowered for token in ["archive", "archival", "historical", "record", "registry", "minutes", "memoir", "correspondence", "catalog", "catalogue", "field log"]):
        return "archival-and-record-based-evidence"
    if any(token in lowered for token in ["research", "literature", "audit", "lineage", "summary"]):
        return "historical-research-reconciliation"
    if any(token in lowered for token in ["baseline", "main.py", "config", "src", "experiments", "implementation", "model"]):
        return "active-implementation-audit"
    return "project-context-and-intake"


def infer_disposition(relative_path: str) -> str:
    lowered = relative_path.lower()
    if any(token in lowered for token in ["legacy", "old", "deprecated", "cleanup"]):
        return "retain_support"
    return "retain_support"


def infer_year(path: Path) -> str:
    try:
        return str(path.stat().st_mtime_ns)[:4]
    except Exception:
        return "2026"


def write_csv_rows(path: Path, columns: list[str], rows: list[dict[str, str]], overwrite: bool) -> None:
    if path.exists() and not overwrite:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in columns})


def write_text(path: Path, text: str, overwrite: bool) -> None:
    if path.exists() and not overwrite:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


if __name__ == "__main__":
    main()
