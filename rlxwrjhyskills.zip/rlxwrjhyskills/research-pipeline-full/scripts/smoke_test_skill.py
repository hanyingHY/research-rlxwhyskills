#!/usr/bin/env python3
"""End-to-end smoke test for the research-pipeline-full skill."""

from __future__ import annotations

import json
import sys
import tempfile
import csv
from pathlib import Path

sys.dont_write_bytecode = True

from local_runtime import python_command, run_command
from profiles import PROFILE_DEFS


def main() -> None:
    skill_root = Path(__file__).resolve().parents[1]
    tmp = Path(tempfile.mkdtemp(prefix="research_pipeline_full_smoke_"))

    init_script = skill_root / "scripts" / "init_research_program.py"
    start_mode_script = skill_root / "scripts" / "recommend_start_mode.py"
    progress_audit_script = skill_root / "scripts" / "assess_workspace_progress.py"
    decision_sync_script = skill_root / "scripts" / "sync_decision_surfaces.py"
    credibility_script = skill_root / "scripts" / "score_research_credibility.py"
    maturity_script = skill_root / "scripts" / "assess_implementation_maturity.py"
    maturity_smoke_script = skill_root / "scripts" / "smoke_test_implementation_maturity.py"
    export_script = skill_root / "scripts" / "export_skill_bundle.py"
    entry_prompt_script = skill_root / "scripts" / "generate_entry_prompts.py"
    prompt_pack_script = skill_root / "scripts" / "generate_window_prompt_pack.py"
    local_validator = skill_root / "scripts" / "validate_skill_local.py"
    workspace_validator = skill_root / "scripts" / "validate_windowed_research_program.py"

    profiles = sorted(PROFILE_DEFS.keys())
    profile_runs = []
    for profile in profiles:
        profile_root = tmp / profile
        raw_project_root = tmp / f"{profile}_raw_project"
        raw_project_root.mkdir(parents=True, exist_ok=True)
        (raw_project_root / "notes.md").write_text("# Notes\n\nThis project has early-stage research notes and draft hypotheses.\n", encoding="utf-8")
        (raw_project_root / "search_results.csv").write_text("title,year\nexample,2026\n", encoding="utf-8")
        credibility_payload = tmp / f"{profile}_credibility_payload.json"
        credibility_payload.write_text(
            json.dumps(
                {
                    "label": "sample_retained_claim",
                    "route_id": "route-alpha",
                    "direction": "direction_alpha",
                    "route_board": "stable",
                    "claim_scope": "signal",
                    "scores": {
                        "source_authority": 4,
                        "task_directness": 4,
                        "empirical_strength": 3,
                        "transfer_risk": 3,
                        "reproducibility_readiness": 4,
                        "contradiction_burden": 3,
                        "validation_readiness": 4
                    }
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        credibility_payload_2 = tmp / f"{profile}_credibility_payload_2.json"
        credibility_payload_2.write_text(
            json.dumps(
                {
                    "label": "sample_retained_claim_2",
                    "route_id": "route-beta",
                    "direction": "direction_beta",
                    "route_board": "aggressive",
                    "claim_scope": "routing",
                    "scores": {
                        "source_authority": 5,
                        "task_directness": 3,
                        "empirical_strength": 4,
                        "transfer_risk": 2,
                        "reproducibility_readiness": 4,
                        "contradiction_burden": 3,
                        "validation_readiness": 4
                    }
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        credibility_report = tmp / f"{profile}_credibility_report.md"
        launch_prompt_path = tmp / f"{profile}_full_launch_prompts.md"
        export_root = tmp / f"{profile}_full_export"
        audit_report_path = tmp / f"{profile}_full_progress_audit.md"
        steps = []
        steps.append(run_step(python_command(start_mode_script, "--project-root", raw_project_root, "--profile", profile), skill_root.parent))
        steps.append(run_step(python_command(credibility_script, "--input-json", credibility_payload, "--output", credibility_report, "--format", "markdown"), skill_root.parent))
        steps.append(run_step(python_command(init_script, "--root", profile_root, "--mode", "windowed-search", "--profile", profile, "--overwrite-generated"), skill_root.parent))
        populate_worker_artifacts(profile_root)
        steps.append(run_step(python_command(credibility_script, "--input-json", credibility_payload, "--output", profile_root / '06_reports' / 'credibility' / 'credibility_direction_alpha.json'), skill_root.parent))
        steps.append(run_step(python_command(credibility_script, "--input-json", credibility_payload_2, "--output", profile_root / '06_reports' / 'credibility' / 'credibility_direction_beta.json'), skill_root.parent))
        steps.append(run_step(python_command(maturity_smoke_script), skill_root.parent))
        steps.append(run_step(python_command(maturity_script, "--workspace-root", profile_root, "--project-root", raw_project_root, "--profile", "generic", "--target-stage", "experiment_execution", "--write-workspace"), skill_root.parent))
        steps.append(run_step(python_command(entry_prompt_script, "--output", launch_prompt_path, "--project-root", profile_root, "--profile", profile), skill_root.parent))
        steps.append(run_step(python_command(export_script, "--output-dir", export_root, "--manifest-output", export_root / 'manifest.json', "--overwrite"), skill_root.parent))
        steps.append(run_step(python_command(export_root / 'research-pipeline-full' / 'scripts' / 'validate_skill_local.py', export_root / 'research-pipeline-full'), export_root / 'research-pipeline-full'))
        steps.append(run_step(python_command(prompt_pack_script, "--root", profile_root, "--profile", profile, "--overwrite"), skill_root.parent))
        steps.append(run_step(python_command(decision_sync_script, "--workspace-root", profile_root, "--source-project-root", raw_project_root, "--profile", profile, "--overwrite-generated"), skill_root.parent))
        steps.append(run_step(python_command(local_validator, skill_root), skill_root.parent))
        steps.append(run_step(python_command(workspace_validator, profile_root, profile), skill_root.parent))
        steps.append(run_step(python_command(progress_audit_script, "--workspace-root", profile_root, "--output", audit_report_path, "--format", "markdown"), skill_root.parent))
        auto_root = tmp / f"{profile}_autonomy"
        auto_audit_report_path = tmp / f"{profile}_autonomy_progress_audit.md"
        steps.append(run_step(python_command(init_script, "--root", auto_root, "--mode", "windowed-search", "--profile", profile, "--overwrite-generated", "--autonomous-mode"), skill_root.parent))
        steps.append(run_step(python_command(workspace_validator, auto_root, profile), skill_root.parent))
        steps.append(run_step(python_command(progress_audit_script, "--workspace-root", auto_root, "--output", auto_audit_report_path, "--format", "markdown"), skill_root.parent))

        legacy_auto_root = tmp / f"{profile}_autonomy_legacy_alias"
        steps.append(run_step(python_command(init_script, "--root", legacy_auto_root, "--mode", "windowed-search", "--profile", profile, "--overwrite-generated", "--experimental-autonomy"), skill_root.parent))
        steps.append(run_step(python_command(workspace_validator, legacy_auto_root, profile), skill_root.parent))

        launch_prompt_text = launch_prompt_path.read_text(encoding="utf-8") if launch_prompt_path.exists() else ""
        content_checks = {
            "entry_prompt_mentions_skill_md": "SKILL.md" in launch_prompt_text,
            "entry_prompt_mentions_strengthen_gate": "strengthen" in launch_prompt_text.lower(),
            "entry_prompt_mentions_reentry_gate": "rebuild generated scaffold artifacts" in launch_prompt_text.lower(),
            "entry_prompt_mentions_search_recheck": "search depth is sufficient" in launch_prompt_text.lower(),
            "entry_prompt_mentions_search_escalation": "escalate breadth, depth, or both" in launch_prompt_text.lower() or "escalate the next wave" in launch_prompt_text.lower(),
            "window_mode_files_exist": (profile_root / '06_reports' / 'STAGE_WINDOW_GUIDANCE.md').exists() and (profile_root / '06_reports' / 'WINDOW_MODE_SELECTION.md').exists() and (profile_root / '06_reports' / 'WINDOW_MODE_PLAN.csv').exists(),
            "search_trace_log_exists": (profile_root / '12_ingestion_logs' / 'search_trace_log.csv').exists(),
            "source_authority_log_exists": (profile_root / '12_ingestion_logs' / 'source_authority_log.csv').exists(),
            "credibility_summary_exists": (profile_root / '06_reports' / 'credibility' / 'credibility_summary.csv').exists(),
            "search_trace_log_has_rows": csv_data_row_count(profile_root / '12_ingestion_logs' / 'search_trace_log.csv') > 0,
            "source_authority_log_has_rows": csv_data_row_count(profile_root / '12_ingestion_logs' / 'source_authority_log.csv') > 0,
            "credibility_summary_has_rows": csv_data_row_count(profile_root / '06_reports' / 'credibility' / 'credibility_summary.csv') > 0,
            "implementation_assessment_has_rows": csv_data_row_count(profile_root / '05_validation' / 'implementation_assessment.csv') > 0,
            "implementation_backlog_has_rows": csv_data_row_count(profile_root / '05_validation' / 'implementation_backlog.csv') > 0,
            "route_readiness_has_rows": csv_data_row_count(profile_root / '05_validation' / 'route_readiness_matrix.csv') > 0,
            "implementation_readiness_exists": (profile_root / '05_validation' / 'IMPLEMENTATION_READINESS.md').exists(),
            "gate_d_has_implementation_repair": "repair_implementation_before_promotion" in (profile_root / '00_protocol' / 'USER_DECISION_GATES.md').read_text(encoding='utf-8'),
            "export_bundle_manifest_exists": (export_root / 'manifest.json').exists(),
            "export_bundle_dir_exists": (export_root / 'research-pipeline-full').exists(),
            "autonomous_mode_flag_verified": any("--autonomous-mode" in " ".join(step["command"]) for step in steps),
            "legacy_autonomy_alias_verified": any("--experimental-autonomy" in " ".join(step["command"]) for step in steps),
            "contract_upgrade_roundtrip": contract_upgrade_roundtrip(skill_root, tmp, profile),
        }
        profile_runs.append({
            "profile": profile,
            "workspace_root": str(profile_root),
            "steps": steps,
            "content_checks": content_checks,
            "status": "ready" if all(step["returncode"] == 0 for step in steps) and all(content_checks.values()) else "needs_attention"
        })

    status = "ready" if all(item["status"] == "ready" for item in profile_runs) else "needs_attention"
    result = {
        "skill_root": str(skill_root),
        "workspace_root": str(tmp),
        "profile_runs": profile_runs,
        "status": status,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if status == "ready" else 1)


def run_step(command: list[str], cwd: Path) -> dict:
    completed = run_command(command, cwd=cwd, check=False)
    return {
        "command": command,
        "returncode": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def contract_upgrade_roundtrip(skill_root: Path, tmp: Path, profile: str) -> bool:
    root = tmp / f"{profile}_legacy_contract"
    init_script = skill_root / "scripts" / "init_research_program.py"
    validator = skill_root / "scripts" / "validate_windowed_research_program.py"
    run_command(python_command(init_script, "--root", root, "--mode", "windowed-search", "--profile", profile), cwd=skill_root.parent, check=True)
    sentinel = root / "03_evidence" / "user_evidence.txt"
    sentinel.write_text("preserve me", encoding="utf-8")
    for name in ["code_inventory.csv", "implementation_evidence.csv", "implementation_assessment.csv", "implementation_backlog.csv", "route_readiness_matrix.csv", "IMPLEMENTATION_READINESS.md"]:
        (root / "05_validation" / name).unlink()
    before = run_command(python_command(validator, root, profile), cwd=skill_root.parent, check=False)
    before_payload = json.loads(before.stdout)
    run_command(python_command(init_script, "--root", root, "--mode", "windowed-search", "--profile", profile), cwd=skill_root.parent, check=True)
    after = run_command(python_command(validator, root, profile), cwd=skill_root.parent, check=False)
    return before_payload.get("status") == "contract_upgrade_required" and after.returncode == 0 and sentinel.read_text(encoding="utf-8") == "preserve me"


def populate_worker_artifacts(workspace_root: Path) -> None:
    worker_root = workspace_root / "01_window_runs"
    for folder in sorted(worker_root.glob("W*_*")):
        if folder.name in {"W01_coordinator", "W02_master_tables"}:
            continue
        append_csv_row(
            folder / "round_log.csv",
            {
                "round_id": "r001",
                "search_question": "Which evidence direction is strongest?",
                "query_set": "core query family",
                "candidate_count": "5",
                "retained_count": "2",
                "next_action": "continue validation",
            },
        )
        append_csv_row(
            folder / "source_index.csv",
            {
                "source_id": f"{folder.name.lower()}_s001",
                "title": f"{folder.name} source",
                "authors": "Example Author",
                "year": "2026",
                "source": "Example Journal",
                "evidence_class": "quantitative_experimental",
                "stable_link": f"https://example.com/{folder.name.lower()}",
                "direction": folder.name,
                "disposition": "retain_core",
            },
        )
        append_csv_row(
            folder / "evidence_matrix.csv",
            {
                "source_id": f"{folder.name.lower()}_s001",
                "evidence_class": "quantitative_experimental",
                "claim": "Example retained claim",
                "study_context": "example context",
                "evaluation_scope": "example scope",
                "evidence_strength": "strong",
                "transferability": "usable",
                "implementation_value": "high",
            },
        )
        append_csv_row(
            folder / "experiment_hypotheses.csv",
            {
                "hypothesis_id": f"{folder.name.lower()}_h001",
                "mapped_category": "model/method",
                "claim": "Example retained claim",
                "validation_placeholder": "run ablation",
                "priority": "immediate",
            },
        )


def append_csv_row(path: Path, row: dict[str, str]) -> None:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        fieldnames = reader.fieldnames or []
    with path.open("a", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writerow({field: row.get(field, "") for field in fieldnames})


def csv_data_row_count(path: Path) -> int:
    if not path.exists():
        return 0
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        try:
            next(reader)
        except StopIteration:
            return 0
        return sum(1 for _ in reader)


if __name__ == "__main__":
    main()
