#!/usr/bin/env python3
"""Exercise maturity levels, hard gates, and quant-profile blockers."""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path


sys.dont_write_bytecode = True

import assess_implementation_maturity as maturity


def main() -> None:
    model = maturity.load_model(Path(__file__).resolve().parents[1] / "references" / "implementation-maturity-model.json")
    with tempfile.TemporaryDirectory(prefix="implementation_maturity_smoke_") as temp_dir:
        root = Path(temp_dir)
        project = root / "project"
        project.mkdir()
        (project / "main.py").write_text("print('ok')\n", encoding="utf-8")
        empty_project = root / "empty_project"
        empty_project.mkdir()
        scenarios = {
            "m0_blocks_execution": run_scenario(root, empty_project, model, "experiment_execution", [], "generic", include_inventory=False),
            "m2_allows_execution": run_scenario(root, project, model, "experiment_execution", evidence("build", "smoke"), "generic"),
            "m3_allows_promotion": run_scenario(root, project, model, "result_promotion", evidence("build", "smoke", "test", "integrity", "static_analysis"), "generic"),
            "m4_allows_benchmark_freeze": run_scenario(root, project, model, "benchmark_freeze", evidence("build", "smoke", "test", "integrity", "static_analysis", "benchmark", "reproduction"), "generic"),
            "m5_allows_release": run_scenario(root, project, model, "release", evidence("traceability", "build", "smoke", "runtime", "environment", "test", "integrity", "static_analysis", "benchmark", "benchmark_freeze", "reproduction", "output_contract", "release", "monitoring"), "generic"),
            "critical_failure_blocks_high_level": run_scenario(root, project, model, "benchmark_freeze", evidence("build", "smoke", "test", "integrity", "static_analysis", "benchmark", "reproduction") + evidence("integrity", status="fail", start=100), "generic"),
            "not_run_blocks_execution": run_scenario(root, project, model, "experiment_execution", evidence("smoke", status="not_run"), "generic"),
            "missing_route_id_blocks_execution": run_scenario(
                root,
                project,
                model,
                "experiment_execution",
                evidence("build", "smoke"),
                "generic",
                credibility_rows=[{"route_id": "", "route_board": "stable", "direction": "route-alpha", "credibility_score_35": "30"}],
            ),
            "quant_missing_checks_block": run_scenario(root, project, model, "experiment_execution", evidence("build", "smoke"), "quant-research"),
        }

    checks = {
        "m0_blocks_execution": scenario_is(scenarios["m0_blocks_execution"], "M0", "implementation_required"),
        "m2_allows_execution": scenario_is(scenarios["m2_allows_execution"], "M2", "ready_for_execution"),
        "m3_allows_promotion": scenario_is(scenarios["m3_allows_promotion"], "M3", "ready_for_promotion"),
        "m4_allows_benchmark_freeze": scenario_is(scenarios["m4_allows_benchmark_freeze"], "M4", "ready_for_benchmark_freeze"),
        "m5_allows_release": scenario_is(scenarios["m5_allows_release"], "M5", "ready_for_release"),
        "critical_failure_blocks_high_level": scenarios["critical_failure_blocks_high_level"]["route_readiness"][0]["implementation_gate"] == "fail" and scenarios["critical_failure_blocks_high_level"]["assessments"][0]["maturity_level"] == "M2",
        "not_run_blocks_execution": scenarios["not_run_blocks_execution"]["route_readiness"][0]["implementation_gate"] == "fail",
        "missing_route_id_blocks_execution": scenarios["missing_route_id_blocks_execution"]["route_readiness"][0]["research_gate"] == "mapping_required" and scenarios["missing_route_id_blocks_execution"]["route_readiness"][0]["gated_status"] == "blocked",
        "quant_missing_checks_block": "required quant evidence missing" in scenarios["quant_missing_checks_block"]["route_readiness"][0]["blocking_reasons"],
    }
    result = {"checks": checks, "status": "ready" if all(checks.values()) else "needs_attention"}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result["status"] == "ready" else 1)


def run_scenario(
    root: Path,
    project: Path,
    model: dict,
    target_stage: str,
    evidence_rows: list[dict[str, str]],
    profile: str,
    include_inventory: bool = True,
    credibility_rows: list[dict[str, str]] | None = None,
) -> dict:
    workspace = root / f"workspace_{target_stage}_{profile}_{len(list(root.glob('workspace_*')))}"
    validation = workspace / "05_validation"
    credibility = workspace / "06_reports" / "credibility"
    validation.mkdir(parents=True)
    credibility.mkdir(parents=True)
    maturity.write_csv(validation / "code_inventory.csv", maturity.INVENTORY_HEADERS, [inventory_row()] if include_inventory else [])
    maturity.write_csv(validation / "implementation_evidence.csv", maturity.EVIDENCE_HEADERS, evidence_rows)
    maturity.write_csv(
        credibility / "credibility_summary.csv",
        ["route_id", "route_board", "direction", "credibility_score_35"],
        credibility_rows or [{"route_id": "route-alpha", "route_board": "stable", "direction": "alpha", "credibility_score_35": "30"}],
    )
    return maturity.assess(workspace, project, profile, target_stage, model)


def inventory_row() -> dict[str, str]:
    return {
        "component_id": "component-alpha",
        "route_id": "route-alpha",
        "research_claim_ids": "claim-alpha",
        "path": "main.py",
        "component_type": "runtime_entrypoint",
        "active_status": "active",
        "entrypoint": "main.py",
        "dependency_surface": "pyproject.toml",
        "test_surface": "tests",
        "benchmark_surface": "benchmark.json",
    }


def evidence(*types: str, status: str = "pass", start: int = 1) -> list[dict[str, str]]:
    return [
        {
            "evidence_id": f"E{index}",
            "route_id": "route-alpha",
            "component_id": "component-alpha",
            "evidence_type": evidence_type,
            "command_or_artifact": evidence_type,
            "status": status,
            "observed_at": "2026-01-01T00:00:00Z",
            "output_reference": f"artifacts/{evidence_type}.txt",
            "notes": "smoke fixture",
        }
        for index, evidence_type in enumerate(types, start=start)
    ]


def scenario_is(result: dict, level: str, gated_status: str) -> bool:
    return result["assessments"][0]["maturity_level"] == level and result["route_readiness"][0]["gated_status"] == gated_status


if __name__ == "__main__":
    main()
