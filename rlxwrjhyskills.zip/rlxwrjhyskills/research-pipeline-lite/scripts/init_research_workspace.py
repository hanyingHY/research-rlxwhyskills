#!/usr/bin/env python3
"""Create a lightweight research workspace scaffold."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


FOCUSED_STRENGTHENING_COLUMNS = ["focus_type", "focus_name", "strengthen_goal", "evidence_gap", "preferred_action", "priority", "notes"]
SEARCH_MODE_COLUMNS = ["phase_scope", "recommended_search_mode", "approved_search_mode", "local_project_corpus", "model_prior_knowledge", "external_literature_search", "user_choice_state", "notes"]
SEARCH_ESCALATION_COLUMNS = ["escalation_level", "scope_change", "round_change", "source_family_change", "trigger_reason", "user_state", "notes"]
WINDOW_MODE_COLUMNS = ["stage", "recommended_mode", "recommended_window_count", "single_window_path", "multi_window_path", "user_assistance_required", "notes"]


def main() -> None:
    parser = argparse.ArgumentParser(description="Initialize a lightweight research workspace")
    parser.add_argument("--root", required=True)
    parser.add_argument("--overwrite-generated", action="store_true")
    args = parser.parse_args()

    root = Path(args.root)
    root.mkdir(parents=True, exist_ok=True)

    for name in ["00_raw", "01_index", "02_retained", "03_output"]:
        (root / name).mkdir(parents=True, exist_ok=True)

    write_csv(root / "01_index" / "source_index.csv", ["source_id", "title", "author_or_org", "year", "source_type", "evidence_class", "stable_link", "topic", "status"], overwrite=args.overwrite_generated)
    write_csv(root / "02_retained" / "retained_evidence.csv", ["source_id", "evidence_class", "claim", "study_context", "method_summary", "evidence_strength", "transferability", "risk_or_limitation"], overwrite=args.overwrite_generated)
    write_csv(root / "03_output" / "action_map.csv", ["source_id", "action_type", "proposed_action", "confidence", "validation_needed", "priority"], overwrite=args.overwrite_generated)
    write_csv(root / "03_output" / "focused_strengthening_plan.csv", FOCUSED_STRENGTHENING_COLUMNS, overwrite=args.overwrite_generated)
    write_csv(root / "03_output" / "search_mode_plan.csv", SEARCH_MODE_COLUMNS, overwrite=args.overwrite_generated)
    write_csv(root / "03_output" / "search_escalation_plan.csv", SEARCH_ESCALATION_COLUMNS, overwrite=args.overwrite_generated)
    write_csv(root / "03_output" / "window_mode_plan.csv", WINDOW_MODE_COLUMNS, overwrite=args.overwrite_generated)
    memo = root / "03_output" / "summary_memo.md"
    if not memo.exists():
        memo.write_text("# Summary Memo\n\n## Main Question\n\n## Strongest Evidence\n\n## Immediate Actions\n\n## Deferred Actions\n\n## Risks\n", encoding="utf-8")
    next_user_decision = root / "03_output" / "NEXT_USER_DECISION.md"
    if not next_user_decision.exists():
        next_user_decision.write_text(
            "# Next User Decision\n\n## Current Lite Result\n\n## Recommended Default\n\n## Recommended Options\n\n1. consolidate\n2. optimize_more\n3. strengthen\n4. search_more\n5. choose_stable_mode\n6. choose_aggressive_mode\n7. move_into_full_pipeline\n8. stop\n\n## User Decision\n",
            encoding="utf-8",
        )
    reentry_decision = root / "03_output" / "REENTRY_DECISION.md"
    if not reentry_decision.exists():
        reentry_decision.write_text(
            "# Reentry Decision\n\n## Purpose\n\nMake the user choose how to handle an existing scaffolded or partially completed lite workspace.\n\n## Current Workspace State\n\n## Recommended Default\n\n## Options\n\n1. continue_current_workspace\n2. repair_current_workspace\n3. rebuild_generated_scaffold_keep_raw_corpus\n4. stop\n\n## User Decision\n\n## Notes\n",
            encoding="utf-8",
        )
    phase_state = root / "03_output" / "PHASE_STATE.md"
    if not phase_state.exists():
        phase_state.write_text(
            "# Phase State\n\ncurrent_phase: lite_summary_ready\nstate_status: pending_user_decision\nrecommended_default: consolidate\nallowed_next_actions: consolidate, optimize_more, strengthen, search_more, choose_stable_mode, choose_aggressive_mode, move_into_full_pipeline, stop\n",
            encoding="utf-8",
        )
    control_center = root / "03_output" / "LITE_CONTROL_CENTER.md"
    if not control_center.exists():
        control_center.write_text(
            "# Lite Control Center\n\n## Current Operating Posture\n\n1. current phase: see `PHASE_STATE.md`\n2. next user decision: see `NEXT_USER_DECISION.md`\n\n## Primary Operator Files\n\n1. `summary_memo.md`\n2. `NEXT_USER_DECISION.md`\n3. `REENTRY_DECISION.md`\n4. `PHASE_STATE.md`\n5. `USER_CHECKPOINT_PROMPTS.md`\n6. `USER_REENTRY_PROMPTS.md`\n7. `USER_FOCUSED_STRENGTHENING_PROMPTS.md`\n8. `USER_SEARCH_MODE_PROMPTS.md`\n9. `SEARCH_MODE_SELECTION.md`\n10. `search_mode_plan.csv`\n11. `USER_SEARCH_ESCALATION_PROMPTS.md`\n12. `SEARCH_ESCALATION_SELECTION.md`\n13. `search_escalation_plan.csv`\n14. `UNIFIED_BROADCAST_PROMPT.md`\n15. `OPERATOR_HANDOFF_CONTRACT.md`\n16. `STABLE_OPTIONS.md`\n17. `AGGRESSIVE_OPTIONS.md`\n18. `FOCUSED_STRENGTHENING_SELECTION.md`\n19. `focused_strengthening_plan.csv`\n\n## Control Rules\n\n1. do not silently broaden scope\n2. do not move into the full pipeline without an explicit user choice\n3. keep stable and aggressive options separate when both are present\n4. if the current lite packet is usable but not clearly final, explicitly ask whether the user wants one more bounded optimization wave\n5. if the user chooses strengthen, ask what specifically should be strengthened first\n6. if the user says search depth is insufficient, run an escalated search wave instead of stopping\n7. before a new search stage begins, ask whether it should use only existing knowledge, only the existing project corpus, or allow external literature search\n8. if the workspace already exists, ask whether to continue, repair, or rebuild generated scaffold artifacts\n9. if the active environment cannot write files, run scripts, or open windows, emit the operator handoff contract instead of pretending the blocked step was completed\n\n## Immediate Use\n\n1. read `summary_memo.md`\n2. read `NEXT_USER_DECISION.md`\n3. if resuming a half-finished lite workspace, review `REENTRY_DECISION.md` first\n4. if strengthen mode is next, review `FOCUSED_STRENGTHENING_SELECTION.md` and `focused_strengthening_plan.csv`\n5. before another search stage begins, review `SEARCH_MODE_SELECTION.md` and `search_mode_plan.csv`\n6. if search depth is questioned, review `SEARCH_ESCALATION_SELECTION.md` and `search_escalation_plan.csv`\n7. if the packet is already usable, ask whether the user wants `optimize_more` before freezing it\n8. send the copy-paste prompt from `USER_CHECKPOINT_PROMPTS.md`\n9. if the environment limit blocks the next required action, fill `OPERATOR_HANDOFF_CONTRACT.md` and stop at the current checkpoint\n",
            encoding="utf-8",
        )
    checkpoint_prompts = root / "03_output" / "USER_CHECKPOINT_PROMPTS.md"
    if not checkpoint_prompts.exists():
        checkpoint_prompts.write_text(
            "# User Checkpoint Prompts\n\n## Lite Prompt\n\nPurpose: decide what to do after the first lite summary is ready.\n\nRecommended default: consolidate if the shortlist is already useful; optimize_more if the packet is usable but one more bounded pass could still improve it; strengthen if the evidence still feels thin.\n\nOption impact:\n1. consolidate: freeze the current lite result and use it as the working summary\n2. optimize_more: run one more bounded lite-quality improvement wave before freezing the current packet\n3. strengthen: improve the evidence base before acting on it, with explicit user-selected strengthening targets\n4. search_more: run another lite search wave because the current search depth still feels too thin\n5. choose_stable_mode: continue with the lower-risk options already supported by direct evidence\n6. choose_aggressive_mode: continue with the higher-upside or more novel options that need more risk tolerance\n7. move_into_full_pipeline: escalate into the full multi-stage research program\n8. stop: pause for review\n\n```text\nWe finished the current lite research wave.\n\nRecommended default: consolidate if the current packet is already useful, optimize_more if one more bounded quality pass would help, strengthen if the evidence still feels thin, or search_more if the current search depth still feels insufficient.\n\nIf you choose optimize_more, specify what should improve in the current lite packet.\nIf you choose strengthen, also specify which directions, datasets, papers, claim bundles, or source families should be reinforced first.\nIf you choose search_more, specify whether the next wave should go broader, deeper, or both.\n\nCurrent options:\n1. consolidate the current result\n2. run one more bounded optimization wave on the current lite packet\n3. strengthen the evidence base\n4. run another search wave\n5. choose the stable option set\n6. choose the aggressive option set\n7. move into the full research pipeline\n8. stop for review\n```\n",
            encoding="utf-8",
        )
    reentry_prompts = root / "03_output" / "USER_REENTRY_PROMPTS.md"
    if not reentry_prompts.exists():
        reentry_prompts.write_text(
            "# User Reentry Prompts\n\n## Purpose\n\nGive the user a visible choice whenever a lite workspace already exists but may be stale, partial, or inconsistent.\n\n## User Prompt\n\n```text\nThis project already contains a scaffolded or partially completed lite workspace.\n\nPlease choose one:\n1. continue_current_workspace\n2. repair_current_workspace\n3. rebuild_generated_scaffold_keep_raw_corpus\n4. stop\n\nUse continue when the current scaffold is sound enough to keep.\nUse repair when the scaffold is mostly right but some artifacts need correction.\nUse rebuild when the generated lite control artifacts should be refreshed while keeping the raw corpus and non-generated research materials.\n```\n",
            encoding="utf-8",
        )
    strengthening_selection = root / "03_output" / "FOCUSED_STRENGTHENING_SELECTION.md"
    if not strengthening_selection.exists():
        strengthening_selection.write_text(
            "# Focused Strengthening Selection\n\n## Purpose\n\nChoose exactly which directions, datasets, papers, claim bundles, or source families should be strengthened before the lite workflow broadens or escalates.\n\n## Candidate Strengthening Targets\n\n## Recommended Targets\n\n## User Choice\n\n## Notes\n",
            encoding="utf-8",
        )
    strengthening_prompts = root / "03_output" / "USER_FOCUSED_STRENGTHENING_PROMPTS.md"
    if not strengthening_prompts.exists():
        strengthening_prompts.write_text(
            "# User Focused Strengthening Prompts\n\n## Purpose\n\nGive the user a direct way to choose what should be reinforced before the lite workflow broadens or escalates.\n\n## User Prompt\n\n```text\nYou chose strengthen mode.\n\nPlease specify what should be strengthened first. You can target one or more of:\n1. directions\n2. datasets\n3. papers\n4. claim bundles\n5. source families such as interviews, surveys, policy sets, archival records, or stakeholder materials\n\nFor each target, record:\n1. focus_type\n2. focus_name\n3. strengthen_goal\n4. evidence_gap\n5. preferred_action\n6. priority\n7. notes\n\nRecord the final choice in:\n1. FOCUSED_STRENGTHENING_SELECTION.md\n2. focused_strengthening_plan.csv\n```\n",
            encoding="utf-8",
        )
    search_mode_selection = root / "03_output" / "SEARCH_MODE_SELECTION.md"
    if not search_mode_selection.exists():
        search_mode_selection.write_text(
            "# Search Mode Selection\n\n## Purpose\n\nChoose whether the next lite research stage should rely only on model prior knowledge, only on the existing project corpus, or on external literature search.\n\n## Available Search Modes\n\n1. knowledge_only\n2. project_corpus_only\n3. external_search_enabled\n\n## User Choice\n\n## Notes\n",
            encoding="utf-8",
        )
    search_mode_prompts = root / "03_output" / "USER_SEARCH_MODE_PROMPTS.md"
    if not search_mode_prompts.exists():
        search_mode_prompts.write_text(
            "# User Search Mode Prompts\n\n## Purpose\n\nAsk the user whether the next lite stage should use only model prior knowledge, only the existing project corpus, or external literature search.\n\n## User Prompt\n\n```text\nBefore the next lite research stage begins, please choose the search mode:\n1. knowledge_only\n2. project_corpus_only\n3. external_search_enabled\n\nUse knowledge_only when you want reasoning without adding new external sources.\nUse project_corpus_only when you want the agent to stay inside the files already present in the project.\nUse external_search_enabled when you want outward paper, literature, or authority search to be allowed.\n\nRecord the final choice in:\n1. SEARCH_MODE_SELECTION.md\n2. search_mode_plan.csv\n```\n",
            encoding="utf-8",
        )
    search_escalation_selection = root / "03_output" / "SEARCH_ESCALATION_SELECTION.md"
    if not search_escalation_selection.exists():
        search_escalation_selection.write_text(
            "# Search Escalation Selection\n\n## Purpose\n\nDecide whether the current search depth is sufficient or whether another search wave should run at a higher breadth, depth, or both.\n\n## Current Search Sufficiency Judgment\n\n## Escalation Levels\n\n1. level_0_initial\n2. level_1_broaden_queries\n3. level_2_broaden_sources\n4. level_3_increase_rounds\n5. level_4_escalate_to_full_search_program\n\n## User Choice\n\n## Notes\n",
            encoding="utf-8",
        )
    search_escalation_prompts = root / "03_output" / "USER_SEARCH_ESCALATION_PROMPTS.md"
    if not search_escalation_prompts.exists():
        search_escalation_prompts.write_text(
            "# User Search Escalation Prompts\n\n## Purpose\n\nAsk the user whether the current lite search depth is sufficient, and if not, which escalation level should be used next.\n\n## User Prompt\n\n```text\nWe completed the current lite search wave.\n\nPlease decide whether the current search depth is sufficient.\nIf not, choose the next escalation level:\n1. level_1_broaden_queries\n2. level_2_broaden_sources\n3. level_3_increase_rounds\n4. level_4_escalate_to_full_search_program\n\nAlso specify why the current search still feels thin.\n\nRecord the final choice in:\n1. SEARCH_ESCALATION_SELECTION.md\n2. search_escalation_plan.csv\n```\n",
            encoding="utf-8",
        )
    stage_window_guidance = root / "03_output" / "STAGE_WINDOW_GUIDANCE.md"
    if not stage_window_guidance.exists():
        stage_window_guidance.write_text(
            "# Stage Window Guidance\n\n## Initial Lite Pass\n\nSingle-window path:\n1. one agent can inventory, shortlist, and summarize the first pass.\n2. if autonomous mode is active and no window help is available, run this as the first serial phase in the same window.\n\nMulti-window path:\n1. if the corpus is already messy or large, ask the user to help open 2-3 windows for intake, evidence extraction, and summary comparison.\n\n## Strengthen Wave\n\nSingle-window path:\n1. one agent can reinforce a small set of directions, datasets, papers, claim bundles, or source families.\n2. if autonomous mode is active and no window help is available, run strengthening targets sequentially in one window.\n\nMulti-window path:\n1. if there are multiple strengthening targets, ask the user to help open 2-4 windows so each target can be reinforced separately.\n\n## Search-More Wave\n\nSingle-window path:\n1. one agent can run the next broadened or deepened search wave when the expansion is still modest.\n2. if autonomous mode is active and no window help is available, run successive search-more waves in the same window while preserving the escalation log.\n\nMulti-window path:\n1. if breadth and depth both need to increase, ask the user to help open 2-4 windows split by source family or question family.\n\n## Full-Pipeline Handoff\n\nSingle-window path:\n1. one agent may still prepare the handoff if the user wants a conservative transition.\n2. if autonomous mode is active and no window help is available, prepare the handoff serially in one window rather than blocking on missing parallel lanes.\n\nMulti-window path:\n1. if the user chooses full escalation, ask whether they want help opening the recommended windows for the full program before launch planning begins.\n",
            encoding="utf-8",
        )
    window_mode_selection = root / "03_output" / "WINDOW_MODE_SELECTION.md"
    if not window_mode_selection.exists():
        window_mode_selection.write_text(
            "# Window Mode Selection\n\n## Purpose\n\nChoose whether the next stage should stay in one window or use multiple windows.\n\n## Current Stage\n\n## Recommended Default\n\n## Available Modes\n\n1. single_window\n2. multi_window\n\n## Suggested Window Count\n\n## User Choice\n\n## Notes\n",
            encoding="utf-8",
        )
    user_window_mode_prompts = root / "03_output" / "USER_WINDOW_MODE_PROMPTS.md"
    if not user_window_mode_prompts.exists():
        user_window_mode_prompts.write_text(
            "# User Window Mode Prompts\n\n## Purpose\n\nAsk the user whether the next stage should stay in one window or use multiple windows, and ask for help opening those windows when needed.\n\n## User Prompt\n\n```text\nWe are choosing the execution mode for the next stage.\n\nPlease decide:\n1. single_window\n2. multi_window\n\nIf you choose multi_window, also confirm how many windows should be opened and help open them, because many agents cannot open extra windows by themselves.\n\nIf autonomous mode is active and you cannot help open windows, the lite workflow should fall back to one-window phased execution instead of blocking. In that fallback, the same lite responsibilities are executed serially in one window:\n1. intake and shortlist pass\n2. strengthening or search-more pass\n3. stable-vs-aggressive option pass\n4. escalation-or-handoff pass\n\nRecord the final choice in:\n1. WINDOW_MODE_SELECTION.md\n2. window_mode_plan.csv\n```\n",
            encoding="utf-8",
        )
    broadcast_prompt = root / "03_output" / "UNIFIED_BROADCAST_PROMPT.md"
    if not broadcast_prompt.exists():
        broadcast_prompt.write_text(
            "# Unified Broadcast Prompt\n\nCurrent phase: lite_summary_ready\nCurrent mode: wait_for_user_decision\n\nAuthoritative files:\n1. summary_memo.md\n2. NEXT_USER_DECISION.md\n3. PHASE_STATE.md\n\nRequired action:\n1. review the lite result\n2. choose consolidate, optimize_more, strengthen, stable, aggressive, full pipeline, or stop\n3. if optimize_more is chosen, run one more bounded lite-quality improvement wave before freezing the packet\n4. if strengthen is chosen, ask which directions, datasets, papers, claim bundles, or source families should be reinforced first\n5. if the workspace already exists, ask whether to continue, repair, or rebuild generated scaffold artifacts\n\nDo not silently broaden scope:\n1. do not move into the full pipeline without an explicit user choice\n",
            encoding="utf-8",
        )
    operator_handoff_contract = root / "03_output" / "OPERATOR_HANDOFF_CONTRACT.md"
    if not operator_handoff_contract.exists():
        operator_handoff_contract.write_text(
            "# Operator Handoff Contract\n\n## Purpose\n\nUse this contract when the active environment can analyze the workspace but cannot perform the next write, script execution, or window-launch step directly.\n\n## Required Fields\n\n1. objective\n2. environment_limit\n3. required_operator_action\n4. input_paths\n5. output_paths\n6. verification_rule\n7. resume_prompt\n\n## Template\n\n```text\nobjective: <ONE_SENTENCE_OBJECTIVE>\nenvironment_limit: <no_local_writes|no_subprocess_execution|no_multi_window_launch|other>\nrequired_operator_action: <EXACT_ACTION>\ninput_paths:\n- <PATH_A>\n- <PATH_B>\noutput_paths:\n- <PATH_C>\n- <PATH_D>\nverification_rule: <HOW_TO_CONFIRM_SUCCESS>\nresume_prompt: <COPY_PASTE_READY_PROMPT>\n```\n\n## Rule\n\nDo not claim the blocked step was completed if the environment limit prevented it. Emit this contract and stop at the current checkpoint.\n",
            encoding="utf-8",
        )
    autonomous_serial_plan = root / "03_output" / "AUTONOMOUS_SERIAL_PLAN.md"
    if not autonomous_serial_plan.exists():
        autonomous_serial_plan.write_text(
            "# Autonomous Serial Plan\n\n## Purpose\n\nUse this plan when the lite workflow is running in autonomous mode but multi-window help is unavailable.\n\n## Activation Rule\n\nUse this plan when both are true:\n\n1. autonomous execution is active for the current run\n2. the user or environment cannot support multi-window execution\n\n## Phase Order\n\n1. intake and shortlist pass\n2. strengthening or search-more pass\n3. stable-vs-aggressive option pass\n4. escalation-or-handoff pass\n\n## Per-phase rule\n\nFor each phase:\n\n1. finish the current phase outputs before moving on\n2. preserve the same evidence and decision standards the multi-window version would have used\n3. record what changed before the next serial phase begins\n\n## Stop Conditions\n\nStop and ask again if one of these appears:\n\n1. scope expands materially\n2. the next phase requires an explicit user choice\n3. evidence remains too thin to justify the next phase\n\n## Completion Rule\n\nSerial execution is a concurrency fallback, not a lower-quality fallback.\n",
            encoding="utf-8",
        )
    stable_options = root / "03_output" / "STABLE_OPTIONS.md"
    if not stable_options.exists():
        stable_options.write_text(
            "# Stable Options\n\n## Direct Evidence First\n\n## Lower-Risk Choices\n\n## Simpler Next Steps\n",
            encoding="utf-8",
        )
    aggressive_options = root / "03_output" / "AGGRESSIVE_OPTIONS.md"
    if not aggressive_options.exists():
        aggressive_options.write_text(
            "# Aggressive Options\n\n## Higher-Upside Ideas\n\n## More Novel Or Transfer-Heavy Ideas\n\n## Extra Validation Needed\n",
            encoding="utf-8",
        )
    print(root)


def write_csv(path: Path, columns: list[str], overwrite: bool = False) -> None:
    if path.exists() and not overwrite:
        return
    existing_rows: list[dict[str, str]] = []
    if path.exists() and overwrite:
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            existing_rows = list(reader)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for row in existing_rows:
            writer.writerow({column: row.get(column, "") for column in columns})


if __name__ == "__main__":
    main()
