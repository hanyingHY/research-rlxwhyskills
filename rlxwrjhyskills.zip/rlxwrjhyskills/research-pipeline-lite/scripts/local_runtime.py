#!/usr/bin/env python3
"""Local runtime helpers for research-pipeline-lite."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


sys.dont_write_bytecode = True


def child_env() -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env


def python_command(script: object, *args: object) -> list[str]:
    return [sys.executable, "-B", str(script), *(str(arg) for arg in args)]


def run_command(command: list[str], cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        env=child_env(),
        check=check,
    )


def run_json(command: list[str], cwd: Path | None = None) -> dict:
    completed = run_command(command, cwd=cwd, check=True)
    return json.loads(completed.stdout)
