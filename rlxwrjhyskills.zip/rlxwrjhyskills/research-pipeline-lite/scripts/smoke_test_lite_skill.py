#!/usr/bin/env python3
"""End-to-end smoke test for research-pipeline-lite."""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True

from local_runtime import python_command, run_command


def main() -> None:
    skill_root = Path(__file__).resolve().parents[1]
    tmp = Path(tempfile.mkdtemp(prefix="research_pipeline_lite_smoke_"))

    init_script = skill_root / "scripts" / "init_research_workspace.py"
    entry_prompt_script = skill_root / "scripts" / "generate_entry_prompts.py"
    progress_audit_script = skill_root / "scripts" / "assess_workspace_progress.py"
    decision_sync_script = skill_root / "scripts" / "sync_decision_surfaces.py"
    export_script = skill_root / "scripts" / "export_skill_bundle.py"
    local_validator = skill_root / "scripts" / "validate_skill_local.py"
    validator_script = skill_root / "scripts" / "validate_research_workspace.py"
    launch_prompt_path = tmp / "lite_launch_prompts.md"
    export_root = tmp / "lite_export"
    audit_report_path = tmp / "lite_progress_audit.md"

    local_validate_step = run_step(python_command(local_validator, skill_root), skill_root.parent)
    prompt_step = run_step(python_command(entry_prompt_script, "--output", launch_prompt_path, "--project-root", tmp), skill_root.parent)
    export_step = run_step(python_command(export_script, "--output-dir", export_root, "--manifest-output", export_root / 'manifest.json', "--overwrite"), skill_root.parent)
    init_step = run_step(python_command(init_script, "--root", tmp), skill_root.parent)
    (tmp / "03_output" / "implementation_snapshot.csv").write_text(
        "route_id,code_present,entrypoint_present,test_surface_present,executable_evidence_status,implementation_level,critical_gaps,escalate_to_full\n"
        "route-alpha,yes,yes,no,not_run,M1,tests and executable evidence missing,yes\n",
        encoding="utf-8",
    )
    validate_step = run_step(python_command(validator_script, tmp), skill_root.parent)
    progress_step = run_step(python_command(progress_audit_script, "--workspace-root", tmp, "--output", audit_report_path, "--format", "markdown"), skill_root.parent)
    sync_step = run_step(python_command(decision_sync_script, "--workspace-root", tmp, "--source-project-root", tmp, "--overwrite-generated"), skill_root.parent)
    export_validate_step = run_step(python_command(export_root / 'research-pipeline-lite' / 'scripts' / 'validate_skill_local.py', export_root / 'research-pipeline-lite'), export_root / 'research-pipeline-lite')

    prompt_payload = extract_prompt_contract(launch_prompt_path)
    sync_payload = json.loads(sync_step["stdout"])
    content_checks = {
        "prompt_mentions_skill_md": "SKILL.md" in prompt_payload,
        "prompt_mentions_strengthen_gate": "strengthen mode" in prompt_payload.lower(),
        "prompt_mentions_reentry_gate": "partial lite workspace" in prompt_payload.lower() or "rebuild generated scaffold artifacts" in prompt_payload.lower(),
        "prompt_mentions_search_recheck": "search depth is sufficient" in prompt_payload.lower(),
        "prompt_mentions_search_escalation": "escalate breadth, depth, or both" in prompt_payload.lower() or "escalate the next wave" in prompt_payload.lower(),
        "export_bundle_manifest_exists": (export_root / 'manifest.json').exists(),
        "export_bundle_dir_exists": (export_root / 'research-pipeline-lite').exists(),
        "implementation_snapshot_exists": (tmp / '03_output' / 'implementation_snapshot.csv').exists(),
        "summary_memo_has_implementation_sections": all(marker in (tmp / '03_output' / 'summary_memo.md').read_text(encoding='utf-8') for marker in ["## Implementation Maturity", "## Critical Code Gaps", "## Full Pipeline Escalation"]),
        "contract_upgrade_roundtrip": contract_upgrade_roundtrip(skill_root, tmp),
        "implementation_gap_recommends_full": sync_payload.get("implementation_requires_full") is True and sync_payload.get("next_user_default") == "move_into_full_pipeline",
    }

    status = "ready" if local_validate_step["returncode"] == 0 and prompt_step["returncode"] == 0 and export_step["returncode"] == 0 and init_step["returncode"] == 0 and validate_step["returncode"] == 0 and progress_step["returncode"] == 0 and sync_step["returncode"] == 0 and export_validate_step["returncode"] == 0 and all(content_checks.values()) else "needs_attention"
    result = {
        "skill_root": str(skill_root),
        "workspace_root": str(tmp),
        "steps": [local_validate_step, prompt_step, export_step, init_step, validate_step, progress_step, sync_step, export_validate_step],
        "content_checks": content_checks,
        "status": status,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if status == "ready" else 1)


def run_step(command: list[str], cwd: Path) -> dict:
    completed = run_command(command, cwd=cwd, check=False)
    return {
        "command": command,
        "returncode": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def contract_upgrade_roundtrip(skill_root: Path, tmp: Path) -> bool:
    root = tmp / "legacy_contract"
    init_script = skill_root / "scripts" / "init_research_workspace.py"
    validator = skill_root / "scripts" / "validate_research_workspace.py"
    run_command(python_command(init_script, "--root", root), cwd=skill_root.parent, check=True)
    sentinel = root / "02_retained" / "user_evidence.txt"
    sentinel.write_text("preserve me", encoding="utf-8")
    (root / "03_output" / "implementation_snapshot.csv").unlink()
    summary = root / "03_output" / "summary_memo.md"
    summary.write_text("# Summary Memo\n\n## Main Question\n\nLegacy content remains.\n", encoding="utf-8")
    before = run_command(python_command(validator, root), cwd=skill_root.parent, check=False)
    before_payload = json.loads(before.stdout)
    run_command(python_command(init_script, "--root", root), cwd=skill_root.parent, check=True)
    after = run_command(python_command(validator, root), cwd=skill_root.parent, check=False)
    return before_payload.get("status") == "contract_upgrade_required" and after.returncode == 0 and sentinel.read_text(encoding="utf-8") == "preserve me" and "Legacy content remains" in summary.read_text(encoding="utf-8")


def extract_prompt_contract(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8")


if __name__ == "__main__":
    main()
