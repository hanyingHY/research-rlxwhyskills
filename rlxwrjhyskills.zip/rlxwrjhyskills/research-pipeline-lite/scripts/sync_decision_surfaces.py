#!/usr/bin/env python3
"""Synchronize user-facing decision surfaces for a lite research workspace."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True

from local_runtime import python_command, run_json


STRENGTHENING_COLUMNS = ["focus_type", "focus_name", "strengthen_goal", "evidence_gap", "preferred_action", "priority", "notes"]
SEARCH_MODE_COLUMNS = ["phase_scope", "recommended_search_mode", "approved_search_mode", "local_project_corpus", "model_prior_knowledge", "external_literature_search", "user_choice_state", "notes"]
SEARCH_ESCALATION_COLUMNS = ["escalation_level", "scope_change", "round_change", "source_family_change", "trigger_reason", "user_state", "notes"]
WINDOW_MODE_COLUMNS = ["stage", "recommended_mode", "recommended_window_count", "single_window_path", "multi_window_path", "user_assistance_required", "notes"]


def main() -> None:
    parser = argparse.ArgumentParser(description="Sync decision surfaces for a lite research workspace")
    parser.add_argument("--workspace-root", required=True)
    parser.add_argument("--source-project-root")
    parser.add_argument("--overwrite-generated", action="store_true")
    args = parser.parse_args()

    workspace_root = Path(args.workspace_root).resolve()
    source_project_root = Path(args.source_project_root).resolve() if args.source_project_root else None

    audit = run_json([
        *python_command(
            Path(__file__).resolve().parent / "assess_workspace_progress.py",
            "--workspace-root",
            workspace_root,
        )
    ])

    source_markers = detect_partial_markers(source_project_root) if source_project_root else None
    inventory = collect_top_level_inventory(source_project_root)
    implementation_snapshot = read_csv_rows(workspace_root / "03_output" / "implementation_snapshot.csv")
    implementation_requires_full = any(row.get("escalate_to_full", "").strip().lower() in {"yes", "true", "1"} or row.get("critical_gaps", "").strip() for row in implementation_snapshot)
    strengthening_rows = recommend_strengthening_rows(inventory)
    search_mode_rows = recommend_search_mode_rows(inventory)
    search_escalation_rows = recommend_search_escalation_rows(audit, inventory)
    window_mode_rows = recommend_window_mode_rows(audit, inventory)

    write_text(
        workspace_root / "03_output" / "REENTRY_DECISION.md",
        build_reentry_decision(audit, source_project_root, source_markers),
        overwrite=args.overwrite_generated,
    )
    write_text(
        workspace_root / "03_output" / "NEXT_USER_DECISION.md",
        build_next_user_decision(audit, implementation_requires_full),
        overwrite=args.overwrite_generated,
    )
    write_text(
        workspace_root / "03_output" / "PHASE_STATE.md",
        build_phase_state(audit, implementation_requires_full),
        overwrite=args.overwrite_generated,
    )
    write_text(
        workspace_root / "03_output" / "FOCUSED_STRENGTHENING_SELECTION.md",
        build_focused_strengthening_selection(strengthening_rows),
        overwrite=args.overwrite_generated,
    )
    write_csv_rows(
        workspace_root / "03_output" / "focused_strengthening_plan.csv",
        STRENGTHENING_COLUMNS,
        strengthening_rows,
        overwrite=args.overwrite_generated,
    )
    write_text(
        workspace_root / "03_output" / "SEARCH_MODE_SELECTION.md",
        build_search_mode_selection(search_mode_rows),
        overwrite=args.overwrite_generated,
    )
    write_csv_rows(
        workspace_root / "03_output" / "search_mode_plan.csv",
        SEARCH_MODE_COLUMNS,
        search_mode_rows,
        overwrite=args.overwrite_generated,
    )
    write_text(
        workspace_root / "03_output" / "SEARCH_ESCALATION_SELECTION.md",
        build_search_escalation_selection(search_escalation_rows),
        overwrite=args.overwrite_generated,
    )
    write_csv_rows(
        workspace_root / "03_output" / "search_escalation_plan.csv",
        SEARCH_ESCALATION_COLUMNS,
        search_escalation_rows,
        overwrite=args.overwrite_generated,
    )
    write_text(
        workspace_root / "03_output" / "STAGE_WINDOW_GUIDANCE.md",
        build_stage_window_guidance(window_mode_rows),
        overwrite=args.overwrite_generated,
    )
    write_text(
        workspace_root / "03_output" / "WINDOW_MODE_SELECTION.md",
        build_window_mode_selection(window_mode_rows),
        overwrite=args.overwrite_generated,
    )
    write_csv_rows(
        workspace_root / "03_output" / "window_mode_plan.csv",
        WINDOW_MODE_COLUMNS,
        window_mode_rows,
        overwrite=args.overwrite_generated,
    )

    result = {
        "workspace_root": str(workspace_root),
        "source_project_root": str(source_project_root) if source_project_root else None,
        "audit_status": audit["status"],
        "reentry_recommended_default": reentry_default(source_markers),
        "next_user_default": next_user_default(audit["status"], implementation_requires_full),
        "implementation_snapshot_count": len(implementation_snapshot),
        "implementation_requires_full": implementation_requires_full,
        "strengthening_target_count": len(strengthening_rows),
        "search_mode_count": len(search_mode_rows),
        "search_escalation_count": len(search_escalation_rows),
        "window_mode_count": len(window_mode_rows),
        "status": "ready",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))

def detect_partial_markers(project_root: Path | None) -> dict | None:
    if not project_root:
        return None
    full_markers = ["00_protocol", "01_window_runs", "05_master_tables", "06_reports"]
    lite_markers = ["00_raw", "01_index", "02_retained", "03_output"]
    full_present = [item for item in full_markers if (project_root / item).exists()]
    lite_present = [item for item in lite_markers if (project_root / item).exists()]
    return {
        "partial_full_workspace_detected": len(full_present) >= 2 and len(full_present) < len(full_markers),
        "partial_lite_workspace_detected": len(lite_present) >= 2 and len(lite_present) < len(lite_markers),
        "partial_full_markers_present": full_present,
        "partial_lite_markers_present": lite_present,
    }


def collect_top_level_inventory(project_root: Path | None) -> dict:
    if not project_root or not project_root.exists():
        return {"dirs": [], "files": [], "all_names": []}
    dirs = sorted(path.name for path in project_root.iterdir() if path.is_dir())
    files = sorted(path.name for path in project_root.iterdir() if path.is_file())
    return {"dirs": dirs, "files": files, "all_names": [*dirs, *files]}


def names_match(names: list[str], keywords: list[str]) -> list[str]:
    matches: list[str] = []
    for name in names:
        lowered = name.lower()
        if any(keyword in lowered for keyword in keywords):
            matches.append(name)
    return matches


def reentry_default(source_markers: dict | None) -> str:
    if not source_markers:
        return "continue_current_workspace"
    if source_markers.get("partial_full_workspace_detected") or source_markers.get("partial_lite_workspace_detected"):
        return "rebuild_generated_scaffold_keep_raw_corpus"
    return "continue_current_workspace"


def next_user_default(audit_status: str, implementation_requires_full: bool = False) -> str:
    if implementation_requires_full:
        return "move_into_full_pipeline"
    if audit_status in {"structural_only", "evidence_building"}:
        return "strengthen"
    return "consolidate"


def build_reentry_decision(audit: dict, source_project_root: Path | None, source_markers: dict | None) -> str:
    current_state_lines = [
        f"- workspace_status: `{audit['status']}`",
        f"- quality_score_100: `{audit['quality_score_100']}`",
        f"- critical_blocker_count: `{audit['critical_blocker_count']}`",
    ]
    if source_project_root:
        current_state_lines.append(f"- source_project_root: `{source_project_root}`")
    if source_markers and source_markers.get("partial_full_workspace_detected"):
        current_state_lines.append(f"- partial_full_markers_present: `{', '.join(source_markers['partial_full_markers_present'])}`")
    if source_markers and source_markers.get("partial_lite_workspace_detected"):
        current_state_lines.append(f"- partial_lite_markers_present: `{', '.join(source_markers['partial_lite_markers_present'])}`")

    notes = []
    if source_markers and (source_markers.get("partial_full_workspace_detected") or source_markers.get("partial_lite_workspace_detected")):
        notes.append("A partial workspace was detected in the source project. Rebuild is the recommended default when you want the generated lite scaffold refreshed without deleting the raw corpus.")
    else:
        notes.append("No partial source workspace markers were detected. Continue is the recommended default unless the generated lite scaffold itself is stale or inconsistent.")

    return "\n".join([
        "# Reentry Decision",
        "",
        "## Purpose",
        "",
        "Make the user choose how to handle an existing scaffolded or partially completed lite workspace.",
        "",
        "## Current Workspace State",
        "",
        *current_state_lines,
        "",
        "## Recommended Default",
        "",
        reentry_default(source_markers),
        "",
        "## Options",
        "",
        "1. continue_current_workspace",
        "2. repair_current_workspace",
        "3. rebuild_generated_scaffold_keep_raw_corpus",
        "4. stop",
        "",
        "## User Decision",
        "",
        "",
        "## Notes",
        "",
        *[f"- {note}" for note in notes],
        "",
    ])


def build_next_user_decision(audit: dict, implementation_requires_full: bool = False) -> str:
    blockers = audit.get("blockers", [])[:5]
    strengths = audit.get("strengths", [])[:5]
    ready_lines = [f"- {item}" for item in strengths] if strengths else ["- lite workspace scaffold is initialized"]
    not_ready_lines = [f"- {item}" for item in blockers] if blockers else ["- no major blockers recorded"]
    return "\n".join([
        "# Next User Decision",
        "",
        "## Current Lite Result",
        "",
        *ready_lines,
        "",
        "## Recommended Default",
        "",
        next_user_default(audit["status"], implementation_requires_full),
        "",
        "## Recommended Options",
        "",
        "1. consolidate",
        "2. optimize_more",
        "3. strengthen",
        "4. search_more",
        "5. choose_stable_mode",
        "6. choose_aggressive_mode",
        "7. move_into_full_pipeline",
        "8. stop",
        "",
        "## User Decision",
        "",
        "",
        "## Notes",
        "",
        *not_ready_lines,
        "- if you choose optimize_more, run one more bounded lite-quality improvement wave before freezing the current packet",
        "- if you choose strengthen, specify which directions, datasets, papers, claim bundles, or source families should be reinforced first",
        "- if you choose search_more, specify whether the next wave should go broader, deeper, or both",
        "- if the next stage should use multiple windows, ask the user to help open them because many agents cannot open extra windows by themselves",
        "- if the implementation snapshot records critical gaps or escalate_to_full=yes, move into the full pipeline before claiming execution readiness",
        "",
    ])


def build_phase_state(audit: dict, implementation_requires_full: bool = False) -> str:
    return "\n".join([
        "# Phase State",
        "",
        "current_phase: lite_summary_ready",
        f"state_status: {'pending_user_decision' if audit['status'] == 'structural_only' else 'ready_to_strengthen'}",
        f"recommended_default: {next_user_default(audit['status'], implementation_requires_full)}",
        "allowed_next_actions: consolidate, optimize_more, strengthen, search_more, choose_stable_mode, choose_aggressive_mode, move_into_full_pipeline, stop",
        "",
    ])


def recommend_strengthening_rows(inventory: dict) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []

    decision_matches = names_match(inventory["all_names"], ["decision", "strategy", "summary", "route", "benchmark", "playbook"])
    if decision_matches:
        rows.append({
            "focus_type": "claim_bundle",
            "focus_name": "strategy-and-decision-summaries",
            "strengthen_goal": "verify high-level strategy and decision summaries before acting on the lite shortlist",
            "evidence_gap": "high-level summaries may not align with the latest retained evidence",
            "preferred_action": "audit_claim_bundle",
            "priority": "high",
            "notes": f"Matched top-level items: {', '.join(decision_matches[:5])}",
        })

    dataset_matches = names_match(inventory["all_names"], ["dataset", "data", "csv", "parquet", "panel", "scholar"])
    if dataset_matches:
        rows.append({
            "focus_type": "dataset",
            "focus_name": "dataset-and-source-governance",
            "strengthen_goal": "clarify dataset provenance and which datasets actually affect the next decision",
            "evidence_gap": "dataset semantics may still be unclear at the lite stage",
            "preferred_action": "inventory_and_map",
            "priority": "high",
            "notes": f"Matched top-level items: {', '.join(dataset_matches[:5])}",
        })

    research_matches = names_match(inventory["all_names"], ["research", "study", "note", "literature", "audit", "program", "process"])
    if research_matches:
        rows.append({
            "focus_type": "direction",
            "focus_name": "historical-research-reconciliation",
            "strengthen_goal": "reconcile historical research notes into active versus stale conclusions before escalation",
            "evidence_gap": "mixed-vintage notes may still blur what is currently actionable",
            "preferred_action": "classify_and_reconcile",
            "priority": "medium",
            "notes": f"Matched top-level items: {', '.join(research_matches[:5])}",
        })

    rules_matches = names_match(inventory["all_names"], ["guide", "handbook", "manual", "submission", "checklist", "faq", "rule"])
    if rules_matches:
        rows.append({
            "focus_type": "paper",
            "focus_name": "rules-and-deliverable-constraints",
            "strengthen_goal": "reconfirm official constraints before acting on the lite shortlist",
            "evidence_gap": "operator assumptions may drift from guide and submission documents",
            "preferred_action": "reconfirm_authoritative_rules",
            "priority": "medium",
            "notes": f"Matched top-level items: {', '.join(rules_matches[:5])}",
        })

    policy_matches = names_match(inventory["all_names"], ["policy", "regulation", "standard", "compliance", "governance", "requirement", "framework", "guideline"])
    if policy_matches:
        rows.append({
            "focus_type": "source_family",
            "focus_name": "policy-and-compliance-interpretation",
            "strengthen_goal": "extract operative constraints from policy, standards, regulatory, or compliance materials before acting on the lite shortlist",
            "evidence_gap": "normative materials may exist but their usable constraints are not yet normalized into the lite decision packet",
            "preferred_action": "extract_constraints_and_map",
            "priority": "high",
            "notes": f"Matched top-level items: {', '.join(policy_matches[:5])}",
        })

    qualitative_matches = names_match(inventory["all_names"], ["interview", "transcript", "survey", "questionnaire", "stakeholder", "persona", "user-research", "user_research", "ux", "ethnography", "fieldnote", "field-note", "observation"])
    if qualitative_matches:
        rows.append({
            "focus_type": "source_family",
            "focus_name": "qualitative-evidence-and-user-insight",
            "strengthen_goal": "normalize interviews, surveys, stakeholder input, and qualitative findings into explicit retained claims before escalation",
            "evidence_gap": "qualitative materials may still be present only as raw notes rather than structured claim bundles",
            "preferred_action": "extract_claim_bundles",
            "priority": "high",
            "notes": f"Matched top-level items: {', '.join(qualitative_matches[:5])}",
        })

    archival_matches = names_match(inventory["all_names"], ["archive", "archival", "historical", "record", "registry", "minutes", "memoir", "correspondence", "catalog", "catalogue", "logbook"])
    if archival_matches:
        rows.append({
            "focus_type": "source_family",
            "focus_name": "archival-and-record-based-evidence",
            "strengthen_goal": "clarify provenance, time semantics, and evidentiary limits for archival or record-based materials before escalation",
            "evidence_gap": "record-based sources may still be present without normalized provenance or temporal interpretation",
            "preferred_action": "provenance_and_timeline_audit",
            "priority": "medium",
            "notes": f"Matched top-level items: {', '.join(archival_matches[:5])}",
        })

    return rows


def build_focused_strengthening_selection(rows: list[dict[str, str]]) -> str:
    candidate_lines = [f"- `{row['focus_type']}`: `{row['focus_name']}`" for row in rows] or ["- no recommended strengthening targets were inferred automatically"]
    recommended_lines = [f"- `{row['focus_name']}`: {row['strengthen_goal']}" for row in rows] or ["- no recommended strengthening targets were inferred automatically"]
    return "\n".join([
        "# Focused Strengthening Selection",
        "",
        "## Purpose",
        "",
        "Choose exactly which directions, datasets, papers, claim bundles, or source families should be strengthened before the lite workflow broadens or escalates.",
        "",
        "## Candidate Strengthening Targets",
        "",
        *candidate_lines,
        "",
        "## Recommended Targets",
        "",
        *recommended_lines,
        "",
        "## User Choice",
        "",
        "",
        "## Notes",
        "",
    ])


def recommend_search_mode_rows(inventory: dict) -> list[dict[str, str]]:
    project_corpus_available = "yes" if inventory["all_names"] else "no"
    default_mode = "project_corpus_only" if project_corpus_available == "yes" else "knowledge_only"
    return [
        {
            "phase_scope": "lite_research_wave",
            "recommended_search_mode": default_mode,
            "approved_search_mode": "pending_user_choice",
            "local_project_corpus": project_corpus_available,
            "model_prior_knowledge": "yes",
            "external_literature_search": "optional",
            "user_choice_state": "pending",
            "notes": "Choose whether the next lite research wave should use only existing knowledge, only the existing project corpus, or allow external literature search.",
        }
    ]


def build_search_mode_selection(rows: list[dict[str, str]]) -> str:
    mode_lines = [f"- `{row['phase_scope']}`: recommend `{row['recommended_search_mode']}`" for row in rows] or ["- no search-mode recommendation inferred automatically"]
    return "\n".join([
        "# Search Mode Selection",
        "",
        "## Purpose",
        "",
        "Choose whether the next lite research stage should rely only on model prior knowledge, only on the existing project corpus, or on external literature search.",
        "",
        "## Recommended Modes",
        "",
        *mode_lines,
        "",
        "## Available Search Modes",
        "",
        "1. knowledge_only",
        "2. project_corpus_only",
        "3. external_search_enabled",
        "",
        "## User Choice",
        "",
        "",
        "## Notes",
        "",
    ])


def recommend_search_escalation_rows(audit: dict, inventory: dict) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    if audit["status"] == "structural_only":
        rows.append({
            "escalation_level": "level_1_broaden_queries",
            "scope_change": "expand question wording, synonym families, and adjacent terminology",
            "round_change": "add one more bounded lite search wave",
            "source_family_change": "stay in current source families first",
            "trigger_reason": "current workspace is still at structural_only depth",
            "user_state": "pending_user_choice",
            "notes": "Recommended first escalation when the user says the initial lite search was too thin.",
        })
    if inventory["all_names"]:
        rows.append({
            "escalation_level": "level_2_broaden_sources",
            "scope_change": "keep the same objective but widen source families and adjacent repositories",
            "round_change": "add another bounded wave after query broadening",
            "source_family_change": "include additional databases, repositories, or author families",
            "trigger_reason": "current source family may still be too narrow",
            "user_state": "pending_user_choice",
            "notes": f"Inventory observed: {', '.join(inventory['all_names'][:5])}",
        })
    return rows


def build_search_escalation_selection(rows: list[dict[str, str]]) -> str:
    escalation_lines = [f"- `{row['escalation_level']}`: {row['scope_change']}" for row in rows] or ["- no escalation recommendations inferred automatically"]
    return "\n".join([
        "# Search Escalation Selection",
        "",
        "## Purpose",
        "",
        "Decide whether the current search depth is sufficient or whether another search wave should run at a higher breadth, depth, or both.",
        "",
        "## Current Search Sufficiency Judgment",
        "",
        "",
        "## Escalation Levels",
        "",
        *escalation_lines,
        "",
        "## User Choice",
        "",
        "",
        "## Notes",
        "",
    ])


def recommend_window_mode_rows(audit: dict, inventory: dict) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = [
        {
            "stage": "initial_lite_pass",
            "recommended_mode": "single_window",
            "recommended_window_count": "1",
            "single_window_path": "One agent inventories, shortlists, and summarizes the first pass.",
            "multi_window_path": "If the corpus is already messy or broad, ask the user to help open 2-3 windows for intake, extraction, and comparison.",
            "user_assistance_required": "yes_if_multi_window",
            "notes": "Default starting posture unless the user already knows the corpus is large or fragmented.",
        },
        {
            "stage": "strengthen_wave",
            "recommended_mode": "single_window" if audit["status"] == "structural_only" else "multi_window_optional",
            "recommended_window_count": "1" if audit["status"] == "structural_only" else "2-4",
            "single_window_path": "One agent reinforces a small set of targets when scope is still modest.",
            "multi_window_path": "If there are multiple strengthening targets, ask the user to help open 2-4 windows so each target can be reinforced separately.",
            "user_assistance_required": "yes_if_multi_window",
            "notes": "Promote to multi-window only when there are genuinely separate targets to reinforce.",
        },
        {
            "stage": "search_more_wave",
            "recommended_mode": "single_window" if len(inventory["all_names"]) < 8 else "multi_window_optional",
            "recommended_window_count": "1" if len(inventory["all_names"]) < 8 else "2-4",
            "single_window_path": "One agent can run the next broadened or deepened search wave when the expansion is still modest.",
            "multi_window_path": "If breadth and depth both need to increase, ask the user to help open 2-4 windows split by source family or question family.",
            "user_assistance_required": "yes_if_multi_window",
            "notes": "Use multi-window when a single agent would become the bottleneck for the next search wave.",
        },
        {
            "stage": "full_pipeline_handoff",
            "recommended_mode": "multi_window_recommended",
            "recommended_window_count": "3+",
            "single_window_path": "One agent may still prepare the handoff if the user wants a conservative transition.",
            "multi_window_path": "If the user escalates to the full pipeline, ask whether they want help opening the recommended windows before launch planning begins.",
            "user_assistance_required": "yes",
            "notes": "The full pipeline usually benefits from multiple windows once the user is ready for a heavier program.",
        },
    ]
    return rows


def build_stage_window_guidance(rows: list[dict[str, str]]) -> str:
    sections: list[str] = ["# Stage Window Guidance", "", "Use this file to decide whether the next stage should stay in one window or use multiple windows.", ""]
    for row in rows:
        title = row["stage"].replace("_", " ").title()
        sections.extend([
            f"## {title}",
            "",
            f"- recommended_mode: `{row['recommended_mode']}`",
            f"- recommended_window_count: `{row['recommended_window_count']}`",
            f"- user_assistance_required: `{row['user_assistance_required']}`",
            "",
            "Single-window path:",
            row["single_window_path"],
            "",
            "Multi-window path:",
            row["multi_window_path"],
            "",
            "Notes:",
            row["notes"],
            "",
        ])
    return "\n".join(sections)


def build_window_mode_selection(rows: list[dict[str, str]]) -> str:
    stage_lines = [f"- `{row['stage']}`: recommend `{row['recommended_mode']}` with `{row['recommended_window_count']}` window(s)" for row in rows]
    return "\n".join([
        "# Window Mode Selection",
        "",
        "## Purpose",
        "",
        "Choose whether the next stage should stay in one window or use multiple windows.",
        "",
        "## Current Stage",
        "",
        "",
        "## Recommended Default",
        "",
        *stage_lines,
        "",
        "## Available Modes",
        "",
        "1. single_window",
        "2. multi_window",
        "",
        "## Suggested Window Count",
        "",
        "",
        "## User Choice",
        "",
        "",
        "## User Assistance Request",
        "",
        "If multi-window is chosen, ask the user to help open the requested number of windows because many agents cannot open extra windows by themselves.",
        "",
        "## Notes",
        "",
    ])


def write_text(path: Path, text: str, overwrite: bool) -> None:
    if path.exists() and not overwrite:
        return
    path.write_text(text, encoding="utf-8")


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv_rows(path: Path, columns: list[str], rows: list[dict[str, str]], overwrite: bool) -> None:
    if path.exists() and not overwrite:
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in columns})


if __name__ == "__main__":
    main()
