#!/usr/bin/env python3
"""Validate a lightweight research workspace scaffold."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path


EXPECTED_HEADERS = {
    "source_index.csv": ["source_id", "title", "author_or_org", "year", "source_type", "evidence_class", "stable_link", "topic", "status"],
    "retained_evidence.csv": ["source_id", "evidence_class", "claim", "study_context", "method_summary", "evidence_strength", "transferability", "risk_or_limitation"],
    "action_map.csv": ["source_id", "action_type", "proposed_action", "confidence", "validation_needed", "priority"],
    "focused_strengthening_plan.csv": ["focus_type", "focus_name", "strengthen_goal", "evidence_gap", "preferred_action", "priority", "notes"],
    "search_mode_plan.csv": ["phase_scope", "recommended_search_mode", "approved_search_mode", "local_project_corpus", "model_prior_knowledge", "external_literature_search", "user_choice_state", "notes"],
    "search_escalation_plan.csv": ["escalation_level", "scope_change", "round_change", "source_family_change", "trigger_reason", "user_state", "notes"],
    "window_mode_plan.csv": ["stage", "recommended_mode", "recommended_window_count", "single_window_path", "multi_window_path", "user_assistance_required", "notes"],
    "implementation_snapshot.csv": ["route_id", "code_present", "entrypoint_present", "test_surface_present", "executable_evidence_status", "implementation_level", "critical_gaps", "escalate_to_full"],
}


def main() -> None:
    if len(sys.argv) != 2:
        print("Usage: python validate_research_workspace.py <workspace_root>")
        sys.exit(1)

    root = Path(sys.argv[1]).resolve()
    checks = {
        "raw_dir_exists": (root / "00_raw").exists(),
        "index_dir_exists": (root / "01_index").exists(),
        "retained_dir_exists": (root / "02_retained").exists(),
        "output_dir_exists": (root / "03_output").exists(),
        "source_index_ok": csv_header_matches(root / "01_index" / "source_index.csv", EXPECTED_HEADERS["source_index.csv"]),
        "retained_evidence_ok": csv_header_matches(root / "02_retained" / "retained_evidence.csv", EXPECTED_HEADERS["retained_evidence.csv"]),
        "action_map_ok": csv_header_matches(root / "03_output" / "action_map.csv", EXPECTED_HEADERS["action_map.csv"]),
        "focused_strengthening_plan_ok": csv_header_matches(root / "03_output" / "focused_strengthening_plan.csv", EXPECTED_HEADERS["focused_strengthening_plan.csv"]),
        "search_mode_plan_ok": csv_header_matches(root / "03_output" / "search_mode_plan.csv", EXPECTED_HEADERS["search_mode_plan.csv"]),
        "search_escalation_plan_ok": csv_header_matches(root / "03_output" / "search_escalation_plan.csv", EXPECTED_HEADERS["search_escalation_plan.csv"]),
        "window_mode_plan_ok": csv_header_matches(root / "03_output" / "window_mode_plan.csv", EXPECTED_HEADERS["window_mode_plan.csv"]),
        "implementation_snapshot_ok": csv_header_matches(root / "03_output" / "implementation_snapshot.csv", EXPECTED_HEADERS["implementation_snapshot.csv"]),
        "implementation_snapshot_values_ok": implementation_snapshot_values_ok(root / "03_output" / "implementation_snapshot.csv"),
        "summary_memo_exists": (root / "03_output" / "summary_memo.md").exists(),
        "summary_memo_implementation_sections_ok": markdown_has_sections(root / "03_output" / "summary_memo.md", ["## Implementation Maturity", "## Critical Code Gaps", "## Full Pipeline Escalation"]),
        "next_user_decision_exists": (root / "03_output" / "NEXT_USER_DECISION.md").exists(),
        "next_user_decision_sections_ok": markdown_has_sections(root / "03_output" / "NEXT_USER_DECISION.md", ["## Current Lite Result", "## Recommended Default", "## Recommended Options", "## User Decision"]),
        "reentry_decision_exists": (root / "03_output" / "REENTRY_DECISION.md").exists(),
        "reentry_decision_sections_ok": markdown_has_sections(root / "03_output" / "REENTRY_DECISION.md", ["## Purpose", "## Current Workspace State", "## Recommended Default", "## Options", "## User Decision", "## Notes", "continue_current_workspace", "repair_current_workspace", "rebuild_generated_scaffold_keep_raw_corpus"]),
        "phase_state_exists": (root / "03_output" / "PHASE_STATE.md").exists(),
        "phase_state_fields_ok": lite_phase_state_fields_ok(root / "03_output" / "PHASE_STATE.md"),
        "control_center_exists": (root / "03_output" / "LITE_CONTROL_CENTER.md").exists(),
        "control_center_sections_ok": markdown_has_sections(root / "03_output" / "LITE_CONTROL_CENTER.md", ["## Current Operating Posture", "## Primary Operator Files", "## Control Rules", "## Immediate Use"]),
        "user_checkpoint_prompts_exists": (root / "03_output" / "USER_CHECKPOINT_PROMPTS.md").exists(),
        "user_checkpoint_prompts_sections_ok": markdown_has_sections(root / "03_output" / "USER_CHECKPOINT_PROMPTS.md", ["## Lite Prompt", "Purpose:", "Recommended default:", "Option impact:", "```text"]),
        "user_reentry_prompts_exists": (root / "03_output" / "USER_REENTRY_PROMPTS.md").exists(),
        "user_reentry_prompts_sections_ok": markdown_has_sections(root / "03_output" / "USER_REENTRY_PROMPTS.md", ["## Purpose", "## User Prompt", "continue_current_workspace", "repair_current_workspace", "rebuild_generated_scaffold_keep_raw_corpus", "```text"]),
        "focused_strengthening_selection_exists": (root / "03_output" / "FOCUSED_STRENGTHENING_SELECTION.md").exists(),
        "focused_strengthening_selection_sections_ok": markdown_has_sections(root / "03_output" / "FOCUSED_STRENGTHENING_SELECTION.md", ["## Purpose", "## Candidate Strengthening Targets", "## Recommended Targets", "## User Choice", "## Notes"]),
        "user_focused_strengthening_prompts_exists": (root / "03_output" / "USER_FOCUSED_STRENGTHENING_PROMPTS.md").exists(),
        "user_focused_strengthening_prompts_sections_ok": markdown_has_sections(root / "03_output" / "USER_FOCUSED_STRENGTHENING_PROMPTS.md", ["## Purpose", "## User Prompt", "focus_type", "focus_name", "focused_strengthening_plan.csv", "```text"]),
        "search_mode_selection_exists": (root / "03_output" / "SEARCH_MODE_SELECTION.md").exists(),
        "search_mode_selection_sections_ok": markdown_has_sections(root / "03_output" / "SEARCH_MODE_SELECTION.md", ["## Purpose", "## Available Search Modes", "## User Choice", "knowledge_only", "project_corpus_only", "external_search_enabled"]),
        "user_search_mode_prompts_exists": (root / "03_output" / "USER_SEARCH_MODE_PROMPTS.md").exists(),
        "user_search_mode_prompts_sections_ok": markdown_has_sections(root / "03_output" / "USER_SEARCH_MODE_PROMPTS.md", ["## Purpose", "## User Prompt", "knowledge_only", "project_corpus_only", "external_search_enabled", "search_mode_plan.csv", "```text"]),
        "search_escalation_selection_exists": (root / "03_output" / "SEARCH_ESCALATION_SELECTION.md").exists(),
        "search_escalation_selection_sections_ok": markdown_has_sections(root / "03_output" / "SEARCH_ESCALATION_SELECTION.md", ["## Purpose", "## Current Search Sufficiency Judgment", "## Escalation Levels", "## User Choice", "## Notes"]),
        "user_search_escalation_prompts_exists": (root / "03_output" / "USER_SEARCH_ESCALATION_PROMPTS.md").exists(),
        "user_search_escalation_prompts_sections_ok": markdown_has_sections(root / "03_output" / "USER_SEARCH_ESCALATION_PROMPTS.md", ["## Purpose", "## User Prompt", "level_1_broaden_queries", "search_escalation_plan.csv", "```text"]),
        "stage_window_guidance_exists": (root / "03_output" / "STAGE_WINDOW_GUIDANCE.md").exists(),
        "stage_window_guidance_sections_ok": markdown_has_sections(root / "03_output" / "STAGE_WINDOW_GUIDANCE.md", ["## Initial Lite Pass", "## Strengthen Wave", "## Search-More Wave", "## Full-Pipeline Handoff"]),
        "window_mode_selection_exists": (root / "03_output" / "WINDOW_MODE_SELECTION.md").exists(),
        "window_mode_selection_sections_ok": markdown_has_sections(root / "03_output" / "WINDOW_MODE_SELECTION.md", ["## Purpose", "## Current Stage", "## Recommended Default", "## Available Modes", "## Suggested Window Count", "## User Choice", "## Notes"]),
        "user_window_mode_prompts_exists": (root / "03_output" / "USER_WINDOW_MODE_PROMPTS.md").exists(),
        "user_window_mode_prompts_sections_ok": markdown_has_sections(root / "03_output" / "USER_WINDOW_MODE_PROMPTS.md", ["## Purpose", "## User Prompt", "single_window", "multi_window", "window_mode_plan.csv", "```text"]),
        "broadcast_prompt_exists": (root / "03_output" / "UNIFIED_BROADCAST_PROMPT.md").exists(),
        "broadcast_prompt_sections_ok": markdown_has_sections(root / "03_output" / "UNIFIED_BROADCAST_PROMPT.md", ["Current phase:", "Current mode:", "Authoritative files:", "Required action:", "Do not silently broaden scope:"]),
        "autonomous_serial_plan_exists": (root / "03_output" / "AUTONOMOUS_SERIAL_PLAN.md").exists(),
        "autonomous_serial_plan_sections_ok": markdown_has_sections(root / "03_output" / "AUTONOMOUS_SERIAL_PLAN.md", ["## Purpose", "## Activation Rule", "## Phase Order", "## Per-phase rule", "## Stop Conditions", "## Completion Rule"]),
        "operator_handoff_contract_exists": (root / "03_output" / "OPERATOR_HANDOFF_CONTRACT.md").exists(),
        "operator_handoff_contract_sections_ok": markdown_has_sections(root / "03_output" / "OPERATOR_HANDOFF_CONTRACT.md", ["## Purpose", "## Required Fields", "objective", "environment_limit", "required_operator_action", "input_paths", "output_paths", "verification_rule", "resume_prompt", "## Template", "```text"]),
        "stable_options_exists": (root / "03_output" / "STABLE_OPTIONS.md").exists(),
        "aggressive_options_exists": (root / "03_output" / "AGGRESSIVE_OPTIONS.md").exists(),
    }

    maturity_check_names = {"implementation_snapshot_ok", "implementation_snapshot_values_ok", "summary_memo_implementation_sections_ok"}
    base_ready = all(value for name, value in checks.items() if name not in maturity_check_names)
    maturity_ready = all(checks[name] for name in maturity_check_names)
    status = "ready" if base_ready and maturity_ready else "contract_upgrade_required" if base_ready else "needs_attention"
    result = {
        "workspace_root": str(root),
        "checks": checks,
        "upgrade_command": f"python -B init_research_workspace.py --root \"{root}\"" if status == "contract_upgrade_required" else None,
        "status": status,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result["status"] == "ready" else 1)


def csv_header_matches(path: Path, expected: list[str]) -> bool:
    if not path.exists():
        return False
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        try:
            header = next(reader)
        except StopIteration:
            return False
    return header == expected


def markdown_has_sections(path: Path, sections: list[str]) -> bool:
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8")
    return all(section in text for section in sections)


def implementation_snapshot_values_ok(path: Path) -> bool:
    if not path.exists():
        return False
    with path.open("r", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    allowed_levels = {"M0", "M1", "M2"}
    allowed_statuses = {"pass", "fail", "missing", "not_run"}
    allowed_bools = {"yes", "no", "true", "false", "1", "0"}
    return all(
        row.get("implementation_level", "") in allowed_levels
        and row.get("executable_evidence_status", "") in allowed_statuses
        and row.get("code_present", "").lower() in allowed_bools
        and row.get("entrypoint_present", "").lower() in allowed_bools
        and row.get("test_surface_present", "").lower() in allowed_bools
        and row.get("escalate_to_full", "").lower() in allowed_bools
        for row in rows
    )


def lite_phase_state_fields_ok(path: Path) -> bool:
    if not path.exists():
        return False
    fields = parse_kv_file(path)
    allowed_actions = {"consolidate", "optimize_more", "strengthen", "search_more", "choose_stable_mode", "choose_aggressive_mode", "move_into_full_pipeline", "stop"}
    current_phase_ok = fields.get("current_phase") == "lite_summary_ready"
    state_status_ok = fields.get("state_status") == "pending_user_decision"
    recommended_default_ok = fields.get("recommended_default") in allowed_actions
    actions = {item.strip() for item in fields.get("allowed_next_actions", "").split(",") if item.strip()}
    allowed_actions_ok = bool(actions) and actions.issubset(allowed_actions)
    return current_phase_ok and state_status_ok and recommended_default_ok and allowed_actions_ok


def parse_kv_file(path: Path) -> dict[str, str]:
    fields: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        fields[key.strip()] = value.strip()
    return fields


if __name__ == "__main__":
    main()
