# Evidence Source Taxonomy

## Objective

Give lite-mode research a practical evidence vocabulary so mixed material can still be triaged consistently before the project escalates.

## Core evidence classes

1. `quantitative_experimental`
2. `quantitative_observational`
3. `qualitative_interview_or_transcript`
4. `survey_or_questionnaire`
5. `policy_or_compliance_document`
6. `archival_or_record_source`
7. `implementation_or_analysis_code`
8. `config_schema_or_structured_text`
9. `markdown_research_note`
10. `general_text_like_research_material`

## Lite handling rule

In lite mode, the goal is not to fully adjudicate every evidence class.

The goal is to triage quickly enough to answer:

1. which items are likely decision-relevant
2. which items require stronger validation before use
3. which items should trigger escalation into the full program

## Quick-use hints

1. interview or transcript material:
   - keep speaker scope and claim boundaries explicit
2. survey material:
   - keep instrument and respondent scope explicit
3. policy or compliance material:
   - extract the operative rule, not just the document title
4. archival or record material:
   - keep provenance and date meaning explicit
5. code or notebook material:
   - separate implementation fact from interpretive commentary
6. markdown notes:
   - treat as synthesis until cross-checked

## Escalation rule

Escalate into the full program when:

1. multiple evidence classes conflict materially
2. qualitative and quantitative findings diverge
3. policy constraints alter the action map significantly
4. archival or historical records require careful provenance adjudication
