# Lite Implementation Maturity

## Purpose

Add a lightweight code-readiness check without turning the lite workflow into an engineering program.

## Snapshot rule

For each actionable route, record in `implementation_snapshot.csv` whether code, an entrypoint, tests, and executable evidence exist. Use only `M0` through `M2` in lite mode:

1. `M0`: concept or validation placeholder only
2. `M1`: code mapping or scaffold exists
3. `M2`: a declared entrypoint runs with recorded evidence

Do not infer runnability from file presence. Use `not_run` when execution was unavailable.

## Escalation rule

Escalate to the full pipeline when the user needs execution, result promotion, benchmark freezing, release readiness, critical integrity checks, or a disputed maturity judgment.

Record code gaps as engineering actions in `action_map.csv`. Do not modify business code unless the user explicitly authorizes engineering work.
