# No Local File Access Mode

Use this mode when the target agent or AI cannot read local filesystem paths at all.

## Typical constraints

1. cannot open `SKILL.md` by local path
2. cannot inspect referenced local files directly
3. cannot run local scripts
4. may only work from pasted text, uploaded artifacts, or operator summaries

## Required behavior

1. do not pretend the agent can see local files when it cannot
2. have the operator choose the target skill first using `START_HERE_PROMPTS.md` or `research-skill-hub/SKILL.md` on a stronger machine
3. paste the selected `SKILL.md` body into the no-file-access environment
4. paste only the required referenced resources for the current subtask instead of dumping the whole repository blindly
5. when a local script is needed, convert that step into an operator handoff using `OPERATOR_HANDOFF_CONTRACT.md`

## Transfer sequence

1. identify the target skill on a machine that can read the local skill family
2. copy the chosen `SKILL.md` body
3. copy the minimum required reference files for the active subtask
4. tell the no-file-access agent what artifacts it cannot see and what the operator will execute externally
5. keep all write, script, and multi-window steps in explicit operator handoff form

## Rule

This mode is slower and less robust than direct local-file access.

Use it only when the target environment truly cannot read local paths.
