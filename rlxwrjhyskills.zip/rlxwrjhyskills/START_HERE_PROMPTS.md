# Research Skill Family Start Here

Use this file when you want a copy-paste-ready starting point without running any local helper script first.

## Canonical entry

Use the local skill family entry skill first whenever the target agent should inspect available entries, explain the differences, recommend one, and wait for the user's explicit choice before routing.

```text
Task: <TASK_STATEMENT>
Skill file: <FAMILY_ROOT>\research-skill-hub\SKILL.md
Instruction: Read that SKILL.md completely first, list the available local research skill entries, recommend the best fit, and wait for the user's explicit choice before routing.
```

## Direct full-program entry

Use this when you already know the task needs the full auditable program.

```text
Task: <TASK_STATEMENT>
Skill file: <FAMILY_ROOT>\research-pipeline-full\SKILL.md
Instruction: Read that SKILL.md completely first, then follow its referenced local resources and bundled scripts. Keep all major phase changes user-visible, and stop for explicit user choice at reentry, search-mode, strengthening, direction-depth, search-escalation, and window-mode gates.
```

## Direct autonomous full-program entry

Use this when you want the full program in autonomous mode and the target agent should keep pushing toward the strongest reachable in-scope result.

```text
Task: <TASK_STATEMENT>
Skill file: <FAMILY_ROOT>\research-pipeline-full\SKILL.md
Instruction: Read that SKILL.md completely first, then follow its referenced local resources and bundled scripts. Run in autonomous_mode, warn explicitly that token consumption may rise, keep major hard stops visible, and if multi-window help is unavailable, fall back to single-window phased execution instead of blocking.
```

## Direct lite entry

Use this when the task needs a fast triage-first pass.

```text
Task: <TASK_STATEMENT>
Skill file: <FAMILY_ROOT>\research-pipeline-lite\SKILL.md
Instruction: Read that SKILL.md completely first, then follow its referenced local resources and bundled scripts. Keep reentry, search-mode, strengthening, search-sufficiency, and lite-to-full escalation decisions explicit to the user.
```

## Replacement rule

Replace `<FAMILY_ROOT>` with the folder that contains this file, `README.md`, `research_skill_family.json`, and the three skill folders.

Typical values include the current installed family root, an exported backup bundle root, or any relocated copy that preserves the same top-level layout.

## Operator note

If the target environment cannot execute local scripts, these prompts still work as long as the agent can read local files by path and follow referenced local resources manually.
