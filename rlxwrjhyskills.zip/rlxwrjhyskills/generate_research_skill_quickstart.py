#!/usr/bin/env python3
"""Generate a cross-agent quickstart pack for the research skill family."""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True

from research_runtime import format_portable_python_command, python_command, run_command, run_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a quickstart prompt pack for the research skill family")
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--profile", default="generic")
    parser.add_argument("--output")
    parser.add_argument("--format", choices=["json", "markdown"], default="json")
    args = parser.parse_args()

    skills_root = Path(__file__).resolve().parent
    project_root = str(Path(args.project_root).resolve())

    result = build_quickstart_pack(skills_root, project_root, args.profile)

    if args.output:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        if args.format == "markdown":
            output.write_text(render_markdown(result), encoding="utf-8")
        else:
            output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(result, ensure_ascii=False, indent=2))


def build_quickstart_pack(skills_root: Path, project_root: str, profile: str) -> dict:
    hub_prompt_script = skills_root / "research-skill-hub" / "scripts" / "build_skill_selection_prompt.py"
    hub_recommend_script = skills_root / "research-skill-hub" / "scripts" / "recommend_local_skill.py"
    route_script = skills_root / "route_research_skill_entry.py"
    full_entry_script = skills_root / "research-pipeline-full" / "scripts" / "generate_entry_prompts.py"
    lite_entry_script = skills_root / "research-pipeline-lite" / "scripts" / "generate_entry_prompts.py"
    platform_recommend_script = skills_root / "recommend_research_platform_profile.py"

    route_payload = run_json(python_command(route_script, "--project-root", project_root, "--profile", profile))
    hub_recommendation = run_json(python_command(hub_recommend_script, "--skills-root", skills_root, "--project-root", project_root, "--profile", profile))
    platform_recommendation = run_json(python_command(platform_recommend_script, "--preferred-execution-posture", "tool_runner", "--preferred-prompt-style", "universal"))

    with tempfile.TemporaryDirectory(prefix="research_skill_quickstart_") as temp_dir:
        temp_root = Path(temp_dir)
        full_bundle_path = temp_root / "full_prompts.md"
        lite_bundle_path = temp_root / "lite_prompts.md"
        run_command(python_command(full_entry_script, "--output", full_bundle_path, "--project-root", project_root, "--profile", profile))
        run_command(python_command(lite_entry_script, "--output", lite_bundle_path, "--project-root", project_root))
        full_bundle = full_bundle_path.read_text(encoding="utf-8")
        lite_bundle = lite_bundle_path.read_text(encoding="utf-8")

    hub_universal = build_selection_prompt(hub_prompt_script, skills_root, "research-skill-hub", project_root, "universal")
    hub_codex = build_selection_prompt(hub_prompt_script, skills_root, "research-skill-hub", project_root, "codex")
    full_universal = build_selection_prompt(hub_prompt_script, skills_root, "research-pipeline-full", project_root, "universal")
    full_codex = build_selection_prompt(hub_prompt_script, skills_root, "research-pipeline-full", project_root, "codex")
    lite_universal = build_selection_prompt(hub_prompt_script, skills_root, "research-pipeline-lite", project_root, "universal")
    lite_codex = build_selection_prompt(hub_prompt_script, skills_root, "research-pipeline-lite", project_root, "codex")

    return {
        "schema_version": 1,
        "project_root": project_root,
        "profile": profile,
        "invocation_contract": "One task statement plus one reachable SKILL.md file address must be enough for a skill-capable agent to load and use the skill correctly.",
        "minimal_invocation_template": "Task: <TASK_STATEMENT>\nSkill file: <ABSOLUTE_PATH_TO_SKILL_MD>\nInstruction: Read that SKILL.md completely first, then follow its referenced local resources and bundled scripts before continuing the task.",
        "recommended_track": route_payload["recommended_track"],
        "recommended_skill": route_payload["recommended_skill"],
        "recommended_skill_file": str(skills_root / route_payload["recommended_skill"] / "SKILL.md"),
        "recommended_start": route_payload["recommended_start"],
        "recommended_window_count": route_payload["recommended_window_count"],
        "search_mode_decision_note": "Before a new search stage begins, choose whether the task should use knowledge_only, project_corpus_only, or external_search_enabled.",
        "low_tool_mode_file": str(skills_root / "LOW_TOOL_MODE.md"),
        "low_tool_mode_note": "If the target agent cannot write files, run scripts, or open windows, use LOW_TOOL_MODE.md together with START_HERE_PROMPTS.md and prefer the read-only-review-agent or chat-manual-operator platform profile.",
        "no_local_file_access_mode_file": str(skills_root / "NO_LOCAL_FILE_ACCESS_MODE.md"),
        "no_local_file_access_mode_note": "If the target agent cannot read local file paths at all, use NO_LOCAL_FILE_ACCESS_MODE.md. Generate a hub transfer packet first when the target environment still needs to choose between local research skills, and use full/lite transfer packets only when the target track is already known.",
        "operator_handoff_contract_file": str(skills_root / "OPERATOR_HANDOFF_CONTRACT.md"),
        "transfer_packet_recommendation": "For no-local-file-access environments, transfer the research-skill-hub packet first. Use the full or lite packet only after the target skill has already been chosen.",
        "transfer_packet_portable_commands": {
            "hub": format_portable_python_command(skills_root / "generate_research_skill_transfer_packet.py", "--skill-name", "research-skill-hub", "--skills-root", skills_root, "--project-root", project_root, "--style", "universal", "--output", Path(project_root) / "research_skill_transfer_packet_hub.md", "--format", "markdown"),
            "full": format_portable_python_command(skills_root / "generate_research_skill_transfer_packet.py", "--skill-name", "research-pipeline-full", "--skills-root", skills_root, "--project-root", project_root, "--style", "universal", "--output", Path(project_root) / "research_skill_transfer_packet_full.md", "--format", "markdown"),
            "lite": format_portable_python_command(skills_root / "generate_research_skill_transfer_packet.py", "--skill-name", "research-pipeline-lite", "--skills-root", skills_root, "--project-root", project_root, "--style", "universal", "--output", Path(project_root) / "research_skill_transfer_packet_lite.md", "--format", "markdown"),
        },
        "platform_profile_recommendation": platform_recommendation,
        "recommended_prompt": route_payload["copy_paste_prompt"],
        "recommended_prompt_codex": route_payload["copy_paste_prompt_codex"],
        "recommended_selection_prompt": route_payload["copy_paste_prompt"],
        "recommended_selection_prompt_codex": route_payload["copy_paste_prompt_codex"],
        "direct_recommended_prompt": route_payload["direct_recommended_prompt"],
        "direct_recommended_prompt_codex": route_payload["direct_recommended_prompt_codex"],
        "autonomous_single_window_note": "In autonomous full mode, if the user cannot help open multiple windows, fall back to one-window phased execution instead of blocking the program.",
        "autonomous_full_prompt": f"Task: <TASK_STATEMENT>\nSkill file: {skills_root / 'research-pipeline-full' / 'SKILL.md'}\nInstruction: Read that SKILL.md completely first, then follow its referenced local resources and bundled scripts. Run in autonomous_mode, warn explicitly that token consumption may rise, keep major hard stops visible, keep research credibility separate from implementation maturity, apply target-stage hard gates, and if multi-window help is unavailable, fall back to single-window phased execution instead of blocking.",
        "hub_recommendation": hub_recommendation,
        "hub_prompts": {
            "universal": hub_universal,
            "codex": hub_codex,
        },
        "full_prompts": {
            "universal": full_universal,
            "codex": full_codex,
            "bundle": full_bundle,
        },
        "lite_prompts": {
            "universal": lite_universal,
            "codex": lite_codex,
            "bundle": lite_bundle,
        },
    }


def build_selection_prompt(script: Path, skills_root: Path, skill_name: str, project_root: str, style: str) -> str:
    payload = run_json([
        *python_command(
            script,
            "--skill-name",
            skill_name,
            "--skills-root",
            skills_root,
            "--project-root",
            project_root,
            "--style",
            style,
        )
    ])
    return payload["prompt"]


def render_markdown(result: dict) -> str:
    return f"""# Research Skill Quickstart

## Recommendation

- invocation_contract: {result['invocation_contract']}
- minimal_invocation_template:

```text
{result['minimal_invocation_template']}
```
- recommended_track: `{result['recommended_track']}`
- recommended_skill: `{result['recommended_skill']}`
- recommended_skill_file: `{result['recommended_skill_file']}`
- recommended_start: `{result['recommended_start']}`
- recommended_window_count: `{result['recommended_window_count']}`
- search_mode_decision_note: {result['search_mode_decision_note']}
- autonomous_single_window_note: {result['autonomous_single_window_note']}
- low_tool_mode_file: `{result['low_tool_mode_file']}`
- low_tool_mode_note: {result['low_tool_mode_note']}
- no_local_file_access_mode_file: `{result['no_local_file_access_mode_file']}`
- no_local_file_access_mode_note: {result['no_local_file_access_mode_note']}
- operator_handoff_contract_file: `{result['operator_handoff_contract_file']}`
- transfer_packet_recommendation: {result['transfer_packet_recommendation']}

## Transfer Packet Commands

- hub: `{result['transfer_packet_portable_commands']['hub']}`
- full: `{result['transfer_packet_portable_commands']['full']}`
- lite: `{result['transfer_packet_portable_commands']['lite']}`

## Platform Profile Recommendation

```json
{json.dumps(result['platform_profile_recommendation'], ensure_ascii=False, indent=2)}
```

## Recommended Prompt

```text
{result['recommended_prompt']}
```

## Autonomous Full Prompt

```text
{result['autonomous_full_prompt']}
```

## Direct Recommended Skill Prompt

```text
{result['direct_recommended_prompt']}
```

## Recommended Prompt For Codex

```text
{result['recommended_prompt_codex']}
```

## Direct Recommended Skill Prompt For Codex

```text
{result['direct_recommended_prompt_codex']}
```

## Hub Prompt

```text
{result['hub_prompts']['universal']}
```

## Hub Prompt For Codex

```text
{result['hub_prompts']['codex']}
```

## Full Prompt

```text
{result['full_prompts']['universal']}
```

## Full Prompt For Codex

```text
{result['full_prompts']['codex']}
```

## Full Prompt Bundle

````text
{result['full_prompts']['bundle']}
````

## Lite Prompt

```text
{result['lite_prompts']['universal']}
```

## Lite Prompt For Codex

```text
{result['lite_prompts']['codex']}
```

## Lite Prompt Bundle

````text
{result['lite_prompts']['bundle']}
````
"""


if __name__ == "__main__":
    main()
