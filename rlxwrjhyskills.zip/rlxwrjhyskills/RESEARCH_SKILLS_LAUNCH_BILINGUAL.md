# Research Skills Launch Guide / 研究技能启动手册

This guide is portable. Set `<FAMILY_ROOT>` to the extracted folder containing `README.md`, `START_HERE_PROMPTS.md`, and the three skill folders. Set `<PROJECT_ROOT>` to the project you want to research.

本手册可移植使用。将 `<FAMILY_ROOT>` 设置为包含 `README.md`、`START_HERE_PROMPTS.md` 和三个技能文件夹的解压目录；将 `<PROJECT_ROOT>` 设置为需要研究的项目目录。

## 1. Prepare paths / 准备路径

```powershell
$python = "python"
$familyRoot = "<FAMILY_ROOT>"
$projectRoot = "<PROJECT_ROOT>"
$fullRoot = "<FULL_WORKSPACE>"
```

Use `-B` on every Python command to avoid bytecode cache files. / 每条 Python 命令都使用 `-B`，避免产生字节码缓存。

## 2. Validate and route / 校验并路由

```powershell
& $python -B "$familyRoot\validate_research_skill_family.py"
& $python -B "$familyRoot\research-skill-hub\scripts\recommend_local_skill.py" `
  --skills-root $familyRoot `
  --project-root $projectRoot `
  --format markdown
```

The Hub lists Lite and Full, recommends an entry, and waits for your explicit choice. / Hub 会列出 Lite 和 Full，给出推荐，并等待你的明确选择。

## 3. Start Lite / 启动 Lite

Lite is for fast triage and action mapping. / Lite 适合快速分诊和行动映射。

```powershell
$liteRoot = "<LITE_WORKSPACE>"
& $python -B "$familyRoot\research-pipeline-lite\scripts\init_research_workspace.py" --root $liteRoot
& $python -B "$familyRoot\research-pipeline-lite\scripts\validate_research_workspace.py" $liteRoot
& $python -B "$familyRoot\research-pipeline-lite\scripts\sync_decision_surfaces.py" `
  --workspace-root $liteRoot `
  --source-project-root $projectRoot `
  --overwrite-generated
```

Review `03_output/implementation_snapshot.csv`. Upgrade to Full for execution, promotion, benchmark freeze, or release decisions. / 检查 `03_output/implementation_snapshot.csv`；涉及执行、晋级、基准冻结或发布时升级到 Full。

## 4. Start Full / 启动 Full

```powershell
& $python -B "$familyRoot\research-pipeline-full\scripts\init_research_program.py" `
  --root $fullRoot `
  --mode windowed-search `
  --profile generic
& $python -B "$familyRoot\research-pipeline-full\scripts\validate_windowed_research_program.py" $fullRoot generic
```

Use `--profile quant-research` for quantitative work. Add `--autonomous-mode` when multiple windows are unavailable. / 量化研究使用 `--profile quant-research`；无法打开多个窗口时加入 `--autonomous-mode`。

## 5. Apply implementation gates / 执行实现门控

```powershell
& $python -B "$familyRoot\research-pipeline-full\scripts\assess_implementation_maturity.py" `
  --workspace-root $fullRoot `
  --project-root $projectRoot `
  --profile generic `
  --target-stage experiment_execution `
  --write-workspace
```

Review `05_validation/IMPLEMENTATION_READINESS.md`, `route_readiness_matrix.csv`, and `implementation_backlog.csv`. Research credibility and implementation maturity remain independent; both gates must pass before execution or promotion. / 检查上述三个文件。研究可信度与实现成熟度始终独立，执行或晋级前两条门控都必须通过。

## 6. Copy-paste prompt / 可复制提示词

```text
Task: Inspect my project and help me improve or rebuild it. Audit the existing research, code, tests, entrypoints, dependencies, and delivery surfaces; identify what to keep, replace, or retire; then create and implement an authorized improvement plan with a rollback path for destructive changes.
任务：盘点我的项目并帮助我改良或推倒重来。审计现有研究、代码、测试、入口、依赖和交付表面，识别应保留、替换或废弃的部分；然后建立并实施已授权的改良计划，对破坏性修改保留回退路径。

Skill file: <FAMILY_ROOT>\research-pipeline-full\SKILL.md
Instruction: Read that SKILL.md completely first. Keep research credibility and implementation maturity separate, require explicit route_id mapping, and block execution or promotion until both target-stage gates pass. Do not modify business code beyond my authorization.
指令：先完整阅读 SKILL.md。将研究可信度和代码实现成熟度分开评估，要求显式 route_id 映射，并在目标阶段两条门控通过前阻止执行或晋级。未经我的授权不要修改业务代码。
```

## 7. GitHub upload / 上传 GitHub

Upload the ZIP and this Markdown guide as the two top-level files you need. / 将 ZIP 和这份 Markdown 说明作为需要上传的两个顶层文件。

If you want the extracted skills as a repository, run the following inside `<FAMILY_ROOT>`: / 如果要把解压后的技能作为仓库，在 `<FAMILY_ROOT>` 中执行：

```powershell
Set-Location <FAMILY_ROOT>
git init
git add .
git commit -m "Release research skills v1.1.0"
git branch -M main
git remote add origin <GITHUB_REPOSITORY_URL>
git push -u origin main
```

The repository URL and credentials are intentionally left to the operator. / 仓库地址和凭据由操作者自行填写。
