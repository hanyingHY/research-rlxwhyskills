#!/usr/bin/env python3
"""Shared contract constants for the research skill family."""

from __future__ import annotations


SKILL_DIRS = ["research-skill-hub", "research-pipeline-full", "research-pipeline-lite"]

TOP_LEVEL_TOOL_FILES = [
    "assess_research_project_state.py",
    "build_research_skill_prompt.py",
    "audit_research_skill_family_readiness.py",
    "export_research_skill_family.py",
    "generate_research_platform_adapter_pack.py",
    "generate_research_skill_transfer_packet.py",
    "generate_research_skill_quickstart.py",
    "prepare_research_project.py",
    "recommend_research_platform_profile.py",
    "research_skill_family_contract.py",
    "research_runtime.py",
    "research_skill_console.py",
    "route_research_skill_entry.py",
    "smoke_test_research_skill_family.py",
    "validate_research_skill_family.py",
]

TOP_LEVEL_EXPORT_FILES = [
    "README.md",
    "START_HERE_PROMPTS.md",
    "RESEARCH_SKILLS_GUIDE_BILINGUAL.md",
    "RESEARCH_SKILLS_LAUNCH_BILINGUAL.md",
    "LOW_TOOL_MODE.md",
    "OPERATOR_HANDOFF_CONTRACT.md",
    "NO_LOCAL_FILE_ACCESS_MODE.md",
    "audit_research_skill_family_readiness.py",
    "research_skill_family.json",
    "research_platform_profiles.json",
    "build_research_skill_prompt.py",
    "export_research_skill_family.py",
    "generate_research_platform_adapter_pack.py",
    "generate_research_skill_transfer_packet.py",
    "prepare_research_project.py",
    "recommend_research_platform_profile.py",
    "research_skill_family_contract.py",
    "research_runtime.py",
    "route_research_skill_entry.py",
    "assess_research_project_state.py",
    "research_skill_console.py",
    "generate_research_skill_quickstart.py",
    "validate_research_platform_profiles.py",
    "validate_research_skill_family.py",
    "smoke_test_research_skill_family.py",
]


def export_manifest_required_keys() -> list[str]:
    return [
        "readme",
        "start_here_prompts",
        "low_tool_mode",
        "operator_handoff_contract",
        "no_local_file_access_mode",
        "family_readiness_audit",
        "family_metadata",
        "family_platform_profiles",
        "family_prompt_builder",
        "family_exporter",
        "family_adapter_generator",
        "family_transfer_packet_generator",
        "family_platform_profile_validator",
        "family_platform_profile_recommender",
        "family_project_preparer",
        "family_runtime",
        "family_router",
        "family_state_assessor",
        "family_console",
        "family_quickstart",
        "family_validator",
        "family_smoke_test",
        *SKILL_DIRS,
    ]
