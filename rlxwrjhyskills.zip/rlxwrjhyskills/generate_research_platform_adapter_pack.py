#!/usr/bin/env python3
"""Generate a platform-adapter prompt pack for the research skill family."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True

from research_runtime import python_command, run_json


CAPABILITY_ARG_MAP = [
    ("supports_local_file_paths", "--requires-local-file-paths"),
    ("supports_local_writes", "--requires-local-writes"),
    ("supports_subprocess_execution", "--requires-subprocess-execution"),
    ("supports_bundled_scripts", "--requires-bundled-scripts"),
    ("supports_multi_window_self_launch", "--requires-multi-window-self-launch"),
    ("supports_owned_scope_isolation", "--requires-owned-scope-isolation"),
]


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate a platform-adapter prompt pack for the research skill family")
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--profile", default="generic")
    parser.add_argument("--platform-profile", default="generic-skill-loader")
    parser.add_argument("--all-profiles", action="store_true")
    parser.add_argument("--auto-recommend-profile", action="store_true")
    parser.add_argument("--requires-local-file-paths", choices=["yes", "no"], default="yes")
    parser.add_argument("--requires-local-writes", choices=["yes", "no"], default="yes")
    parser.add_argument("--requires-subprocess-execution", choices=["yes", "no"], default="no")
    parser.add_argument("--requires-bundled-scripts", choices=["yes", "no"], default="yes")
    parser.add_argument("--requires-multi-window-self-launch", choices=["yes", "no"], default="no")
    parser.add_argument("--requires-owned-scope-isolation", choices=["yes", "no"], default="no")
    parser.add_argument("--preferred-execution-posture", choices=["tool_runner", "manual_operator", "worker_lane"])
    parser.add_argument("--preferred-prompt-style", choices=["universal", "codex"])
    parser.add_argument("--output")
    parser.add_argument("--format", choices=["json", "markdown"], default="json")
    args = parser.parse_args()

    skills_root = Path(__file__).resolve().parent
    project_root = Path(args.project_root).resolve()
    profiles_payload = json.loads((skills_root / "research_platform_profiles.json").read_text(encoding="utf-8"))

    quickstart_payload = run_json([
        *python_command(
            skills_root / "generate_research_skill_quickstart.py",
            "--project-root",
            project_root,
            "--profile",
            args.profile,
        )
    ])

    if args.all_profiles:
        result = build_all_profiles_result(skills_root, project_root, args.profile, profiles_payload, quickstart_payload)
    else:
        auto_recommendation = None
        if args.auto_recommend_profile:
            auto_recommendation = run_json(build_recommendation_command(skills_root, args))
            profile_entry = resolve_platform_profile(profiles_payload, auto_recommendation["recommended_profile"]["id"])
        else:
            profile_entry = resolve_platform_profile(profiles_payload, args.platform_profile)
        result = build_result(skills_root, project_root, args.profile, profile_entry, quickstart_payload, auto_recommendation)

    if args.output:
        output = Path(args.output).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        if args.format == "markdown":
            output.write_text(render_markdown(result), encoding="utf-8")
        else:
            output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(result, ensure_ascii=False, indent=2))


def resolve_platform_profile(profiles_payload: dict, profile_id: str) -> dict:
    for item in profiles_payload.get("profiles", []):
        if item.get("id") == profile_id:
            return item
    raise KeyError(f"Unknown platform profile: {profile_id}")


def build_result(skills_root: Path, project_root: Path, profile: str, platform_profile: dict, quickstart_payload: dict, auto_recommendation: dict | None = None) -> dict:
    adapter_prompts = {
        "hub": adapt_prompt(quickstart_payload["hub_prompts"][platform_profile["prompt_style"]], platform_profile),
        "full": adapt_prompt(quickstart_payload["full_prompts"][platform_profile["prompt_style"]], platform_profile),
        "lite": adapt_prompt(quickstart_payload["lite_prompts"][platform_profile["prompt_style"]], platform_profile),
        "recommended": adapt_prompt(quickstart_payload[f"recommended_prompt{'_codex' if platform_profile['prompt_style'] == 'codex' else ''}"] if platform_profile["prompt_style"] == "codex" else quickstart_payload["recommended_prompt"], platform_profile),
        "direct_recommended": adapt_prompt(quickstart_payload[f"direct_recommended_prompt{'_codex' if platform_profile['prompt_style'] == 'codex' else ''}"] if platform_profile["prompt_style"] == "codex" else quickstart_payload["direct_recommended_prompt"], platform_profile),
        "autonomous_full": adapt_prompt(quickstart_payload["autonomous_full_prompt"], platform_profile),
    }

    return {
        "schema_version": 1,
        "result_kind": "single_profile",
        "project_root": str(project_root),
        "profile": profile,
        "profiles_file": str(skills_root / "research_platform_profiles.json"),
        "recommended_skill": quickstart_payload["recommended_skill"],
        "recommended_track": quickstart_payload["recommended_track"],
        "recommended_start": quickstart_payload["recommended_start"],
        "recommended_window_count": quickstart_payload["recommended_window_count"],
        "platform_profile": platform_profile,
        "auto_recommendation": auto_recommendation,
        "invocation_contract": quickstart_payload["invocation_contract"],
        "minimal_invocation_template": quickstart_payload["minimal_invocation_template"],
        "low_tool_mode_file": quickstart_payload.get("low_tool_mode_file"),
        "low_tool_mode_note": quickstart_payload.get("low_tool_mode_note"),
        "no_local_file_access_mode_file": quickstart_payload.get("no_local_file_access_mode_file"),
        "no_local_file_access_mode_note": quickstart_payload.get("no_local_file_access_mode_note"),
        "operator_handoff_contract_file": quickstart_payload.get("operator_handoff_contract_file"),
        "adapter_prompts": adapter_prompts,
        "migration_backup_hint": str(project_root / "rlxwrjhyskills.zip"),
        "family_backup_command": build_backup_command(skills_root, project_root),
    }


def build_all_profiles_result(skills_root: Path, project_root: Path, profile: str, profiles_payload: dict, quickstart_payload: dict) -> dict:
    profiles = profiles_payload.get("profiles", [])
    results = [build_result(skills_root, project_root, profile, item, quickstart_payload) for item in profiles]
    capability_matrix = [
        {
            "id": item["platform_profile"]["id"],
            "prompt_style": item["platform_profile"]["prompt_style"],
            "execution_posture": item["platform_profile"]["execution_posture"],
            "supports_local_file_paths": item["platform_profile"]["supports_local_file_paths"],
            "supports_bundled_scripts": item["platform_profile"]["supports_bundled_scripts"],
            "multi_window_launch_model": item["platform_profile"]["multi_window_launch_model"],
        }
        for item in results
    ]
    return {
        "schema_version": 1,
        "result_kind": "all_profiles",
        "project_root": str(project_root),
        "profile": profile,
        "profiles_file": str(skills_root / "research_platform_profiles.json"),
        "recommended_skill": quickstart_payload["recommended_skill"],
        "recommended_track": quickstart_payload["recommended_track"],
        "recommended_start": quickstart_payload["recommended_start"],
        "recommended_window_count": quickstart_payload["recommended_window_count"],
        "invocation_contract": quickstart_payload["invocation_contract"],
        "minimal_invocation_template": quickstart_payload["minimal_invocation_template"],
        "low_tool_mode_file": quickstart_payload.get("low_tool_mode_file"),
        "low_tool_mode_note": quickstart_payload.get("low_tool_mode_note"),
        "no_local_file_access_mode_file": quickstart_payload.get("no_local_file_access_mode_file"),
        "no_local_file_access_mode_note": quickstart_payload.get("no_local_file_access_mode_note"),
        "operator_handoff_contract_file": quickstart_payload.get("operator_handoff_contract_file"),
        "capability_matrix": capability_matrix,
        "profiles": results,
    }


def build_recommendation_command(skills_root: Path, args: argparse.Namespace) -> list[str]:
    command = [
        *python_command(
            skills_root / "recommend_research_platform_profile.py",
            "--profiles-file",
            skills_root / "research_platform_profiles.json",
        )
    ]
    for _, flag in CAPABILITY_ARG_MAP:
        attr = flag.removeprefix("--").replace("-", "_")
        command.extend([flag, getattr(args, attr)])
    if args.preferred_execution_posture:
        command.extend(["--preferred-execution-posture", args.preferred_execution_posture])
    if args.preferred_prompt_style:
        command.extend(["--preferred-prompt-style", args.preferred_prompt_style])
    return command


def build_backup_command(skills_root: Path, project_root: Path) -> str:
    return f'python "-B" "{skills_root / "export_research_skill_family.py"}" --output-dir "{project_root}" --bundle-name "rlxwrjhyskills" --manifest-output "{project_root / "rlxwrjhyskills_manifest.json"}" --overwrite'


def adapt_prompt(prompt: str, platform_profile: dict) -> str:
    overlay = " ".join(platform_profile.get("overlay", []))
    assumptions = " ".join(platform_profile.get("assumptions", []))
    posture = platform_profile.get("execution_posture", "unspecified")
    fallback = ""
    if not platform_profile.get("supports_multi_window_self_launch", False):
        fallback = " Autonomous note: if multi-window help is unavailable, fall back to one-window phased execution instead of blocking."
    return (
        prompt
        + "\n\n"
        + f"Platform adapter profile: {platform_profile['display_name']} ({platform_profile['id']}).\n"
        + f"Execution posture: {posture}.\n"
        + f"Assumptions: {assumptions}\n"
        + f"Adapter overlay: {overlay}{fallback}"
    )


def render_markdown(result: dict) -> str:
    if result.get("result_kind") == "all_profiles":
        matrix_lines = "\n".join(
            f"- `{item['id']}`: style `{item['prompt_style']}`, posture `{item['execution_posture']}`, local_paths `{item['supports_local_file_paths']}`, bundled_scripts `{item['supports_bundled_scripts']}`, multi_window `{item['multi_window_launch_model']}`"
            for item in result.get("capability_matrix", [])
        ) or "- none"
        sections: list[str] = [
            "# Research Platform Adapter Pack",
            "",
            "## Summary",
            "",
            f"- recommended_skill: `{result['recommended_skill']}`",
            f"- recommended_track: `{result['recommended_track']}`",
            f"- recommended_start: `{result['recommended_start']}`",
            f"- recommended_window_count: `{result['recommended_window_count']}`",
            "",
            "## Invocation Contract",
            "",
            "```text",
            result["minimal_invocation_template"],
            "```",
            "",
            "## Capability Matrix",
            "",
            matrix_lines,
            "",
            "## Low Tool Mode",
            "",
            f"- file: `{result.get('low_tool_mode_file')}`",
            f"- note: {result.get('low_tool_mode_note')}",
            f"- no_local_file_access_mode_file: `{result.get('no_local_file_access_mode_file')}`",
            f"- no_local_file_access_mode_note: {result.get('no_local_file_access_mode_note')}",
            f"- operator_handoff_contract_file: `{result.get('operator_handoff_contract_file')}`",
        ]
        for item in result.get("profiles", []):
            assumptions = "\n".join(f"- {entry}" for entry in item["platform_profile"].get("assumptions", [])) or "- none"
            overlay = "\n".join(f"- {entry}" for entry in item["platform_profile"].get("overlay", [])) or "- none"
            sections.extend([
                "",
                f"## {item['platform_profile']['display_name']}",
                "",
                f"- id: `{item['platform_profile']['id']}`",
                f"- prompt_style: `{item['platform_profile']['prompt_style']}`",
                f"- execution_posture: `{item['platform_profile']['execution_posture']}`",
                "",
                "### Assumptions",
                "",
                assumptions,
                "",
                "### Overlay",
                "",
                overlay,
                "",
                "### Recommended Prompt",
                "",
                "```text",
                item["adapter_prompts"]["recommended"],
                "```",
                "",
                "### Autonomous Full Prompt",
                "",
                "```text",
                item["adapter_prompts"]["autonomous_full"],
                "```",
            ])
        return "\n".join(sections) + "\n"

    assumptions = "\n".join(f"- {item}" for item in result["platform_profile"].get("assumptions", [])) or "- none"
    overlay = "\n".join(f"- {item}" for item in result["platform_profile"].get("overlay", [])) or "- none"
    auto_recommendation = ""
    if result.get("auto_recommendation"):
        auto_recommendation = f"\n## Auto Recommendation\n\n```json\n{json.dumps(result['auto_recommendation'], ensure_ascii=False, indent=2)}\n```\n"
    return f"""# Research Platform Adapter Pack

## Summary

- recommended_skill: `{result['recommended_skill']}`
- recommended_track: `{result['recommended_track']}`
- recommended_start: `{result['recommended_start']}`
- recommended_window_count: `{result['recommended_window_count']}`
- platform_profile: `{result['platform_profile']['id']}`
- prompt_style: `{result['platform_profile']['prompt_style']}`
- execution_posture: `{result['platform_profile']['execution_posture']}`

## Invocation Contract

```text
{result['minimal_invocation_template']}
```

## Low Tool Mode

- file: `{result.get('low_tool_mode_file')}`
- note: {result.get('low_tool_mode_note')}
- no_local_file_access_mode_file: `{result.get('no_local_file_access_mode_file')}`
- no_local_file_access_mode_note: {result.get('no_local_file_access_mode_note')}
- operator_handoff_contract_file: `{result.get('operator_handoff_contract_file')}`

## Platform Assumptions

{assumptions}

## Platform Overlay

{overlay}
{auto_recommendation}

## Recommended Prompt

```text
{result['adapter_prompts']['recommended']}
```

## Direct Recommended Skill Prompt

```text
{result['adapter_prompts']['direct_recommended']}
```

## Autonomous Full Prompt

```text
{result['adapter_prompts']['autonomous_full']}
```

## Hub Prompt

```text
{result['adapter_prompts']['hub']}
```

## Full Prompt

```text
{result['adapter_prompts']['full']}
```

## Lite Prompt

```text
{result['adapter_prompts']['lite']}
```

## Backup Export Command

```text
{result['family_backup_command']}
```
"""


if __name__ == "__main__":
    main()
