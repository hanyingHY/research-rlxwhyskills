# rlxwrjhyskills

Migrated research skill family bundle.

# Research Skills Guide

This directory contains reusable research-operation skills for future handoffs and new tasks.

If you need a copy-paste-ready starting point without running helper scripts first, open `START_HERE_PROMPTS.md`.

If the target environment is weak on tools, open `LOW_TOOL_MODE.md`.

If the active agent must hand control back to a human or stronger agent for writes, scripts, or window launch, use `OPERATOR_HANDOFF_CONTRACT.md`.

If the target environment cannot read local file paths at all, use `NO_LOCAL_FILE_ACCESS_MODE.md`.

## Available skills

### 0. Research Skill Hub

Path: `research-skill-hub/SKILL.md`

Use it when:

1. the user first needs to discover what local research skills are available
2. the user wants a unified keyword or unified entry into the skill family
3. the user wants to choose one local skill and then jump directly into it

What it gives you:

1. local skill discovery
2. local skill comparison
3. direct handoff prompt generation into the chosen skill
4. universal-first prompt variants plus optional Codex-specific prompt variants for cross-agent reuse
5. corrected UI metadata discovery from `agents/openai.yaml` so skill listings expose the intended display names and concise summaries

### 1. Research Pipeline Lite

Path: `research-pipeline-lite/SKILL.md`

Use it when:

1. the corpus is small or medium
2. one operator or one window is enough
3. the goal is to move quickly from raw material to a shortlist and action plan

What it gives you:

1. fast intake workflow
2. retained evidence table
3. action mapping
4. lightweight workspace scaffold script
5. universal-first entry prompts plus optional Codex-specific variants for reuse in other AI environments

### 2. Research Pipeline Full

Path: `research-pipeline-full/SKILL.md`

Use it when:

1. the corpus is large, growing, or contradictory
2. multiple agents or windows are contributing
3. the research must drive experiments, validation plans, or cloud execution
4. provenance and benchmark freezing matter
5. you need a multi-window frontier-source expansion program with strict evidence control

What it gives you:

1. full research program workflow
2. evidence grading rules
3. validation-program design references
4. cloud-execution planning references
5. full research-program scaffold script
6. multi-window search-program guidance
7. corpus governance and quarantine-over-delete rules
8. report contract for final synthesis output
9. generated 10-window prompt-pack and role-map scaffold in `windowed-search` mode
10. local non-PyYAML skill validator and windowed-workspace validator
11. explicit user-controlled direction selection, depth selection, and direction-depth budget planning before long deep cycles
12. universal-first launch prompts plus optional Codex-specific variants for cross-agent reuse
13. bytecode-safe smoke and validation flow that keeps exported or source skills free of `__pycache__` and `*.pyc` pollution
14. explicit stage-level single-window versus multi-window control surfaces
15. machine-readable research audit traces for search rounds, source authority checks, and credibility summaries
16. autonomous-mode fallback that can serialize the multi-window research roles inside one window when the user cannot help open multiple windows

## Which one to choose

Use `lite` if you need speed.

Use `full` if you need auditability, coordination, and downstream execution planning.

Use `full` in autonomous mode when you want the agent to keep pushing toward the strongest reachable in-scope result and you accept higher token consumption.

If the user cannot help open multiple windows, autonomous `full` mode can still proceed by executing the multi-window responsibilities serially inside one window.

## Minimal Invocation Contract

This skill family is designed around one portable activation rule:

1. one task statement
2. one reachable `SKILL.md` file address

That should be enough for a skill-capable agent to load the selected skill, read its referenced local resources, and continue correctly.

Minimal template:

```text
Task: <TASK_STATEMENT>
Skill file: <ABSOLUTE_PATH_TO_SKILL_MD>
Instruction: Read that SKILL.md completely first, then follow its referenced local resources and bundled scripts before continuing the task.
```

Static copy-paste prompts are also provided in `START_HERE_PROMPTS.md` for environments where you want a ready-made starter without executing any local generator first.

## Family-level tools

This directory now also contains shared family-level helpers:

1. `export_research_skill_family.py`
   - export both research skills together as a reusable copy and/or zip bundle
   - can also export a migration backup such as `rlxwrjhyskills`
2. `build_research_skill_prompt.py`
   - build a reusable activation prompt directly from a `SKILL.md` file path, without requiring local skill discovery first
3. `audit_research_skill_family_readiness.py`
   - run a repeatable readiness audit across source family, export family, and optional real prepared workspaces
4. `generate_research_platform_adapter_pack.py`
   - generate a platform-specific adapter pack for agents that differ in script execution, window orchestration, or manual-operator posture
   - can also generate one combined pack for all known platform profiles
5. `recommend_research_platform_profile.py`
   - recommend the best platform profile from explicit execution-capability constraints instead of requiring manual profile selection
6. `prepare_research_project.py`
   - prepare a project end to end by chaining state assessment, quickstart generation, recommended full/lite workspace initialization, and decision-surface synchronization
7. `route_research_skill_entry.py`
   - inspect a new project and recommend the best research-skill entry path, while also generating entry prompt bundles
8. `assess_research_project_state.py`
   - classify any project root as raw, lite-workspace, or full-workspace and return the right high-level judgment
9. `research_skill_console.py`
   - provide a single-entry command surface that combines project-state judgment, recommended prompts, runnable commands, review checkpoints, portable command templates, backup export commands, and audit-trace review gates
   - includes explicit autonomous-mode initialization and prompt-pack refresh commands plus a visible single-window fallback note for cases where the user cannot help open multiple windows
10. `generate_research_skill_quickstart.py`
   - emit a ready-to-copy quickstart pack containing hub/full/lite prompts in universal-first form plus optional Codex-specific variants
11. `generate_research_skill_transfer_packet.py`
   - build a single transferable packet containing the selected activation prompt, SKILL body, and required reference files for environments that cannot read local files
12. `research_platform_profiles.json`
   - define reusable cross-agent platform adapter profiles for generic loaders, Codex-like agents, manual chat operators, read-only reviewers, and orchestrated worker lanes
13. `validate_research_platform_profiles.py`
   - validate platform profile semantics before export or reuse
14. `research-skill-hub/`
   - a local skill-discovery and selection hub skill for open or shared skill families
15. deeper family and local validators
   - detect missing referenced resources, invalid `openai.yaml` metadata, cache artifacts, nonportable local hardcoding, and missing full-workspace CSV audit traces before export or reuse
16. `LOW_TOOL_MODE.md`
   - describe the no-script, no-write, no-multi-window fallback for weak-tool agent environments
17. `OPERATOR_HANDOFF_CONTRACT.md`
   - define the exact fields a weak-tool agent should emit when it must hand execution back to a human or stronger agent
18. `NO_LOCAL_FILE_ACCESS_MODE.md`
   - define how to transfer a selected skill into environments that cannot read local files by path at all

## Local examples

This repository may also contain project-specific notes or execution plans near these skills. Treat those as local examples, not as part of the reusable skill contract.
