#!/usr/bin/env python3
"""Smoke test for research-skill-hub."""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True

from local_runtime import python_command, run_command


def main() -> None:
    skill_root = Path(__file__).resolve().parents[1]
    skills_root = skill_root.parent
    tmp = Path(tempfile.mkdtemp(prefix="research_skill_hub_smoke_"))

    validate_script = skill_root / "scripts" / "validate_skill_local.py"
    discover_script = skill_root / "scripts" / "discover_local_skills.py"
    recommend_script = skill_root / "scripts" / "recommend_local_skill.py"
    select_script = skill_root / "scripts" / "build_skill_selection_prompt.py"
    export_script = skill_root / "scripts" / "export_skill_bundle.py"

    raw_project = tmp / "raw_project"
    raw_project.mkdir(parents=True, exist_ok=True)
    (raw_project / "notes.md").write_text("# Notes\n\nEarly research notes.\n", encoding="utf-8")

    discover_report = tmp / "discover.md"
    recommend_report = tmp / "recommend.md"
    select_report = tmp / "select.md"
    export_root = tmp / "hub_export"

    steps = [
        run_step(python_command(validate_script, skill_root), skills_root),
        run_step(python_command(discover_script, "--skills-root", skills_root, "--output", discover_report, "--format", "markdown"), skills_root),
        run_step(python_command(recommend_script, "--skills-root", skills_root, "--project-root", raw_project, "--output", recommend_report, "--format", "markdown"), skills_root),
        run_step(python_command(select_script, "--skill-name", "research-pipeline-lite", "--skills-root", skills_root, "--project-root", raw_project, "--output", select_report, "--format", "markdown"), skills_root),
        run_step(python_command(export_script, "--output-dir", export_root, "--manifest-output", export_root / 'manifest.json', "--overwrite"), skills_root),
        run_step(python_command(export_root / 'research-skill-hub' / 'scripts' / 'validate_skill_local.py', export_root / 'research-skill-hub'), export_root / 'research-skill-hub'),
    ]

    discover_payload = parse_json_stdout(steps[1])
    recommend_payload = parse_json_stdout(steps[2])
    content_checks = {
        "discover_display_names_ok": [item.get("display_name") for item in discover_payload.get("skills", [])] == ["Research Pipeline Full", "Research Pipeline Lite", "Research Skill Hub"],
        "recommend_selected_skill_file_ok": recommend_payload.get("selected_skill_file", "").endswith("research-pipeline-lite\\SKILL.md"),
        "recommend_minimal_prompt_ok": "Skill file:" in recommend_payload.get("selection_prompt_minimal", ""),
        "recommend_available_entries_ok": recommend_payload.get("available_skill_count") == 3 and len(recommend_payload.get("available_skills", [])) == 3,
        "recommend_waits_for_choice_ok": "wait for the user's explicit choice before routing" in recommend_payload.get("selection_prompt_codex", "").lower() and "explicitly choose which skill to enter before routing anywhere" in recommend_payload.get("selection_prompt", "").lower(),
        "export_bundle_manifest_exists": (export_root / 'manifest.json').exists(),
        "export_bundle_dir_exists": (export_root / 'research-skill-hub').exists(),
    }

    status = "ready" if all(step["returncode"] == 0 for step in steps) and all(content_checks.values()) else "needs_attention"
    result = {
        "skill_root": str(skill_root),
        "workspace_root": str(tmp),
        "steps": steps,
        "content_checks": content_checks,
        "status": status,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if status == "ready" else 1)


def run_step(command: list[str], cwd: Path) -> dict:
    completed = run_command(command, cwd=cwd, check=False)
    return {
        "command": command,
        "returncode": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def parse_json_stdout(step: dict) -> dict:
    try:
        return json.loads(step.get("stdout") or "{}")
    except json.JSONDecodeError:
        return {}


if __name__ == "__main__":
    main()
