#!/usr/bin/env python3
"""Audit the current research skill family and optional prepared workspaces."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True

from research_runtime import python_command, run_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Audit the readiness of a research skill family")
    parser.add_argument("--family-root", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--project-root")
    parser.add_argument("--source-workspace")
    parser.add_argument("--export-workspace")
    parser.add_argument("--export-family-root")
    parser.add_argument("--output")
    parser.add_argument("--format", choices=["json", "markdown"], default="json")
    args = parser.parse_args()

    family_root = Path(args.family_root).resolve()
    project_root = Path(args.project_root).resolve() if args.project_root else family_root.parent

    source_workspace = resolve_optional_path(args.source_workspace) or project_root / "audit" / "source_realworld_program"
    export_workspace = resolve_optional_path(args.export_workspace) or project_root / "audit" / "export_realworld_program"
    export_family_root = resolve_optional_path(args.export_family_root) or project_root / "rlxwrjhyskills"

    family_validation = run_json([*python_command(family_root / "validate_research_skill_family.py")])
    family_smoke = run_json([*python_command(family_root / "smoke_test_research_skill_family.py")])
    export_validation = run_json([*python_command(export_family_root / "validate_research_skill_family.py")]) if export_family_root.exists() else {"status": "missing"}
    export_smoke = run_json([*python_command(export_family_root / "smoke_test_research_skill_family.py")]) if export_family_root.exists() else {"status": "missing"}

    source_workspace_audit = inspect_workspace(family_root, source_workspace)
    export_workspace_audit = inspect_workspace(export_family_root if export_family_root.exists() else family_root, export_workspace)

    checks = {
        "family_validation_ready": family_validation.get("status") == "ready",
        "family_smoke_ready": family_smoke.get("status") == "ready",
        "export_validation_ready": export_validation.get("status") == "ready",
        "export_smoke_ready": export_smoke.get("status") == "ready",
        "source_workspace_ready": source_workspace_audit.get("status") == "ready",
        "export_workspace_ready": export_workspace_audit.get("status") == "ready",
    }

    result = {
        "schema_version": 1,
        "family_root": str(family_root),
        "project_root": str(project_root),
        "source_workspace": str(source_workspace),
        "export_workspace": str(export_workspace),
        "export_family_root": str(export_family_root),
        "checks": checks,
        "family_validation": family_validation,
        "family_smoke": family_smoke,
        "export_validation": export_validation,
        "export_smoke": export_smoke,
        "source_workspace_audit": source_workspace_audit,
        "export_workspace_audit": export_workspace_audit,
        "status": "ready" if all(checks.values()) else "needs_attention",
    }

    if args.output:
        output = Path(args.output).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        if args.format == "markdown":
            output.write_text(render_markdown(result), encoding="utf-8")
        else:
            output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if result["status"] == "ready" else 1)


def resolve_optional_path(raw: str | None) -> Path | None:
    if not raw:
        return None
    return Path(raw).resolve()


def inspect_workspace(family_root: Path, workspace_root: Path) -> dict:
    if not workspace_root.exists():
        return {"workspace_root": str(workspace_root), "status": "missing"}

    state = run_json([*python_command(family_root / "assess_research_project_state.py", "--project-root", workspace_root)])
    checks = {
        "state_known": state.get("project_kind") in {"full_workspace", "lite_workspace"},
        "operator_handoff_contract_exists": Path(state.get("operator_handoff_contract_path", "missing")).exists(),
    }

    if state.get("project_kind") == "full_workspace":
        validation = run_json([*python_command(family_root / "research-pipeline-full" / "scripts" / "validate_windowed_research_program.py", workspace_root, "generic")])
        checks["workspace_validator_ready"] = validation.get("status") == "ready"
        checks["autonomous_serial_plan_exists"] = (workspace_root / "00_protocol" / "AUTONOMOUS_SERIAL_PLAN.md").exists() or not (workspace_root / "00_protocol" / "AUTONOMY_STATUS.md").exists()
        checks["master_source_index_has_evidence_class"] = csv_header_contains(workspace_root / "05_master_tables" / "master_source_index.csv", "evidence_class")
        checks["source_authority_log_has_evidence_class"] = csv_header_contains(workspace_root / "12_ingestion_logs" / "source_authority_log.csv", "evidence_class")
        checks["retained_evidence_has_evidence_class"] = csv_header_contains(workspace_root / "03_evidence" / "retained_evidence.csv", "evidence_class")
        checks["worker_evidence_matrix_has_evidence_class"] = all_worker_headers_include(workspace_root / "01_window_runs", "evidence_matrix.csv", "evidence_class")
    elif state.get("project_kind") == "lite_workspace":
        validation = run_json([*python_command(family_root / "research-pipeline-lite" / "scripts" / "validate_research_workspace.py", workspace_root)])
        checks["workspace_validator_ready"] = validation.get("status") == "ready"
        checks["autonomous_serial_plan_exists"] = (workspace_root / "03_output" / "AUTONOMOUS_SERIAL_PLAN.md").exists()
        checks["source_index_has_evidence_class"] = csv_header_contains(workspace_root / "01_index" / "source_index.csv", "evidence_class")
        checks["retained_evidence_has_evidence_class"] = csv_header_contains(workspace_root / "02_retained" / "retained_evidence.csv", "evidence_class")
    else:
        validation = {"status": "not_applicable"}
        checks["workspace_validator_ready"] = False

    return {
        "workspace_root": str(workspace_root),
        "state": state,
        "validation": validation,
        "checks": checks,
        "status": "ready" if all(checks.values()) else "needs_attention",
    }


def csv_header_contains(path: Path, column: str) -> bool:
    if not path.exists():
        return False
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        try:
            header = next(reader)
        except StopIteration:
            return False
    return column in header


def all_worker_headers_include(worker_root: Path, filename: str, column: str) -> bool:
    folders = [folder for folder in sorted(worker_root.glob("W*_*")) if folder.name not in {"W01_coordinator", "W02_master_tables"}]
    if not folders:
        return False
    return all(csv_header_contains(folder / filename, column) for folder in folders)


def render_markdown(result: dict) -> str:
    checks = "\n".join(f"- {key}: `{value}`" for key, value in result.get("checks", {}).items()) or "- none"
    return f"""# Research Skill Family Readiness Audit

## Summary

- family_root: `{result['family_root']}`
- project_root: `{result['project_root']}`
- source_workspace: `{result['source_workspace']}`
- export_workspace: `{result['export_workspace']}`
- export_family_root: `{result['export_family_root']}`
- status: `{result['status']}`

## Top-Level Checks

{checks}

## Family Validation

```json
{json.dumps(result['family_validation'], ensure_ascii=False, indent=2)}
```

## Family Smoke

```json
{json.dumps(result['family_smoke'], ensure_ascii=False, indent=2)}
```

## Export Validation

```json
{json.dumps(result['export_validation'], ensure_ascii=False, indent=2)}
```

## Export Smoke

```json
{json.dumps(result['export_smoke'], ensure_ascii=False, indent=2)}
```

## Source Workspace Audit

```json
{json.dumps(result['source_workspace_audit'], ensure_ascii=False, indent=2)}
```

## Export Workspace Audit

```json
{json.dumps(result['export_workspace_audit'], ensure_ascii=False, indent=2)}
```
"""


if __name__ == "__main__":
    main()
