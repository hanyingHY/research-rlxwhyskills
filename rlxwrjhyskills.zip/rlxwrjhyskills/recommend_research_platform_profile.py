#!/usr/bin/env python3
"""Recommend the best research platform profile for a target execution environment."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


CAPABILITY_KEYS = [
    "supports_local_file_paths",
    "supports_local_writes",
    "supports_subprocess_execution",
    "supports_bundled_scripts",
    "supports_multi_window_self_launch",
    "supports_owned_scope_isolation",
]


def main() -> None:
    parser = argparse.ArgumentParser(description="Recommend the best research platform profile")
    parser.add_argument("--profiles-file", default=str(Path(__file__).resolve().parent / "research_platform_profiles.json"))
    parser.add_argument("--requires-local-file-paths", choices=["yes", "no"], default="yes")
    parser.add_argument("--requires-local-writes", choices=["yes", "no"], default="yes")
    parser.add_argument("--requires-subprocess-execution", choices=["yes", "no"], default="no")
    parser.add_argument("--requires-bundled-scripts", choices=["yes", "no"], default="yes")
    parser.add_argument("--requires-multi-window-self-launch", choices=["yes", "no"], default="no")
    parser.add_argument("--requires-owned-scope-isolation", choices=["yes", "no"], default="no")
    parser.add_argument("--preferred-execution-posture", choices=["tool_runner", "manual_operator", "worker_lane"])
    parser.add_argument("--preferred-prompt-style", choices=["universal", "codex"])
    args = parser.parse_args()

    profiles_file = Path(args.profiles_file).resolve()
    payload = json.loads(profiles_file.read_text(encoding="utf-8"))
    requirements = {
        "supports_local_file_paths": args.requires_local_file_paths == "yes",
        "supports_local_writes": args.requires_local_writes == "yes",
        "supports_subprocess_execution": args.requires_subprocess_execution == "yes",
        "supports_bundled_scripts": args.requires_bundled_scripts == "yes",
        "supports_multi_window_self_launch": args.requires_multi_window_self_launch == "yes",
        "supports_owned_scope_isolation": args.requires_owned_scope_isolation == "yes",
    }

    ranked = rank_profiles(payload.get("profiles", []), requirements, args.preferred_execution_posture, args.preferred_prompt_style)
    best = ranked[0] if ranked else None
    result = {
        "profiles_file": str(profiles_file),
        "requirements": requirements,
        "preferred_execution_posture": args.preferred_execution_posture,
        "preferred_prompt_style": args.preferred_prompt_style,
        "recommended_profile": best,
        "ranked_profiles": ranked,
        "status": "ready" if best else "needs_attention",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(0 if best else 1)


def rank_profiles(profiles: list[dict], requirements: dict[str, bool], preferred_execution_posture: str | None, preferred_prompt_style: str | None) -> list[dict]:
    ranked: list[dict] = []
    for profile in profiles:
        score = 0
        blockers: list[str] = []
        notes: list[str] = []
        for key in CAPABILITY_KEYS:
            required = requirements[key]
            available = bool(profile.get(key))
            if required and not available:
                blockers.append(f"missing required capability: {key}")
            elif required and available:
                score += 3
                notes.append(f"meets required capability: {key}")
            elif not required and available:
                score += 1
        if preferred_execution_posture and profile.get("execution_posture") == preferred_execution_posture:
            score += 2
            notes.append("matches preferred execution posture")
        if preferred_prompt_style and profile.get("prompt_style") == preferred_prompt_style:
            score += 1
            notes.append("matches preferred prompt style")
        if not blockers:
            score += 5
            notes.append("no blocking capability mismatch")
        ranked.append(
            {
                "id": profile.get("id"),
                "display_name": profile.get("display_name"),
                "prompt_style": profile.get("prompt_style"),
                "execution_posture": profile.get("execution_posture"),
                "score": score,
                "blockers": blockers,
                "notes": notes,
            }
        )
    ranked.sort(key=lambda item: (len(item["blockers"]), -item["score"], item["id"] or ""))
    return ranked


if __name__ == "__main__":
    main()
